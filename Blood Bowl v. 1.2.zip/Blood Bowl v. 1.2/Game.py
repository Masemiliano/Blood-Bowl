import os
import pickle
import random
import time

import pygame
from Functions import *

pygame.init()

vidd, hoejd = 1380, 675

gameDisplay = pygame.display.set_mode((vidd, hoejd))

pygame.display.set_caption("Blood Bowl")
pygame.display.set_icon(pygame.image.load(".bilder/.markörer/Cancel.png"))

mus = pygame.image.load(".bilder/.markörer/Mus.png")
pekmus = pygame.image.load(".bilder/.markörer/Pekmus.png")
spelplan = pygame.image.load(".bilder/.spelplansgrejer/Nice.png")
boll = pygame.image.load(".bilder/.spelplansgrejer/Boll.png")

for v in os.listdir(".bilder/.lag/"):
    for v2 in os.listdir(".bilder/.lag/" + v):
        v3 = v2.replace(".png", "")
        globals()[v3 + "bild"] = pygame.image.load(".bilder/.lag/" + v + "/" + v2)
for v in os.listdir(".bilder/.markörer/"):
    v2 = v.replace(".png", "")
    globals()[v2 + "bild"] = pygame.image.load(".bilder/.markörer/" + v)
for v in os.listdir(".bilder/.tarningar/"):
    v2 = v.replace(".png", "")
    globals()[v2 + "bild"] = pygame.image.load(".bilder/.tarningar/" + v)
    globals()[v2 + "litenbild"] = pygame.transform.scale(globals()[v2 + "bild"], (20, 20))

pygame.mouse.set_visible(False)

lag1namn = pygame_input(gameDisplay, "Lag 1:")
filer = os.listdir(".skapade lag/" + lag1namn + "/.spelare/")
hela_laget1 = []
for v in filer:
    fil = open(".skapade lag/" + lag1namn + "/.spelare/" + v, "rb")
    hela_laget1.append(pickle.load(fil))

# följande handlar om att ladda en match automatiskt genom att skriva in bara ett lags namn
matchen = ""

varfil = open(".skapade lag/" + lag1namn + "/Var", "r")
var1 = varfil.read()
varfil.close()
if var1 != "inget":
    matchen = var1

#

if matchen:
    lag1namn, lag2namn = matchen.split(" VS ")
    filer = os.listdir(".skapade lag/" + lag1namn + "/.spelare/")
    hela_laget1 = []
    for v in filer:
        fil = open(".skapade lag/" + lag1namn + "/.spelare/" + v, "rb")
        hela_laget1.append(pickle.load(fil))
else:
    lag2namn = pygame_input(gameDisplay, "Lag 2:")
    varfil = open(".skapade lag/" + lag2namn + "/Var", "r")
    var2 = varfil.read()
    varfil.close()
    if var2 != "inget":
        print("Lag2 var redan i en match, men inte i match med lag1. Därför stängde vi ner programmet, för ett lag kan "
              "inte vara i flera matcher samtidigt.")
        exit()
filer = os.listdir(".skapade lag/" + lag2namn + "/.spelare/")
hela_laget2 = []
for v in filer:
    fil = open(".skapade lag/" + lag2namn + "/.spelare/" + v, "rb")
    hela_laget2.append(pickle.load(fil))

alla_spelare1 = []
for v in hela_laget1:
    alla_spelare1.append(spelareimatch(v))
alla_spelare2 = []
for v in hela_laget2:
    alla_spelare2.append(spelareimatch(v))

fil1, fil2 = open(".skapade lag/" + lag1namn + "/Coach", "r"), open(".skapade lag/" + lag2namn + "/Coach", "r")
coach1, coach2 = fil1.read().strip(), fil2.read().strip()
fil1.close()
fil2.close()

aglist = [None, 6, 5, 4, 3, 2, 1]

tarningsslag = []

listahall = [25, 26, 27, -1, 1, -27, -26, -25]


def spara_match():
    vag = ".matcher/" + lag1namn + " VS " + lag2namn
    try:
        os.mkdir(vag)
    except FileExistsError:
        pass
    try:
        os.mkdir(vag + "/1")
    except FileExistsError:
        pass
    try:
        os.mkdir(vag + "/2")
    except FileExistsError:
        pass
    for vh in alla_spelare1:
        filh = open(vag + "/1/" + vh.spelare.namn, "wb")
        pickle.dump(vh, filh)
        filh.close()
    for vh in alla_spelare2:
        filh = open(vag + "/2/" + vh.spelare.namn, "wb")
        pickle.dump(vh, filh)
        filh.close()
    filh = open(".skapade lag/" + lag1namn + "/Var", "w")
    filh.write(lag1namn + " VS " + lag2namn)
    filh.close()
    filh = open(".skapade lag/" + lag2namn + "/Var", "w")
    filh.write(lag1namn + " VS " + lag2namn)
    filh.close()

    filh = open(vag + "/Lag1", "w")
    filh.write(str(lag1namn))
    filh.close()
    filh = open(vag + "/Lag2", "w")
    filh.write(str(lag2namn))
    filh.close()

    filh = open(vag + "/T", "w")
    filh.write(str(tur))
    filh.close()
    filh = open(vag + "/B", "w")
    filh.write(str(bollruta))
    filh.close()
    filh = open(vag + "/Bö", "w")
    filh.write(str(borjar))
    filh.close()
    filh = open(vag + "/PH", "w")
    listh = [True, True]
    if not handoffat:
        listh[0] = ""
    if not passat:
        listh[1] = ""
    filh.write(str(listh[0]) + "\n" + str(listh[1]))
    filh.close()
    filh = open(vag + "/D", "w")
    filh.write(str(drag))
    filh.close()

    filh = open(vag + "/TD", "w")
    filh.write(str(td1) + "\n" + str(td2))
    filh.close()

    filh = open(vag + "/Tä", "w")
    stringh = ""
    for sh in tarningsslag:
        stringh += sh + "\n"
    filh.write(stringh.strip())
    filh.close()

    splash_message("Match sparad", tid=2.0)


def ladda_match():
    global tur, bollruta, borjar, passat, handoffat, drag, td1, td2, tarningsslag
    vag = ".matcher/" + lag1namn + " VS " + lag2namn
    numh = 0
    for vh in alla_spelare1:
        filh = open(vag + "/1/" + vh.spelare.namn, "rb")
        alla_spelare1[numh] = pickle.load(filh)
        filh.close()
        numh += 1
    numh = 0
    for vh in alla_spelare2:
        filh = open(vag + "/2/" + vh.spelare.namn, "rb")
        alla_spelare2[numh] = pickle.load(filh)
        filh.close()
        numh += 1
    filh = open(vag + "/T", "r")
    tur = int(filh.read().strip())
    filh.close()
    filh = open(vag + "/B", "r")
    bollruta = int(filh.read().strip())
    filh.close()
    filh = open(vag + "/Bö", "r")
    borjar = int(filh.read().strip())
    filh.close()
    filh = open(vag + "/PH", "r")
    ett, tva = filh.read().split("\n")
    if ett:
        handoffat = True
    else:
        handoffat = False
    if tva:
        passat = True
    else:
        passat = False
    filh.close()

    filh = open(vag + "/D", "r")
    drag = int(filh.read())
    filh.close()

    filh = open(vag + "/TD", "r")
    tdlist = filh.read().split("\n")
    td1, td2 = int(tdlist[0]), int(tdlist[1])
    filh.close()

    filh = open(vag + "/Tä", "r")
    tarningsslag = filh.read().split("\n")
    filh.close()


def vem_star_har(ruta, return_team=False):
    for vh in alla_spelare1:
        if vh.ruta == ruta:
            if return_team:
                return vh, 1
            else:
                return vh
    for vh in alla_spelare2:
        if vh.ruta == ruta:
            if return_team:
                return vh, 2
            else:
                return vh
    if return_team:
        return None, None


def valj_person(lag):
    yh = 0
    for vh in lag:
        if vh.ruta == 1000:
            locals()["knapp" + vh.spelare.namn] = knapp(gameDisplay, vh.spelare.typ + ": " + vh.spelare.namn, (0, yh),
                                                        40)
        yh += 40
    while True:
        rita(False)
        for eventh in pygame.event.get():
            if eventh.type == pygame.MOUSEBUTTONDOWN:
                if eventh.button == 1:
                    for vh in lag:
                        if vh.ruta == 1000:
                            if locals()["knapp" + vh.spelare.namn].ar_aktiv():
                                return vh
                if eventh.button == 3:
                    return None

        peka = False
        for vh in lag:
            if vh.ruta == 1000:
                locals()["knapp" + vh.spelare.namn].rita()
                if locals()["knapp" + vh.spelare.namn].ar_aktiv():
                    peka = True
        musposh = pygame.mouse.get_pos()
        if peka:
            gameDisplay.blit(pekmus, musposh)
        else:
            gameDisplay.blit(mus, musposh)

        pygame.display.update()


def passa(person):
    global bollruta, passat
    while True:
        rita(False)
        musposh = pygame.mouse.get_pos()
        rutah = vilken_ruta(musposh)

        langd = kolla_langden(person.ruta, rutah)

        farg = (30, 30, 30)

        if langd == "bomb":
            farg = (255, 0, 0)
        elif langd == "long":
            farg = (255, 97, 3)
        elif langd == "short":
            farg = (255, 215, 0)
        elif langd == "quick":
            farg = (0, 255, 0)

        pos1, pos2 = fa_pos(person.ruta), fa_pos(rutah)
        pygame.draw.line(gameDisplay, farg, (pos1[0] + 22, pos1[1] + 22), (pos2[0] + 22, pos2[1] + 22), 5)

        if langd == "":
            gameDisplay.blit(globals()["Cancelbild"], fa_pos(rutah))
        else:
            if vem_star_har(rutah) is not None:
                if vem_star_har(rutah, True)[1] == tur:
                    gameDisplay.blit(globals()["Grön markörbild"], fa_pos(rutah))
                else:
                    gameDisplay.blit(globals()["Röd markörbild"], fa_pos(rutah))
            else:
                gameDisplay.blit(globals()["Röd markörbild"], fa_pos(rutah))

        gameDisplay.blit(mus, musposh)
        pygame.display.update()

        for eventh in pygame.event.get():
            if eventh.type == pygame.MOUSEBUTTONDOWN:
                if eventh.button == 1:
                    if gor_nagot(person, tur):
                        rutanh = vilken_ruta(pygame.mouse.get_pos())
                        langd = kolla_langden(person.ruta, rutanh)
                        if langd != "":
                            modify = 0
                            if langd == "bomb":
                                modify -= 2
                            elif langd == "long":
                                modify -= 1
                            elif langd == "quick":
                                modify += 1
                            modify -= tackle_zones(person)
                            ag = int(person.spelare.varden[2])
                            mer = aglist[ag]
                            slag = tarning(person.spelare.namn + " försöker passa, med " + str(mer - modify) + "+",
                                           "pass")
                            oslag = slag
                            slag += modify
                            person.har_bollen = False
                            if slag <= 1 or oslag == 1:
                                if ball_bounce() == "denfor":
                                    inkast()
                                bra = False
                            else:
                                bollruta = rutanh

                                ute = False
                                acc = True
                                if slag < mer and oslag != 6:
                                    acc = False
                                    for _ in range(0, 3):
                                        if ball_scatter() == "denfor":
                                            inkast()
                                            ute = True
                                            break
                                if not ute:
                                    ph, lh = vem_star_har(bollruta, True)
                                    if ph is not None:
                                        if fanga(acc) == "denfor":
                                            inkast()
                                    else:
                                        if ball_bounce() == "denfor":
                                            inkast()
                                bra = False
                                if tur == 1:
                                    for vh in alla_spelare1:
                                        if vh.har_bollen:
                                            bra = True
                                if tur == 2:
                                    for vh in alla_spelare2:
                                        if vh.har_bollen:
                                            bra = True
                            person.fardig = True
                            passat = True
                            if not bra:
                                nasta_drag("Turnover")
                            return
                if eventh.button == 3:
                    return


def handoffa(person):
    global bollruta, handoffat
    while True:
        rita(False)

        musposh = pygame.mouse.get_pos()
        rutanh = vilken_ruta(musposh)
        ja = False
        for numh in listahall:
            if rutanh == person.ruta + numh:
                ja = True

        vem, lag = vem_star_har(rutanh, True)
        if vem is not None:
            if lag == tur:
                bra = True
            else:
                bra = "nja"
        else:
            bra = False
        if ja:
            if bra == "nja":
                gameDisplay.blit(globals()["Röd markörbild"], fa_pos(rutanh))
            elif bra:
                gameDisplay.blit(globals()["Grön markörbild"], fa_pos(rutanh))
            else:
                gameDisplay.blit(globals()["Cancelbild"], fa_pos(rutanh))
        else:
            gameDisplay.blit(globals()["Cancelbild"], fa_pos(rutanh))

        gameDisplay.blit(mus, musposh)

        for eventh in pygame.event.get():
            if eventh.type == pygame.MOUSEBUTTONDOWN:
                if eventh.button == 1:
                    if ja:
                        if bra:
                            if gor_nagot(person, tur):
                                person.har_bollen = False
                                bollruta = rutanh
                                fanga(True)
                                turnover = True
                                if tur == 1:
                                    for vh in alla_spelare1:
                                        if vh.har_bollen:
                                            turnover = False
                                if tur == 2:
                                    for vh in alla_spelare2:
                                        if vh.har_bollen:
                                            turnover = False
                                person.fardig = True
                                handoffat = True
                                if turnover:
                                    nasta_drag("Turnover")
                                return
                        else:
                            return
                    else:
                        return
                if eventh.button == 3:
                    return
        pygame.display.update()


def action(person):
    kanpassa = person.ska_passa and person.har_bollen and not passat
    kanhandoffa = person.ska_handoffa and person.har_bollen and not handoffat
    kanresasig = not person.star
    avbrytknapp = knapp(gameDisplay, "Avbryt", (1180, 20), 45)
    yh = 80
    passknapp, handoffknapp, resasigknapp = None, None, None
    if kanpassa:
        passknapp = knapp(gameDisplay, "Passa", (1180, yh), 45)
        yh += 60
    if kanhandoffa:
        handoffknapp = knapp(gameDisplay, "Hand-offa", (1180, yh), 45)
        yh += 60
    if kanresasig:
        resasigknapp = knapp(gameDisplay, "Resa sig", (1180, yh), 45)
        yh += 60
    while True:
        for eventh in pygame.event.get():
            if eventh.type == pygame.MOUSEBUTTONDOWN:
                if eventh.button == 1:
                    if avbrytknapp.ar_aktiv():
                        return
                    if kanpassa and passknapp.ar_aktiv():
                        if person.fardig is False:
                            passa(person)
                            return
                    if kanhandoffa and handoffknapp.ar_aktiv():
                        if person.fardig is False:
                            handoffa(person)
                            return
                    if kanresasig and resasigknapp.ar_aktiv():
                        if gor_nagot(person, tur):
                            if aktiv.steg_kvar > 2:
                                aktiv.star = True
                                aktiv.steg_kvar -= 3
                            else:
                                if tarning(aktiv.spelare.namn + " försöker ställa sig upp, 4+", "resa sig") > 3:
                                    aktiv.star = True
                                    aktiv.steg_kvar -= 3
                                else:
                                    aktiv.fardig = True
                            return
                if eventh.button == 3:
                    return
        rita(False)
        gameDisplay.blit(globals()["Cirkelvitbild"], fa_pos(person.ruta))
        avbrytknapp.rita()
        if kanpassa:
            passknapp.rita()
        if kanhandoffa:
            handoffknapp.rita()
        if kanresasig:
            resasigknapp.rita()
        if avbrytknapp.ar_aktiv() or (kanpassa and passknapp.ar_aktiv()) or (kanhandoffa and handoffknapp.ar_aktiv()) \
                or (kanresasig and resasigknapp.ar_aktiv()):
            gameDisplay.blit(pekmus, pygame.mouse.get_pos())
        else:
            gameDisplay.blit(mus, pygame.mouse.get_pos())
        pygame.display.update()


def declare_action(person):
    avbrytknapp = knapp(gameDisplay, "Avbryt", (1180, 20), 40)
    blitzknapp = knapp(gameDisplay, "Blitz", (1180, 80), 40)
    passknapp = knapp(gameDisplay, "Pass", (1180, 140), 40)
    handoffknapp = knapp(gameDisplay, "Handoff", (1180, 200), 40)
    fardeclara = person.steg_kvar == person.spelare.varden[0] and not person.har_gjort
    if not fardeclara:
        return
    farblitza = not har_blitzat(tur) and not person.ska_passa and not person.ska_handoffa
    farpassa = not har_passat(tur) and not person.ska_blitza and not person.ska_handoffa
    farhandoffa = not har_handoffat(tur) and not person.ska_blitza and not person.ska_passa
    while True:
        for eventh in pygame.event.get():
            if eventh.type == pygame.MOUSEBUTTONDOWN:
                if eventh.button == 1:
                    if avbrytknapp.ar_aktiv():
                        return
                    if blitzknapp.ar_aktiv() and farblitza:
                        person.ska_blitza = True
                        return
                    if passknapp.ar_aktiv() and farpassa:
                        person.ska_passa = True
                        return
                    if handoffknapp.ar_aktiv() and farhandoffa:
                        person.ska_handoffa = True
                        return
                elif eventh.button == 3:
                    return
        rita(False)
        gameDisplay.blit(globals()["Cirkelvitbild"], fa_pos(person.ruta))
        avbrytknapp.rita()
        if farblitza:
            blitzknapp.rita()
        if farpassa:
            passknapp.rita()
        if farhandoffa:
            handoffknapp.rita()
        if avbrytknapp.ar_aktiv() or (blitzknapp.ar_aktiv() and farblitza) or (passknapp.ar_aktiv() and farpassa) \
                or (handoffknapp.ar_aktiv() and farhandoffa):
            gameDisplay.blit(pekmus, pygame.mouse.get_pos())
        else:
            gameDisplay.blit(mus, pygame.mouse.get_pos())
        pygame.display.update()


def hogerklick(person):
    declareknapp = knapp(gameDisplay, "Declara", (1180, 20))
    gorknapp = knapp(gameDisplay, "Gör något", (1180, 80))
    while True:
        rita(False)
        declareknapp.rita()
        gorknapp.rita()
        if declareknapp.ar_aktiv() or gorknapp.ar_aktiv():
            gameDisplay.blit(pekmus, pygame.mouse.get_pos())
        else:
            gameDisplay.blit(mus, pygame.mouse.get_pos())
        pygame.display.update()
        for eventh in pygame.event.get():
            if eventh.type == pygame.MOUSEBUTTONDOWN:
                if eventh.button == 1:
                    if declareknapp.ar_aktiv():
                        declare_action(person)
                        return
                    if gorknapp.ar_aktiv():
                        action(person)
                        return
                if eventh.button == 3:
                    return


def rita(visamus=True):
    gameDisplay.fill((30, 100, 255))
    gameDisplay.blit(spelplan, (0, 0))
    gameDisplay.blit(boll, fa_pos(bollruta))

    for vh in alla_spelare1:
        gameDisplay.blit(globals()[vh.spelare.typ + "bild"], fa_pos(vh.ruta))
        if vh.star is False:
            skriv(gameDisplay, "N", fa_pos(vh.ruta))
        if vh.ska_blitza is True:
            gameDisplay.blit(globals()["Blitzbild"], fa_pos(vh.ruta))
        if vh.ska_passa is True:
            gameDisplay.blit(globals()["Passbild"], fa_pos(vh.ruta))
        if vh.ska_handoffa is True:
            gameDisplay.blit(globals()["Handoffbild"], fa_pos(vh.ruta))
    for vh in alla_spelare2:
        gameDisplay.blit(globals()[vh.spelare.typ + "bild"], fa_pos(vh.ruta))
        if vh.star is False:
            skriv(gameDisplay, "N", fa_pos(vh.ruta))
        if vh.ska_blitza is True:
            gameDisplay.blit(globals()["Blitzbild"], fa_pos(vh.ruta))
        if vh.ska_passa is True:
            gameDisplay.blit(globals()["Passbild"], fa_pos(vh.ruta))
        if vh.ska_handoffa is True:
            gameDisplay.blit(globals()["Handoffbild"], fa_pos(vh.ruta))

    if visamus:
        musposh = pygame.mouse.get_pos()
        gameDisplay.blit(mus, musposh)


def rita_stats(person, stegkvar=False):
    vilkety = 190
    if stegkvar:
        pygame.draw.rect(gameDisplay, (255, 255, 255), (1175, vilkety - 5, 250, 115))
    else:
        pygame.draw.rect(gameDisplay, (255, 255, 255), (1175, vilkety - 5, 250, 95))
    skriv(gameDisplay, person.spelare.namn, (1180, vilkety), 30)
    skriv(gameDisplay, person.spelare.typ, (1180, vilkety + 25), 20)
    skriv(gameDisplay, str(person.spelare.varden).replace("[", "").replace("]", ""), (1180, vilkety + 45), 20)
    plush = 0
    if stegkvar:
        skriv(gameDisplay, str(person.steg_kvar) + " steg kvar", (1180, vilkety + 65), 20)
        plush = 20
    skriv(gameDisplay, str(person.spelare.skills).replace("[", "").replace("]", "").replace("'", ""),
          (1180, vilkety + 65 + plush), 20)  # plush: för att om stegkvar visas, så måste
    # skills visas längre ned


def rakna_klar(lag, nu):
    klart = True
    vad = ""
    kantn = 0
    kantu = 0
    linjen = 0
    for vh in lag:
        if nu == 1:
            if fa_pos(vh.ruta)[0] < 585 and vh.ruta != 1000:
                klart = False
                vad = "Du har spelare på fel sida!"
            if 584 < fa_pos(vh.ruta)[0] < 630 and vh.ruta != 1000 and 179 < fa_pos(vh.ruta)[1] < 495:
                linjen += 1
        if nu == 2:
            if fa_pos(vh.ruta)[0] > 584 and vh.ruta != 1000:
                klart = False
                vad = "Du har spelare på fel sida!"
            if 585 > fa_pos(vh.ruta)[0] > 539 and vh.ruta != 1000 and 179 < fa_pos(vh.ruta)[1] < 495:
                linjen += 1
        if fa_pos(vh.ruta)[1] > 494 and vh.ruta != 1000:
            kantn += 1
        if fa_pos(vh.ruta)[1] < 180 and vh.ruta != 1000:
            kantu += 1

    if kantu > 2:
        klart = False
        vad = "Du har för många i övre wide zone!"
    if kantn > 2:
        klart = False
        vad = "Du har för många i nedre wide zone!"
    if linjen < 3 and not vad:
        klart = False
        vad = "Du har inte tre personer på linjen!"

    return klart, vad


def splash_message(string, farg=(255, 0, 0), tid=1.0):
    gameDisplay.fill(farg)
    skriv(gameDisplay, string, (50, 50), 90, (50, 0, 0))
    pygame.display.update()
    time.sleep(tid)


def gor_nagot(person, turh):
    if person.fardig is False:
        if turh == 1:
            lagh = alla_spelare1
        else:
            lagh = alla_spelare2
        for vh in lagh:
            if not vh.spelare.namn == person.spelare.namn:
                if vh.har_gjort:
                    vh.fardig = True
        person.har_gjort = True
        return True
    else:
        return False


def tarning(message="", tema=None):
    slag = random.randint(1, 6)
    if tema is None:
        tarningsslag.append("T6: " + str(slag))
    else:
        tarningsslag.append("T6 (" + tema + "): " + str(slag))
    rita()
    gameDisplay.blit(globals()["Tärning" + str(slag) + "bild"], (20, 20))
    skriv(gameDisplay, message, (20, 65), 50)
    pygame.display.update()
    time.sleep(2)
    return slag


def nasta_drag(message):
    global bollruta, tur, aktiv, drag, info, passat, handoffat
    passat, handoffat = False, False
    rita(False)
    skriv(gameDisplay, message, (50, 50), 90, (50, 0, 0))
    pygame.display.update()
    time.sleep(1)
    aktiv = None
    info = None
    if tur == 1:
        for vh in alla_spelare1:
            vh.fardig = False
            vh.har_gjort = False
            vh.steg_kvar = vh.spelare.varden[0]
            vh.ska_blitza = False
            vh.har_blockat = False
            vh.ska_passa = False
            vh.ska_handoffa = False
        tur = 2
    else:
        for vh in alla_spelare2:
            vh.fardig = False
            vh.har_gjort = False
            vh.steg_kvar = vh.spelare.varden[0]
            vh.ska_blitza = False
            vh.har_blockat = False
            vh.ska_passa = False
            vh.ska_handoffa = False
        tur = 1
    drag += 1
    if drag == 17:
        splash_message("Halvlek", (0, 255, 0))
        drag = 17
        if tur == 1:
            set_up(1)
        else:
            set_up(2)
    elif drag == 33:
        slut()


def slut():
    filh = open(".skapade lag/" + lag1namn + "/Var", "w")
    filh.write("inget")
    filh.close()
    filh = open(".skapade lag/" + lag2namn + "/Var", "w")
    filh.write("inget")
    filh.close()
    splash_message("Matchen är slut!", tid=1.5)
    if not td1 == td2:
        if td1 > td2:
            sh = "1"
        else:
            sh = "2"
        pygame_input(gameDisplay, globals()["lag" + str(sh) + "namn"] + " vann med " + str(td1) + " – " + str(td2) +
                     ".")
    else:
        pygame_input(gameDisplay, "Det blev lika!")
    quit()


def ball_bounce(sidbry=0):
    tebaks = ""
    global bollruta
    rita()
    pygame.display.update()
    hallsiffra = random.randint(1, 8)
    tarningsslag.append("T8 (bounce): " + str(hallsiffra))
    hall = listahall[hallsiffra - 1]
    if sidbry:
        if far_bollen_ut(hall, True, sidbry):
            tebaks = "denfor"
    else:
        if far_bollen_ut(hall):
            tebaks = "denfor"
    if tebaks != "denfor":
        time.sleep(1)
        rita()
        pygame.display.update()
        bollruta += hall
        if vem_star_har(bollruta) is not None:
            if vem_star_har(bollruta).star is True:
                tebaks = fanga(sidbry=sidbry)
            else:
                tebaks = ball_bounce(sidbry)
    return tebaks


def ball_scatter(sidbry=0):
    tebaks = ""
    global bollruta
    rita()
    pygame.display.update()
    hallsiffra = random.randint(1, 8)
    tarningsslag.append("T8 (scatter): " + str(hallsiffra))
    hall = listahall[hallsiffra - 1]
    if sidbry:
        if far_bollen_ut(hall, True, sidbry):
            tebaks = "denfor"
    else:
        if far_bollen_ut(hall):
            tebaks = "denfor"
    if tebaks != "denfor":
        rita()
        pygame.display.update()
        bollruta += hall
    return tebaks


def inkast():
    splash_message("Inkast!")
    global bollruta
    t3 = random.randint(1, 3)
    tarningsslag.append("T3 (throw-in): " + str(t3))
    # följande kan var confusing, förklaring:
    # om bollen far ut på kortsidan, så kan bollruta inte plussas ut från skärmen, för då hamnar den på andra sidan
    # plan. Om det gjorts, så hade den inte "fått" åka in igen
    # "fore" är till för att om den far ut på kortsidan, så kan ju inte inkastet ske från den oplussade bollrutan, för
    # då hade det ju blivit fel. Därför måste den börja customizat och sedan fara ett steg mindre (m.h.a. "borja").
    fore = [0, 0, 0]
    borja = 0
    if fa_pos(bollruta)[0] == 1125 or fa_pos(bollruta)[0] == 0:
        borja = 1
    if fa_pos(bollruta)[0] == 1125:
        listahallh = [25, -1, -27]
        fore = [26, 0, -26]
    elif fa_pos(bollruta)[0] == 0:
        listahallh = [27, 1, -25]
        fore = [26, 0, -26]
    else:
        if fa_pos(bollruta)[1] > 300:
            listahallh = [-27, -26, -25]
            bollruta += 26
        else:
            listahallh = [25, 26, 27]
            bollruta -= 26
    hall = listahallh[t3 - 1]
    if fore[t3 - 1]:
        if not far_bollen_ut(fore[t3 - 1]):
            bollruta += fore[t3 - 1]
    langd = random.randint(1, 6)
    tarningsslag.append("T6: (throw-in): " + str(langd))

    studs = True
    for numh in range(borja, langd):
        if far_bollen_ut(hall):
            studs = False
            inkast()
            break
        else:
            bollruta += hall
    if studs:
        if vem_star_har(bollruta) is not None:
            if vem_star_har(bollruta).star is True:
                n = fanga(False)
                if n == "denfor":
                    inkast()
            else:
                if ball_bounce() == "denfor":
                    inkast()
        else:
            if ball_bounce() == "denfor":
                inkast()


def far_bollen_ut(plush, bry_om_sida=False, sida=1):
    nux, nuy = fa_pos(bollruta)
    pospluslistah = [25, (-45, 45), 26, (0, 45), 27, (45, 45), -1, (-45, 0), 1, (45, 0), -27, (-45, -45),
                     -26, (0, -45), -25, (45, -45)]
    ppos = pospluslistah[pospluslistah.index(plush) + 1]
    if bry_om_sida:
        if (fa_pos(bollruta)[0] + ppos[0] < 585 and sida == 1) or (fa_pos(bollruta)[0] + ppos[0] > 584 and sida == 2):
            return True
    if -1 < nux + ppos[0] < 1169 and -1 < nuy + ppos[1] < 674:
        return False
    else:
        return True


def far_spelaren_ut(person, plush, bry_om_sida=False, sida=1):
    nux, nuy = fa_pos(person.ruta)
    pospluslistah = [25, (-45, 45), 26, (0, 45), 27, (45, 45), -1, (-45, 0), 1, (45, 0), -27, (-45, -45),
                     -26, (0, -45), -25, (45, -45)]
    ppos = pospluslistah[pospluslistah.index(plush) + 1]
    if bry_om_sida:
        if (nux + ppos[0] < 585 and sida == 1) or (nux + ppos[0] > 584 and sida == 2):
            return True
    if -1 < nux + ppos[0] < 1169 and -1 < nuy + ppos[1] < 674:
        return False
    else:
        return True


def far_nagot_ut(ruta, plush, bry_om_sida=False, sida=1):
    nux, nuy = fa_pos(ruta)
    pospluslistah = [25, (-45, 45), 26, (0, 45), 27, (45, 45), -1, (-45, 0), 1, (45, 0), -27, (-45, -45),
                     -26, (0, -45), -25, (45, -45)]
    ppos = pospluslistah[pospluslistah.index(plush) + 1]
    if bry_om_sida:
        if (nux + ppos[0] < 585 and sida == 1) or (nux + ppos[0] > 584 and sida == 2):
            return True
    if -1 < nux + ppos[0] < 1169 and -1 < nuy + ppos[1] < 674:
        return False
    else:
        return True


def tackle_zones(person):
    zoner = 0
    for numh in listahall:
        if not far_spelaren_ut(person, numh):
            p, lag = vem_star_har(person.ruta + numh, True)
            if p is not None and lag != vem_star_har(person.ruta, True)[1]:
                if p.star and p.tacklezone:
                    zoner += 1
    return zoner


def tackle_zones_ruta(ruta, personenslag):
    zoner = 0
    for numh in listahall:
        if not far_nagot_ut(ruta, numh):
            p, lag = vem_star_har(ruta + numh, True)
            if p is not None and lag != personenslag:
                if p.star and p.tacklezone:
                    zoner += 1
    return zoner


def fanga(accurate=False, sidbry=0):
    person, lag = vem_star_har(bollruta, True)
    ag = person.spelare.varden[2]
    mer = aglist[ag]
    h = 0
    if accurate:
        h = 1
    numh = tarning(person.spelare.namn + " försöker fånga bollen med " + str(mer + tackle_zones(person) - h) + "+",
                   "fångning")
    numhm = numh
    if accurate:
        numhm = numh + 1
    numhm -= tackle_zones(person)
    if (numhm >= mer and numh != 1 and numhm != 1) or numh == 6:
        person.har_bollen = True
    else:
        return ball_bounce(sidbry)


def putt(p, m, original=False):  # person, mot
    tebaks = ""
    global bollruta
    riktningindex = m.ruta - p.ruta
    riktlista = [-27, (-1, -27, -26), -26, (-27, -26, -25), -25, (-26, -25, 1), -1, (-27, -1, 25), 1, (-25, 1, 27),
                 25, (-1, 25, 26), 26, (25, 26, 27), 27, (26, 27, 1)]
    riktningar = riktlista[riktlista.index(riktningindex) + 1]
    hallen = []
    numhh = 0
    kanskeut = []
    for vh in riktningar:
        hallen.append(True)
        if vem_star_har(m.ruta + vh) is not None:
            hallen[numhh] = False
        if far_spelaren_ut(m, vh):
            hallen[numhh] = False
            kanskeut.append(True)
        else:
            kanskeut.append(False)
        numhh += 1
    alla = True
    for vh in hallen:
        if vh:
            alla = False
    if alla:
        numhh = 0
        for _ in hallen:
            hallen[numhh] = True
            numhh += 1
    ut = False
    uth = False
    if alla and kanskeut.__contains__(True):
        uth = True
    utknapp = knapp(gameDisplay, "Putta ut!", (1180, 20), 45, (255, 10, 10))
    # kanskeut är antalet av de möjliga puttrutorna som är utanför plan, och utrak är sedan hur många puttrutor det
    # finns totalt. Om det är lika många, d.v.s. att alla puttrutor är utanför plan, så blir ut True
    while True:
        rita(False)
        if uth:
            utknapp.rita()
        for eventhh in pygame.event.get():
            if eventhh.type == pygame.MOUSEBUTTONDOWN:
                rutanh = vilken_ruta(pygame.mouse.get_pos())
                vart = rutanh - m.ruta
                if uth and utknapp.ar_aktiv():
                    ut = True
                if (vart in riktningar and hallen[riktningar.index(vart)] and not kanskeut[riktningar.index(vart)]) \
                        or ut:
                    fore = m.ruta
                    if ut:
                        splash_message(m.spelare.namn + " blev utsmashad!", tid=2.0)
                        m.ruta = 1000
                    elif vem_star_har(rutanh) is not None:
                        tebaks = putt(m, vem_star_har(m.ruta + vart))
                    m.ruta += vart
                    if m.har_bollen:
                        if ut:
                            tebaks = "inkast"
                        else:
                            bollruta += vart
                    if m.ruta == bollruta and not m.har_bollen:
                        if tebaks != "inkast":
                            tebaks = "paboll"
                    if original:
                        ja, nej = knapp(gameDisplay, "Följ efter", (20, 20)), knapp(gameDisplay, "Stanna", (20, 70))
                        folja, stopp = False, False
                        while not stopp:
                            for event2hh in pygame.event.get():
                                if event2hh.type == pygame.MOUSEBUTTONDOWN:
                                    if ja.ar_aktiv():
                                        folja = True
                                        stopp = True
                                    elif nej.ar_aktiv():
                                        folja = False
                                        stopp = True
                            rita(False)
                            ja.rita()
                            nej.rita()
                            if ja.ar_aktiv() or nej.ar_aktiv():
                                gameDisplay.blit(pekmus, pygame.mouse.get_pos())
                            else:
                                gameDisplay.blit(mus, pygame.mouse.get_pos())
                            pygame.display.update()
                        if folja:
                            p.ruta = fore
                            if p.har_bollen:
                                bollruta = fore
                    return tebaks
        numhh = 0
        for vh in hallen:
            if vh and not kanskeut[numhh]:
                gameDisplay.blit(globals()["Grön markörbild"], fa_pos(m.ruta + riktningar[numhh]))
            numhh += 1
        if uth and utknapp.ar_aktiv():
            gameDisplay.blit(pekmus, pygame.mouse.get_pos())
        else:
            gameDisplay.blit(mus, pygame.mouse.get_pos())
        pygame.display.update()


def blocka(person, motperson):
    st1, st2 = person.spelare.varden[1], motperson.spelare.varden[1]
    perlag = vem_star_har(person.ruta, True)[1]
    extra2 = 0
    for numh in listahall:
        if not far_spelaren_ut(person, numh):
            if person.ruta + numh != motperson.ruta:
                ph, lh = vem_star_har(person.ruta + numh, True)
                if ph is not None:
                    if lh != perlag:
                        if ph.star and ph.tacklezone:
                            if tackle_zones(ph) == 1:
                                extra2 += 1
    motlag = vem_star_har(motperson.ruta, True)[1]
    extra1 = 0
    for numh in listahall:
        if not far_spelaren_ut(motperson, numh):
            if motperson.ruta + numh != person.ruta:
                ph, lh = vem_star_har(motperson.ruta + numh, True)
                if ph is not None:
                    if lh != motlag:
                        if ph.star and ph.tacklezone:
                            if tackle_zones(ph) == 1:
                                extra1 += 1
    st1 += extra1
    st2 += extra2

    # print(st1)
    # print(st2)

    text = "Det finns inte så mycket att välja på"
    if st1 > st2:
        text = "Anfallaren väljer tärning"
    if st1 < st2:
        text = "Försvararen väljer tärning"

    tva, tre = False, False
    if st1 < st2 or st1 > st2:
        tva = True
    if st1 * 2 < st2 or st1 > st2 * 2:
        tre = True

    blocklista = ["Dödskalle", "Putt", "Putt", "Both down", "Defender down", "Defender stumbles"]
    val1, val2, val3 = random.choice(blocklista), random.choice(blocklista), random.choice(blocklista)

    plushar = val1
    if tva:
        plushar += ", " + val2
    if tre:
        plushar += ", " + val3

    while True:
        for eventh in pygame.event.get():
            if eventh.type == pygame.MOUSEBUTTONDOWN:
                musx, musy = pygame.mouse.get_pos()
                if ((20 <= musx <= 60) or (100 <= musx <= 140 and tva) or (180 <= musx <= 220 and tre)) and 20 <= musy \
                        <= 60:
                    if 20 <= musx <= 60:
                        valt = val1
                        tarningsslag.append("Block: " + plushar + ": " + str(0))
                    elif 100 <= musx <= 160 and tva:
                        valt = val2
                        tarningsslag.append("Block: " + plushar + ": " + str(1))
                    else:
                        valt = val3
                        tarningsslag.append("Block: " + plushar + ": " + str(2))
                    nastah = False
                    if valt == "Dödskalle":
                        person.star = False
                        if person.har_bollen:
                            if ball_bounce() == "denfor":
                                inkast()
                        person.har_bollen = False
                        rita()
                        pygame.display.update()
                        nastah = True
                    if valt == "Both down":
                        if not motperson.spelare.skills.__contains__("block"):
                            motperson.star = False
                        if not person.spelare.skills.__contains__("block"):
                            person.star = False
                            if person.har_bollen:
                                if ball_bounce() == "denfor":
                                    inkast()
                            person.har_bollen = False
                            rita()
                            pygame.display.update()
                            nastah = True
                        if not motperson.spelare.skills.__contains__("block"):
                            if motperson.har_bollen:
                                if ball_bounce() == "denfor":
                                    inkast()
                            motperson.har_bollen = False
                    if valt == "Defender stumbles":
                        if (not motperson.spelare.skills.__contains__("dodge")) or person.spelare.skills.__contains__(
                                "tackle"):
                            motperson.star = False
                        putten = putt(person, motperson, True)
                        if putten == "paboll":
                            if ball_bounce() == "denfor":
                                inkast()
                        if putten == "inkast":
                            inkast()
                        if (not motperson.spelare.skills.__contains__("dodge")) or person.spelare.skills.__contains__(
                                "tackle"):
                            if motperson.har_bollen and motperson.ruta == bollruta:
                                if ball_bounce() == "denfor":
                                    inkast()
                            motperson.har_bollen = False
                    if valt == "Defender down":
                        motperson.star = False
                        putten = putt(person, motperson, True)
                        if putten == "paboll":
                            if ball_bounce() == "denfor":
                                inkast()
                        if putten == "inkast":
                            inkast()
                        if motperson.har_bollen and motperson.ruta == bollruta:
                            if ball_bounce() == "denfor":
                                inkast()
                        motperson.har_bollen = False
                    if valt == "Putt":
                        putten = putt(person, motperson, True)
                        if putten == "paboll":
                            if ball_bounce() == "denfor":
                                inkast()
                        if putten == "inkast":
                            inkast()
                    if i_touch_down(person):
                        if tur != vem_star_har(person.ruta, True)[1]:
                            nasta_drag("Fixar...")
                        touch_down(vem_star_har(person.ruta, True)[1], person)
                    if i_touch_down(motperson):
                        if tur != vem_star_har(motperson.ruta, True)[1]:
                            nasta_drag("Fixar...")
                        touch_down(vem_star_har(motperson.ruta, True)[1], motperson)
                    return nastah

        rita(False)
        gameDisplay.blit(globals()[val1 + "bild"], (20, 20))
        if tva:
            gameDisplay.blit(globals()[val2 + "bild"], (100, 20))
        if tre:
            gameDisplay.blit(globals()[val3 + "bild"], (180, 20))
        skriv(gameDisplay, "Block mellan " + person.spelare.namn + " och " + motperson.spelare.namn + ".", (20, 65), 50)
        skriv(gameDisplay, text, (20, 140), 40)
        gameDisplay.blit(mus, pygame.mouse.get_pos())
        pygame.display.update()


def i_touch_down(person):
    if person.har_bollen:
        xh, yh = fa_pos(person.ruta)
        lagh = vem_star_har(person.ruta, True)[1]
        if lagh == 1:
            if xh == 0:
                return True
        else:
            if xh == 1125:
                return True
    return False


def touch_down(lag, person):
    splash_message(person.spelare.namn + " gjorde touch down!!!", (0, 255, 0), 2.0)
    globals()["td" + str(lag)] += 1
    nasta_drag("Ny drive")
    if tur == 1:
        set_up(2)
    else:
        set_up(1)


def ga(person, plush):
    global bollruta
    if person.star:
        xnu, ynu = fa_pos(person.ruta)
        pospluslista = [25, (-45, 45), 26, (0, 45), 27, (45, 45), -1, (-45, 0), 1, (45, 0), -27,
                        (-45, -45),
                        -26, (0, -45), -25, (45, -45)]
        xp, yp = pospluslista[pospluslista.index(plush) + 1]  # plusx, plusy
        if -1 < xnu + xp < 1169 and -1 < ynu + yp < 674:  # checkar så att man inte går av plan
            if gor_nagot(person, tur):
                if int(person.steg_kvar) > -2:
                    if vem_star_har(person.ruta + plush) is None:
                        if not person.har_blockat or person.ska_blitza:
                            dodgning = kanske_dodga(person, plush)
                            person.ruta += plush
                            if person.har_bollen:
                                bollruta += plush
                            person.steg_kvar -= 1
                            if dodgning != "fail":
                                if person.steg_kvar == -1 or person.steg_kvar == -2:
                                    if tarning(person.spelare.namn + " försöker ta ett extrasteg",
                                               "extrasteg") == 1:
                                        person.star = False
                                        if person.har_bollen or bollruta == person.ruta:
                                            if ball_bounce() == "denfor":
                                                inkast()
                                        person.har_bollen = False
                                        rita()
                                        pygame.display.update()
                                        nasta_drag("Turnover")
                                if person is not None:
                                    if person.star and person.ruta == bollruta and person.har_bollen is False:
                                        plock = pick_up(person)
                                        if plock == "denfor":
                                            inkast()
                                        if plock != "YEAH":
                                            nasta_drag("Turnover")
                            else:
                                person.star = False
                                if person.har_bollen or bollruta == person.ruta:
                                    if ball_bounce() == "denfor":
                                        inkast()
                                person.har_bollen = False
                                rita()
                                pygame.display.update()
                                nasta_drag("Turnover")
                    elif vem_star_har(person.ruta + plush).star and vem_star_har(person.ruta + plush,
                                                                                 True)[1] != tur:
                        if (person.steg_kvar == person.spelare.varden[0] or person.ska_blitza) and not \
                                person.har_blockat and not person.ska_passa and not person.ska_handoffa:
                            person.steg_kvar -= 1
                            if (person.steg_kvar == -1 or person.steg_kvar == -2) and tarning(
                                    person.spelare.namn + " försöker ta ett extrasteg för att blocka",
                                    "extrasteg") == 1:
                                person.star = False
                                person.har_bollen = False
                                if person.har_bollen or bollruta == person.ruta:
                                    if ball_bounce() == "denfor":
                                        inkast()
                                rita()
                                pygame.display.update()
                                nasta_drag("Turnover")
                            else:
                                nasta = blocka(person, vem_star_har(person.ruta + plush))
                                person.har_blockat = True
                                if not person.ska_blitza:
                                    person.fardig = True
                                if nasta:
                                    nasta_drag("Turnover")


def kanske_dodga(person, plush):
    if tackle_zones(person) > 0:
        zones = tackle_zones_ruta(person.ruta + plush, vem_star_har(person.ruta, True)[1])
        ag = person.spelare.varden[2]
        mer = aglist[ag]
        mer -= 1
        mer += zones
        slag = tarning(person.spelare.namn + " försöker dodga, med " + str(mer) + "+", "dodge")
        if (slag >= mer or slag == 6) and slag != 1:
            return "lyckad"
        else:
            return "fail"
    else:
        return "lyckad"


def har_blitzat(turh):
    blitzat = False
    if turh == 1:
        for vh in alla_spelare1:
            if vh.ska_blitza:
                blitzat = True
    else:
        for vh in alla_spelare2:
            if vh.ska_blitza:
                blitzat = True
    return blitzat


def har_passat(turh):
    passath = False
    if turh == 1:
        for vh in alla_spelare1:
            if vh.ska_passa:
                passath = True
    else:
        for vh in alla_spelare2:
            if vh.ska_passa:
                passath = True
    return passath


def har_handoffat(turh):
    passath = False
    if turh == 1:
        for vh in alla_spelare1:
            if vh.ska_handoffa:
                passath = True
    else:
        for vh in alla_spelare2:
            if vh.ska_handoffa:
                passath = True
    return passath


def ge_boll(turh):
    splash_message("Touchback! (bollen for ut)", (0, 255, 0), 2)
    global bollruta
    while True:
        for eventh in pygame.event.get():
            if eventh.type == pygame.MOUSEBUTTONDOWN:
                musposh = pygame.mouse.get_pos()
                rutanh = vilken_ruta(musposh)
                dar = vem_star_har(rutanh, True)
                if dar[0] is not None and dar[1] == turh:
                    bollruta = rutanh
                    vem_star_har(rutanh).har_bollen = True
                    return
        rita()
        musposh = pygame.mouse.get_pos()
        rutanh = vilken_ruta(musposh)
        dar = vem_star_har(rutanh, True)
        if dar[0] is not None and dar[1] == turh:
            gameDisplay.blit(globals()["Grön markörbild"], fa_pos(vilken_ruta(musposh)))
        else:
            gameDisplay.blit(globals()["Cancelbild"], fa_pos(vilken_ruta(musposh)))
        gameDisplay.blit(mus, musposh)
        pygame.display.update()


def pick_up(person):
    tebaks = "YEAH"
    ag = person.spelare.varden[2]
    mer = aglist[ag]
    mer -= 1
    numh = tarning(person.spelare.namn + " försöker ta upp bollen med " + str(mer + tackle_zones(person)) + "+",
                   "ta upp bollen")
    numhm = numh
    numhm -= tackle_zones(person)
    if (numhm >= mer and numh != 1 and numhm != 1) or numh == 6:
        person.har_bollen = True
    else:
        tebaks = ball_bounce()
    return tebaks


def set_up(vem_borjar):
    global bollruta, tur
    bollruta = 0
    klarknapp = knapp(gameDisplay, "Klar", (1200, 20), textfarg=(0, 255, 0))
    sparaknapp = knapp(gameDisplay, "Spara", (1200, 100), textfarg=(0, 100, 0))
    laddaknapp = knapp(gameDisplay, "Ladda", (1200, 150), textfarg=(0, 100, 0))
    for vh in alla_spelare1:
        vh.ruta = 1000
        vh.fardig = False
        vh.har_gjort = False
        vh.steg_kvar = vh.spelare.varden[0]
        vh.har_bollen = False
        vh.har_blockat = False
        vh.ska_blitza = False
        vh.ska_passa = False
        vh.star = True
        # rita(True)
        # pygame.display.update()
        # time.sleep(0.1)
    for vh in alla_spelare2:
        vh.ruta = 1000
        vh.fardig = False
        vh.har_gjort = False
        vh.steg_kvar = vh.spelare.varden[0]
        vh.har_bollen = False
        vh.har_blockat = False
        vh.ska_blitza = False
        vh.ska_passa = False
        vh.star = True
        # rita(True)
        # pygame.display.update()
        # time.sleep(0.1)
    nu = vem_borjar
    if nu == 1:
        nulagh = alla_spelare1
        coach = coach1
        tur = 2
    else:
        nulagh = alla_spelare2
        coach = coach2
        tur = 1
    utsatta = 0

    splash_message(coach + " börjar ställa upp.", (0, 255, 0))

    andra = False

    while True:
        for eventh in pygame.event.get():
            if eventh.type == pygame.QUIT:
                quit()
            if eventh.type == pygame.KEYDOWN:
                if pygame.key.get_pressed()[pygame.K_a]:
                    if nu == 2:
                        for vh in alla_spelare2:
                            vh.ruta = 1000
                        numh = 0
                        for vh in alla_spelare2:
                            vh.ruta = 64 + 26 * numh
                            numh += 1
                            if numh > 10:
                                break
                    if nu == 1:
                        for vh in alla_spelare1:
                            vh.ruta = 1000
                        numh = 0
                        for vh in alla_spelare1:
                            vh.ruta = 65 + 26 * numh
                            numh += 1
                            if numh > 10:
                                break
            if eventh.type == pygame.MOUSEBUTTONDOWN:
                musposh = pygame.mouse.get_pos()
                if klarknapp.ar_aktiv() and eventh.button == 1:
                    va = rakna_klar(nulagh, nu)
                    if va[0]:
                        if nu == 1:
                            nu = 2
                            nulagh = alla_spelare2
                            coach = coach2
                            if andra:
                                kick_off(2)
                                return
                            else:
                                andra = True
                        else:
                            nu = 1
                            nulagh = alla_spelare1
                            coach = coach1
                            if andra:
                                kick_off(1)
                                return
                            else:
                                andra = True
                        splash_message(vettigt_s(coach) + " tur att ställa upp.", (0, 255, 0))
                    else:
                        splash_message(va[1])
                elif sparaknapp.ar_aktiv() and eventh.button == 1:
                    # sparar en uppställning
                    try:
                        os.mkdir(".skapade lag/" + globals()["lag" + str(nu) + "namn"] + "/.setups")
                    except FileExistsError:
                        pass
                    filh = open(".skapade lag/" + globals()["lag" + str(nu) + "namn"] + "/.setups/" +
                                pygame_input(gameDisplay, "Vad ska uppställningen heta?"), "w")
                    skrivah = ""
                    for vh in nulagh:
                        skrivah += vh.spelare.namn + "=" + str(vh.ruta) + ","
                    filh.write(skrivah.strip(","))
                    filh.close()
                elif laddaknapp.ar_aktiv() and eventh.button == 1:
                    try:
                        filh = open(".skapade lag/" + globals()["lag" + str(nu) + "namn"] + "/.setups/" +
                                    pygame_input(gameDisplay, "Vad heter uppställningen?"), "r")
                        setuplist = filh.read().split(",")
                        filh.close()
                        for sh in setuplist:
                            n, r = sh.split("=")
                            for vh in nulagh:
                                if vh.spelare.namn == n:
                                    vh.ruta = int(r)
                    except FileNotFoundError:
                        pass
                else:
                    rutanh = vilken_ruta(musposh)
                    if vem_star_har(rutanh) is None:
                        if eventh.button == 1:
                            if utsatta < 11:
                                nagon = valj_person(nulagh)
                                if nagon is not None:
                                    nagon.ruta = rutanh
                            else:
                                splash_message("Du har redan 11 på plan!")
                    else:
                        person, lagtillhorighet = vem_star_har(rutanh, True)
                        if lagtillhorighet == nu:
                            if eventh.button == 1:
                                kor = True
                                while kor:
                                    for event2h in pygame.event.get():
                                        if event2h.type == pygame.MOUSEBUTTONDOWN:
                                            if event2h.button == 1:
                                                musposh = pygame.mouse.get_pos()
                                                if vem_star_har(vilken_ruta(musposh)) is None:
                                                    person.ruta = vilken_ruta(musposh)
                                                    kor = False
                                            if event2h.button == 3:
                                                kor = False
                                    rita(False)
                                    gameDisplay.blit(globals()["Cirkelvitbild"], fa_pos(rutanh))
                                    rita_stats(person)
                                    gameDisplay.blit(mus, pygame.mouse.get_pos())
                                    pygame.display.update()
                            elif eventh.button == 3:
                                person.ruta = 1000

        utsatta = 0
        for vh in nulagh:
            if vh.ruta != 1000:
                utsatta += 1

        rita(False)
        klarknapp.rita()
        sparaknapp.rita()
        laddaknapp.rita()

        musposh = pygame.mouse.get_pos()
        if klarknapp.ar_aktiv() or sparaknapp.ar_aktiv() or laddaknapp.ar_aktiv():
            gameDisplay.blit(pekmus, musposh)
        else:
            gameDisplay.blit(mus, musposh)

        pygame.display.update()


def kick_off(vemkickar):
    global aktiv
    aktiv = None
    global bollruta
    splash_message("Kick-off!", (0, 255, 0), 1.5)
    if vemkickar == 1:
        detandra = 2
    else:
        detandra = 1
    while True:
        for eventh in pygame.event.get():
            if eventh.type == pygame.MOUSEBUTTONDOWN:
                musposh = pygame.mouse.get_pos()
                if ((musposh[0] < 585 and vemkickar == 1) or (musposh[0] > 584 and vemkickar == 2)) and musposh[0] <= \
                        1170:
                    rutanh = vilken_ruta(musposh)
                    hall = random.randint(1, 8)
                    tarningsslag.append("T8 (kick-scatter): " + str(hall))
                    plush = listahall[hall - 1]
                    hur_manga = random.randint(1, 6)
                    tarningsslag.append("T6 (kick-längd): " + str(hur_manga))
                    bollruta = rutanh
                    denfor = False
                    for _ in range(0, hur_manga):
                        if far_bollen_ut(plush, True, detandra):
                            bollruta += plush
                            denfor = True
                            ge_boll(detandra)
                            break
                        else:
                            bollruta += plush
                    if denfor is False:
                        if vem_star_har(bollruta) is not None:
                            if vem_star_har(bollruta).star is True:
                                if fanga(sidbry=detandra) == "denfor":
                                    ge_boll(detandra)
                            else:
                                if ball_bounce(detandra) == "denfor":
                                    ge_boll(detandra)
                        elif ball_bounce(detandra) == "denfor":
                            ge_boll(detandra)
                    return
        rita(False)
        musposh = pygame.mouse.get_pos()
        if ((musposh[0] < 585 and vemkickar == 1) or (musposh[0] > 584 and vemkickar == 2)) and musposh[0] <= 1170:
            gameDisplay.blit(globals()["Grön markörbild"], fa_pos(vilken_ruta(musposh)))
        else:
            gameDisplay.blit(globals()["Cancelbild"], fa_pos(vilken_ruta(musposh)))
        gameDisplay.blit(mus, musposh)

        pygame.display.update()


aktiv = None
info = None
tur = 1
td1, td2 = 0, 0
drag = 1

if not matchen:
    bollruta = 0
    passat, handoffat = False, False

    borjar = random.randint(1, 2)
    set_up(borjar)
    if borjar == 1:
        tur = 2
    else:
        tur = 1

else:
    ladda_match()

dragklarknapp = knapp(gameDisplay, "Nästa drag", (1180, 10), 45, (0, 255, 0))

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quit()
        if event.type == pygame.MOUSEBUTTONDOWN:
            if dragklarknapp.ar_aktiv():
                nasta_drag("Nästa drag")
            else:
                if event.button == 1:
                    muspos = pygame.mouse.get_pos()
                    rutan = vilken_ruta(muspos)
                    stardar = vem_star_har(rutan, True)
                    if stardar[0] is not None and stardar[1] == tur:
                        aktiv = stardar[0]
                        info = None
                    elif stardar[0] is not None:
                        info = stardar[0]
                        aktiv = None
                    else:
                        aktiv = None
                        info = None
                elif event.button == 3:
                    muspos = pygame.mouse.get_pos()
                    rutan = vilken_ruta(muspos)
                    if aktiv is not None:
                        if rutan == aktiv.ruta:
                            hogerklick(aktiv)
        if event.type == pygame.KEYDOWN:
            key = pygame.key.get_pressed()
            if key[pygame.K_k]:
                set_up(1)
            if key[pygame.K_t]:
                for v in tarningsslag:
                    print(v)
            if (key[pygame.K_RCTRL] or key[pygame.K_LCTRL]) and key[pygame.K_s]:
                spara_match()
            if aktiv is not None:
                if key[pygame.K_SPACE]:
                    if aktiv.star is False:
                        if gor_nagot(aktiv, tur):
                            if aktiv.steg_kvar > 2:
                                aktiv.star = True
                                aktiv.steg_kvar -= 3
                            else:
                                if tarning(aktiv.spelare.namn + " försöker ställa sig upp, 4+", "resa sig") > 3:
                                    aktiv.star = True
                                    aktiv.steg_kvar -= 3
                                else:
                                    aktiv.fardig = True
                plus = 0
                if key[pygame.K_l]:
                    aktiv.star = False
                if key[pygame.K_KP1]:
                    plus = 25
                if key[pygame.K_KP2]:
                    plus = 26
                if key[pygame.K_KP3]:
                    plus = 27
                if key[pygame.K_KP4]:
                    plus = -1
                if key[pygame.K_KP6]:
                    plus = 1
                if key[pygame.K_KP7]:
                    plus = -27
                if key[pygame.K_KP8]:
                    plus = -26
                if key[pygame.K_KP9]:
                    plus = -25
                if plus:
                    ga(aktiv, plus)

    # kollar om någon står i touch down, och om det är den andras drag så gör den nasta_drag() för
    # att det inte ska bli fel med vem som ställer upp å sånt
    for v in alla_spelare1:
        if i_touch_down(v):
            if tur != 1:
                nasta_drag("Fixar...")
            touch_down(1, v)
    for v in alla_spelare2:
        if i_touch_down(v):
            if tur != 2:
                nasta_drag("Fixar...")
            touch_down(2, v)

    rita(False)
    if aktiv is not None:
        if aktiv.fardig is True:
            gameDisplay.blit(globals()["Cirkelrödbild"], fa_pos(aktiv.ruta))
        elif aktiv.star is False:
            gameDisplay.blit(globals()["Cirkelgulbild"], fa_pos(aktiv.ruta))
        else:
            gameDisplay.blit(globals()["Cirkelvitbild"], fa_pos(aktiv.ruta))
        rita_stats(aktiv, True)
    if info is not None:
        gameDisplay.blit(globals()["Cirkelgråbild"], fa_pos(info.ruta))
        rita_stats(info)

    skriv(gameDisplay, vettigt_s(globals()["coach" + str(tur)]) + " drag", (1175, 60), 30, (255, 0, 0))

    # skriver ställningen i matchen
    vu1 = " till"
    if td1 == td2:
        vu1 = ""
    skriv(gameDisplay, "Det står " + str(td1) + " – " + str(td2) + vu1, (1175, 100), 25, (255, 100, 20))
    if not td1 == td2:
        if td1 > td2:
            vu2 = "1"
        else:
            vu2 = "2"
        skriv(gameDisplay, globals()["lag" + str(vu2) + "namn"], (1175, 125), 25, (255, 100, 20))
    #
    skriv(gameDisplay, "Drag: " + str(drag), (1175, 150), 25, (8, 76, 54))

    dragklarknapp.rita()

    num = -10
    for yu in range(410, 660, 25):
        try:
            if tarningsslag[num].split(": ")[0] == "Block":
                skriv(gameDisplay, "Block:", (1180, yu), 20)
                valu = int(tarningsslag[num].split(": ")[2])
                xu = 1250
                num2 = 0
                for v in tarningsslag[num].split(": ")[1].split(", "):
                    if num2 == valu:
                        pygame.draw.rect(gameDisplay, (0, 255, 50), (xu - 2, yu - 7, 24, 24))
                        gameDisplay.blit(globals()[v + "litenbild"], (xu, yu - 5))
                    else:
                        gameDisplay.blit(globals()[v + "litenbild"], (xu, yu - 5))
                    xu += 30
                    num2 += 1
            else:
                skriv(gameDisplay, tarningsslag[num], (1180, yu), 20)
        except IndexError:
            pass
        num += 1

    muspos = pygame.mouse.get_pos()
    if dragklarknapp.ar_aktiv():
        gameDisplay.blit(pekmus, muspos)
    else:
        gameDisplay.blit(mus, muspos)
    pygame.display.update()
