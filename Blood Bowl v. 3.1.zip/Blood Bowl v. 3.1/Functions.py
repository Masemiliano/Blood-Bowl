import random

import pygame.mouse

import math

from math import atan2, degrees


def ta_bort_farg(bild, farg=(0, 0, 0)):
    import pygame
    x, y = bild.get_size()
    ny = pygame.Surface((x, y))
    for vy in range(0, y):
        for vx in range(0, x):
            ett, tva, tre, fyra = bild.get_at((vx, vy))
            print(ett)
            if ett == farg[0] and tva == farg[1] and tre == farg[2]:
                ny.set_at((vx, vy), (ett, tva, tre + 1))
            else:
                ny.set_at((vx, vy), (ett, tva, tre))

    return ny


def gor_bild_svartvit(bild):
    import pygame
    x, y = bild.get_size()

    ny = pygame.Surface((x, y))

    for vy in range(0, y):
        print(vy)
        for vx in range(0, x):
            ett, tva, tre, fyra = bild.get_at((vx, vy))
            enavde = (ett + tva + tre) / 3
            nyfarg = (enavde, enavde, enavde)
            ny.set_at((vx, vy), nyfarg)

    return ny


def skriv(surface, text, pos=(0, 0), storlek=30, farg=(0, 0, 0), fetstil=False):
    display = surface
    import pygame
    font = pygame.font.SysFont("", storlek, fetstil)
    bildh = font.render(text, True, farg)
    display.blit(bildh, pos)


def get_textwidth(text, storlek):
    import pygame
    font = pygame.font.SysFont("", storlek)
    s = font.render(text, True, (0, 0, 0))
    tx, ty = s.get_size()
    return tx


def pygame_input(surface, text, redan="", helskarm=True, rutplats=(0, 0), mussur=None):
    display = surface
    import pygame
    pyper = True
    try:
        import pyperclip
    except ModuleNotFoundError:
        pyper = False
    xh, yh = rutplats
    inputtat = redan
    plats = len(inputtat)
    forebild = pygame.Surface((1200, 620))
    forebild.blit(display, (0, 0))
    while True:
        if helskarm:
            display.fill((54, 100, 132))
        else:
            display.blit(forebild, (0, 0))
            pygame.draw.rect(display, (255, 255, 255), (xh, yh, get_textwidth(inputtat, 40), 40))
        skriv(display, text, (30, 30), 75)
        ev = pygame.event.poll()
        if ev.type == pygame.QUIT:
            pygame.quit()
            quit()
        if ev.type == pygame.KEYDOWN:
            keysh = pygame.key.get_pressed()
            if keysh[pygame.K_LEFT]:
                plats -= 1
                if plats < 0:
                    plats = 0
            if keysh[pygame.K_RIGHT]:
                plats += 1
                if plats > len(inputtat):
                    plats = len(inputtat)
            keyh = pygame.key.name(ev.key)
            klippt = False
            if keysh[pygame.K_LCTRL] or keysh[pygame.K_RCTRL]:
                if keysh[pygame.K_v] and pyper:
                    keyh = pyperclip.paste()
                    klippt = True
            shift = keysh[pygame.K_LSHIFT]
            if not shift:
                shift = keysh[pygame.K_RSHIFT]
            altgr = keysh[pygame.K_RCTRL]
            if not altgr:
                altgr = keysh[pygame.K_LCTRL]
            if keyh == "backspace":
                pa = -1
            elif keyh == "space":
                pa = " "
            elif keyh == "return":
                return inputtat
            else:
                if len(keyh) == 1:
                    if shift:
                        keyh = keyh.upper()
                        if keyh == "-":
                            keyh = "_"
                        elif keyh == "1":
                            keyh = "!"
                        elif keyh == "+":
                            keyh = "?"
                        elif keyh == "8":
                            keyh = "("
                        elif keyh == "9":
                            keyh = ")"
                        elif keyh == "3":
                            keyh = "#"
                        elif keyh == "0":
                            keyh = "="
                        elif keyh == "2":
                            keyh = '"'
                        elif keyh == "4":
                            keyh = "¤"
                        elif keyh == "5":
                            keyh = "%"
                        elif keyh == "'":
                            keyh = "*"
                        elif keyh == "6":
                            keyh = "&"
                        elif keyh == ".":
                            keyh = ":"
                        elif keyh == ",":
                            keyh = ";"
                        elif keyh == "<":
                            keyh = ">"
                        elif keyh == "7":
                            keyh = "/"
                    if altgr:
                        if keyh == "U":
                            keyh = "Ü"
                        if keyh == "u":
                            keyh = "ü"
                    pa = keyh
                else:
                    if klippt is False:
                        pa = ""
                    else:
                        pa = keyh

            if pa != "":
                inputtatny = ""
                numh = 0
                for vh in inputtat + "#":
                    if plats == numh:
                        if pa == -1:
                            inputtatny = inputtatny[:-1]
                        else:
                            inputtatny += pa
                    inputtatny += vh
                    numh += 1
                inputtat = inputtatny[:-1]
                if pa == -1:
                    plats -= 1
                    if plats < 0:
                        plats = 0
                else:
                    plats += 1
        if helskarm:
            skriv(display, inputtat, (10, 300), 40)
            pygame.draw.line(display, (0, 0, 0), (10 + get_textwidth(inputtat[:plats], 40), 300),
                             (10 + get_textwidth(inputtat[:plats], 40), 330))
        else:
            skriv(display, inputtat, rutplats, 40)
            pygame.draw.line(display, (0, 0, 0), (xh + get_textwidth(inputtat[:plats], 40), yh),
                             (xh + get_textwidth(inputtat[:plats], 40), yh + 30))
        if mussur:
            surface.blit(mussur, pygame.mouse.get_pos())
        pygame.display.update()


def get_textsize(text, storlek):
    import pygame
    font = pygame.font.SysFont("", storlek)
    s = font.render(text, True, (0, 0, 0))
    tx, ty = s.get_size()
    return tx, ty


def fa_pos(ruta):
    x = (ruta % 26) * 45
    y = int(ruta / 26) * 45
    if ruta > -1:
        return x, y
    else:
        return x, -45


def vilken_ruta(pos):
    musx, musy = pos
    xrund, yrund = int(musx / 45), int(musy / 45)
    return yrund * 26 + xrund


def stor_forsta_bokstav(string):
    tebaks = ""
    numh = 0
    for vh in string:
        if numh == 0:
            tebaks += vh.upper()
        else:
            tebaks += vh
        numh += 1
    return tebaks


def kolla_langden(ruta, sikte):
    x1, y1 = fa_pos(ruta)
    x2, y2 = fa_pos(sikte)
    mellanx = x1 - x2
    if str(mellanx).find("-") != -1:
        mellanx = -mellanx
    mellanrutor = round(mellanx / 45)
    mellany = y1 - y2
    if str(mellany).find("-") != -1:
        mellany = -mellany
    hoejdrutor = round(mellany / 45)

    langd = ""

    if hoejdrutor == 13:
        if mellanrutor < 2:
            langd = "bomb"
    if hoejdrutor == 12:
        if mellanrutor < 5:
            langd = "bomb"
    if hoejdrutor == 11:
        if mellanrutor < 7:
            langd = "bomb"
    if hoejdrutor == 10:
        if mellanrutor < 3:
            langd = "long"
        elif mellanrutor < 9:
            langd = "bomb"
    if hoejdrutor == 9:
        if mellanrutor < 5:
            langd = "long"
        elif mellanrutor < 10:
            langd = "bomb"
    if hoejdrutor == 8:
        if mellanrutor < 7:
            langd = "long"
        elif mellanrutor < 11:
            langd = "bomb"
    if hoejdrutor == 7:
        if mellanrutor < 8:
            langd = "long"
        elif mellanrutor < 11:
            langd = "bomb"
    if hoejdrutor == 6:
        if mellanrutor < 4:
            langd = "short"
        elif mellanrutor < 9:
            langd = "long"
        elif mellanrutor < 12:
            langd = "bomb"
    if hoejdrutor == 5:
        if mellanrutor < 5:
            langd = "short"
        elif mellanrutor < 9:
            langd = "long"
        elif mellanrutor < 12:
            langd = "bomb"
    if hoejdrutor == 4:
        if mellanrutor < 6:
            langd = "short"
        elif mellanrutor < 10:
            langd = "long"
        elif mellanrutor < 13:
            langd = "bomb"
    if hoejdrutor == 3:
        if mellanrutor < 2:
            langd = "quick"
        elif mellanrutor < 7:
            langd = "short"
        elif mellanrutor < 10:
            langd = "long"
        elif mellanrutor < 13:
            langd = "bomb"
    if hoejdrutor == 2:
        if mellanrutor < 3:
            langd = "quick"
        elif mellanrutor < 7:
            langd = "short"
        elif mellanrutor < 11:
            langd = "long"
        elif mellanrutor < 13:
            langd = "bomb"
    if hoejdrutor == 1:
        if mellanrutor < 4:
            langd = "quick"
        elif mellanrutor < 7:
            langd = "short"
        elif mellanrutor < 11:
            langd = "long"
        elif mellanrutor < 14:
            langd = "bomb"
    if hoejdrutor == 0:
        if mellanrutor < 4:
            langd = "quick"
        elif mellanrutor < 7:
            langd = "short"
        elif mellanrutor < 11:
            langd = "long"
        elif mellanrutor < 14:
            langd = "bomb"
    # if vader == 12 and (langd == "bomb" or langd == "long"):
    #    langd = ""
    return langd


def get_angle(point_1, point_2, computer_coords=True):  # These can also be four parameters instead of two arrays
    if computer_coords:
        point_1 = (point_1[0], -point_1[1])
        point_2 = (point_2[0], -point_2[1])

    angle = atan2(point_1[1] - point_2[1], point_1[0] - point_2[0])

    angle = degrees(angle)


    if angle < 0:
        angle = 360 + angle

    angle -= 270

    if angle < 0:
        angle = -angle

    return angle


def interceptrutor(ruta1, ruta2):  # använder trigonometriska funktioner och sådant coolt, men på många ställen är det nog
    # konstigt och dåligt implementerat. Skit i det och var glad att det fungerar
    streckpositioner = []

    nordvast = [(22, 22, 22, 22)]
    nordost = [(22, 22, 22, 22)]
    sydvast = [(22, 22, 22, 22)]
    sydost = [(22, 22, 22, 22)]
    nord = ((22, 22, 22, 22), (-22, -1, -22, 46), (67, -1, 67, 46))
    syd = ((22, 22, 22, 22), (-22, 46, -22, -1), (67, 46, 67, -1))
    vast = ((22, 22, 22, 22), (-1, -22, 46, -22), (-1, 67, 46, 67))
    ost = ((22, 22, 22, 22), (46, -22, -1, -22), (46, 67, -1, 67))

    p1 = fa_pos(ruta1)
    p1 = (p1[0] + 22, p1[1] + 22)
    p2 = fa_pos(ruta2)
    p2 = (p2[0] + 22, p2[1] + 22)

    avstand1 = p2[0] - p1[0]
    avstand2 = p2[1] - p1[1]

    if avstand2 == 0:
        nordsyd = 0
    else:
        nordsyd = avstand2 / abs(avstand2)
    if avstand1 == 0:
        vastost = 0
    else:
        vastost = avstand1 / abs(avstand1)

    bestamt = None

    if nordsyd > 0:
        if vastost > 0:
            bestamt = sydost
        elif vastost < 0:
            bestamt = sydvast
        else:
            bestamt = syd
    elif nordsyd < 0:
        if vastost > 0:
            bestamt = nordost
        elif vastost < 0:
            bestamt = nordvast
        else:
            bestamt = nord
    elif vastost > 0:
        bestamt = ost
    elif vastost < 0:
        bestamt = vast

    forst = True
    for plus in bestamt:
        stpoh = []  # streckpostitionerhär

        # p1 och p2 är positionen i mitten av rutorna, i pixlar
        p1 = fa_pos(ruta1)
        p1 = (p1[0] + plus[0], p1[1] + plus[1])
        p2 = fa_pos(ruta2)
        p2 = (p2[0] + plus[2], p2[1] + plus[3])

        # kollar avståndet mellan rutornas mitt, både höjd-avståndet och längd-avståndet (i pixlar)
        distance1 = abs(p1[0] - p2[0])
        distance2 = abs(p1[1] - p2[1])

        # dessa håller reda på hur linjen dras. Om båda är ett, så ökar den ena med ett när den andra gör det
        forhallande1 = 0.2
        forhallande2 = 0.2

        if bestamt == vast or bestamt == ost or bestamt == nord or bestamt == syd:
            forhallande1, forhallande2 = 2, 2

        # här kollar den hur många pixlar den ena ska röra sig när den andra rör sig en pixel. Om ingen av avstånden är
        # större så blir det såklart 1:1 som definierat ovanför
        if distance1 == 0:
            forhallande1 = 0
        if distance2 == 0:
            forhallande2 = 0

        if not (distance1 == 0 or distance2 == 0):
            if distance1 > distance2:
                forhallande1 = distance1 / distance2 / 5
            if distance2 > distance1:
                forhallande2 = distance2 / distance1 / 5

        # avstånden och förhållandena är alltid positiva, så här fixar den så att de blir negativa om de ska vara det
        if p1[0] > p2[0]:
            forhallande1 *= -1
        if p1[1] > p2[1]:
            forhallande2 *= -1

        nu1, nu2 = p1[0], p1[1]

        while True:
            if abs(ruta1 - ruta2) == 1 or abs(ruta1 - ruta2) == 26:
                break
            else:
                nu1 += forhallande1
                nu2 += forhallande2

                stpoh.append((nu1, nu2))

                if forhallande1 > 0:
                    if int(nu1) >= p2[0]:
                        break
                elif forhallande1 < 0:
                    if int(nu1) <= p2[0]:
                        break
                if forhallande2 > 0:
                    if int(nu2) >= p2[1]:
                        break
                elif forhallande2 < 0:
                    if int(nu2) <= p2[1]:
                        break

        if forst and bestamt != vast and bestamt != ost and bestamt != nord and bestamt != syd:
            streckpositioner.extend(stpoh)

            forst = False

            vinkelh = get_angle(streckpositioner[0], streckpositioner[-1])

            vinkelh += 90

            skillnadh = abs(vinkelh - 180)

            nerh = math.cos(math.radians(skillnadh)) * 39.5

            hogerh = math.sin(math.radians(skillnadh)) * 39.5

            nerh = abs(int(nerh))
            hogerh = abs(int(hogerh))

            if bestamt == nordost:
                nordost.append((22 + hogerh, 22 + nerh, 22 + hogerh, 22 + nerh))
                nordost.append((22 - hogerh, 22 - nerh, 22 - hogerh, 22 - nerh))
            if bestamt == sydost:
                sydost.append((22 - hogerh, 22 + nerh, 22 - hogerh, 22 + nerh))
                sydost.append((22 + hogerh, 22 - nerh, 22 + hogerh, 22 - nerh))
            if bestamt == sydvast:
                sydvast.append((22 + hogerh, 22 + nerh, 22 + hogerh, 22 + nerh))
                sydvast.append((22 - hogerh, 22 - nerh, 22 - hogerh, 22 - nerh))
            if bestamt == nordvast:
                nordvast.append((22 + hogerh, 22 - nerh, 22 + hogerh, 22 - nerh))
                nordvast.append((22 - hogerh, 22 + nerh, 22 - hogerh, 22 + nerh))
        elif bestamt != vast and bestamt != ost and bestamt != nord and bestamt != syd:
            length = 0
            first = True

            rutskillnad = abs(ruta1 - ruta2)

            # 28, 24, 51 och 53 är special och måste anpassas, linjalen måste vara kortare

            while True:
                pos = stpoh.pop(0)
                stpoh.pop(-1)

                if not first:
                    length += math.dist(pos, sparpos)
                first = False

                sparpos = pos

                if length > 30 or (rutskillnad not in (24, 28, 51, 53) and length > 16):
                    break

            streckpositioner.extend(stpoh)
        else:
            streckpositioner.extend(stpoh)

    nyasp = []  # nyastreckpositioner
    for vh in streckpositioner:
        dennarutan = vilken_ruta(vh)
        if not nyasp.__contains__(vh):
            if dennarutan != ruta1 and dennarutan != ruta2:
                nyasp.append(dennarutan)

    return nyasp


def casualty(person, tarningsslag):
    skadah = "badly hurt"
    e, t = random.randint(1, 6), random.randint(1, 8)
    slag3 = int(str(e) + str(t))
    tarningsslag.append("T6T8 ('" + person.spelare.namn + "' casualty-tabellen): " + str(slag3))

    va = person.spelare.varden

    if e == 6:
        skadah = "död"
    elif e == 5:
        if t == 1 or t == 2:
            skadah = "niggling injury"
        elif t == 3 or t == 4:
            skadah = "-1 MA"
        elif t == 5 or t == 6:
            skadah = "-1 AV"
        elif t == 7:
            skadah = "-1 AG"
        elif t == 8:
            skadah = "-1 ST"
    elif e == 4:
        skadah = "miss next game"

    return skadah


def vettigt_s(string):
    if string[-1].lower() in ["x", "s", "z"]:
        return string
    else:
        return string + "s"


def fraga(surface, fragan, mus, pekmus, enterarforsta=False):
    jaknapp, nejknapp = knapp(surface, "Ja", (10, 70), 40), knapp(surface, "Nej", (10, 120), 40)
    alltsur = surface.copy()
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                quit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if jaknapp.ar_aktiv():
                    return True
                elif nejknapp.ar_aktiv():
                    return False
            if enterarforsta and event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    return True
        surface.blit(alltsur, (0, 0))
        skriv(surface, fragan, (10, 10), 50)
        jaknapp.rita()
        nejknapp.rita()
        if jaknapp.ar_aktiv() or nejknapp.ar_aktiv():
            surface.blit(pekmus, pygame.mouse.get_pos())
        else:
            surface.blit(mus, pygame.mouse.get_pos())
        pygame.display.update()


def anvanda_skill(surface, skill, alltsur, namn, mus, pekmus):
    jaknapp, nejknapp = knapp(surface, "Ja", (10, 70), 40), knapp(surface, "Nej", (10, 120), 40)
    while True:
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if jaknapp.ar_aktiv():
                    return True
                elif nejknapp.ar_aktiv():
                    return False
        surface.blit(alltsur, (0, 0))
        skriv(surface, "Vill " + namn + " använda " + skill + "?", (10, 10), 50)
        jaknapp.rita()
        nejknapp.rita()
        if jaknapp.ar_aktiv() or nejknapp.ar_aktiv():
            surface.blit(pekmus, pygame.mouse.get_pos())
        else:
            surface.blit(mus, pygame.mouse.get_pos())
        pygame.display.update()


def tvartom_ruta(ruta):
    paraden = ruta % 26
    if paraden - 13 >= 0:
        franmitten = paraden - 13
    else:
        franmitten = 13 - paraden
    if paraden > 12:
        ret = ruta - (franmitten * 2) - 1
    else:
        ret = ruta + (franmitten * 2) - 1
    return ret


def far_bollen_ut(bollruta, plush, bry_om_sida=False, sida=1):
    nux, nuy = fa_pos(bollruta)
    pospluslistah = [25, (-45, 45), 26, (0, 45), 27, (45, 45), -1, (-45, 0), 1, (45, 0), -27, (-45, -45),
                     -26, (0, -45), -25, (45, -45)]
    ppos = pospluslistah[pospluslistah.index(plush) + 1]
    if bry_om_sida:
        if (fa_pos(bollruta)[0] + ppos[0] < 585 and sida == 1) or (fa_pos(bollruta)[0] + ppos[0] > 584 and sida == 2):
            return True
    if -1 < nux + ppos[0] < 1169 and -1 < nuy + ppos[1] < 674:
        return False
    else:
        return True


def far_spelaren_ut(person, plush, bry_om_sida=False, sida=1):
    nux, nuy = fa_pos(person.ruta)
    pospluslistah = [25, (-45, 45), 26, (0, 45), 27, (45, 45), -1, (-45, 0), 1, (45, 0), -27, (-45, -45),
                     -26, (0, -45), -25, (45, -45)]
    ppos = pospluslistah[pospluslistah.index(plush) + 1]
    if bry_om_sida:
        if (nux + ppos[0] < 585 and sida == 1) or (nux + ppos[0] > 584 and sida == 2):
            return True
    if -1 < nux + ppos[0] < 1169 and -1 < nuy + ppos[1] < 674:
        return False
    else:
        return True


def far_nagot_ut(ruta, plush, bry_om_sida=False, sida=1):
    nux, nuy = fa_pos(ruta)
    pospluslistah = [25, (-45, 45), 26, (0, 45), 27, (45, 45), -1, (-45, 0), 1, (45, 0), -27, (-45, -45),
                     -26, (0, -45), -25, (45, -45)]
    ppos = pospluslistah[pospluslistah.index(plush) + 1]
    if bry_om_sida:
        if (nux + ppos[0] < 585 and sida == 1) or (nux + ppos[0] > 584 and sida == 2):
            return True
    if -1 < nux + ppos[0] < 1169 and -1 < nuy + ppos[1] < 674:
        return False
    else:
        return True


class knapp:
    def __init__(self, surface, text, pos=(0, 0), storlek=50, textfarg=(0, 0, 0)):
        self.text = text
        self.pos = pos
        self.storlek = storlek
        self.vidd = 0
        self.hoejd = 0
        self.farg = textfarg
        self.surface = surface

    def ar_aktiv(self):
        import pygame
        musx, musy = pygame.mouse.get_pos()
        self.vidd, self.hoejd = get_textsize(self.text, self.storlek)
        if self.pos[0] + self.vidd > musx > self.pos[0] and self.pos[1] < musy < self.pos[1] + self.hoejd:
            return True
        return False

    def rita(self):
        skriv(self.surface, self.text, self.pos, self.storlek, self.farg)


class BreakOut(Exception):
    pass


class spelare:
    def __init__(self, namn="name", typ="Orch_blitzer", varden=(6, 3, 3, 9), pengavarde=80000, skills=None,
                 skadad="", nig=0):
        if skills is None:
            skills = ""
        self.namn, self.typ, self.varden, self.pengavarde, self.skills, self.skadad = namn, typ, varden, pengavarde, skills, skadad
        self.nig = nig
        self.spp = 0
        self.level = 0
        self.touchdowns = 0
        self.passar = 0
        self.casualties = 0
        self.interceptions = 0
        self.mvps = 0


class spelareimatch:
    def __init__(self, spelaren):
        self.spelare = spelaren
        self.ruta = 1000
        self.star = True
        self.tacklezone = True
        self.skadad = ""
        self.har_gjort = False
        self.fardig = False
        self.steg_kvar = self.spelare.varden[0]
        self.har_bollen = False
        self.har_blitzat = False
        self.har_blockat = False
        self.ska_blitza = False
        self.ska_passa = False
        self.ska_handoffa = False
        self.fastvaxt = False
        self.ska_foula = False
        self.nerehall = 0
        for s in self.spelare.skills:
            if s in ["dodge", "pass", "sure feet", "sure hands", "catch", "pro", "break tackle", "leap"]:
                s = s.replace(" ", "_").replace("-", "")
                exec("self." + s + "anvant = False")
