import ctypes
import os
import pickle
import time

import pygame

from Functions import *

pygame.init()

riktigapixlar = False
fil = open(".hemliga inställningar/Riktiga pixlar", "r", encoding="utf-8")
if fil.read().lower().__contains__("true"):
    riktigapixlar = True
fil.close()

if riktigapixlar:
    try:
        ctypes.windll.user32.SetProcessDPIAware()  # detta gör så att pixlar faktiskt är pixlar i pygame
    except AttributeError:
        print("Du har riktia pixlar på, men den inställningen fungerar inte på din plattform.")

vidd, hoejd = 1170, 675

gameDisplay = pygame.display.set_mode((vidd, hoejd))

mus = pygame.image.load(".bilder/.markörer/Mus.png")
pekmus = pygame.image.load(".bilder/.markörer/Pekmus.png")

pygame.mouse.set_visible(False)

raser = ["skogsalver", "orcher", "ogres", "lizardmen", "hobbitar", "odöda", "norse", "chaos", "goblins",
         "människor"]


def team_data(ras):
    filh = open(".lag/" + stor_forsta_bokstav(ras) + "/Kostnader", encoding="utf-8")
    kostnader = filh.read().strip().split("/")
    filh.close()
    filh = open(".lag/" + stor_forsta_bokstav(ras) + "/Maximalt", encoding="utf-8")
    maximalt = filh.read().strip().split("/")
    filh.close()
    filh = open(".lag/" + stor_forsta_bokstav(ras) + "/Personer", encoding="utf-8")
    personer = filh.read().strip().split("/")
    filh.close()
    filh = open(".lag/" + stor_forsta_bokstav(ras) + "/Skills", encoding="utf-8")
    skills = filh.read().strip().split("/")
    filh.close()
    filh = open(".lag/" + stor_forsta_bokstav(ras) + "/Värden", encoding="utf-8")
    varden = filh.read().strip().split("/")
    filh.close()
    return kostnader, maximalt, personer, skills, varden


def spara_lag(hela_laget, lagnamn, ras, pengar, apo, rerolls):
    filh = open(".skapade lag/" + lagnamn + "/Ras", "w", encoding="utf-8")
    filh.write(ras)
    filh.close()
    filh = open(".skapade lag/" + lagnamn + "/Pengar", "w", encoding="utf-8")
    filh.write(str(pengar))
    filh.close()
    filh = open(".skapade lag/" + lagnamn + "/Apo", "w", encoding="utf-8")
    filh.write(str(apo))
    filh.close()
    filh = open(".skapade lag/" + lagnamn + "/RR", "w", encoding="utf-8")
    filh.write(str(rerolls))
    filh.close()
    for vh in hela_laget:
        #vh.touchdowns = 0
        #vh.passar = 0
        #vh.casualties = 0
        #vh.interceptions = 0
        #vh.mvps = 0
        filh = open(".skapade lag/" + lagnamn + "/.spelare/" + vh.namn, "wb")
        pickle.dump(vh, filh)
        filh.close()


def fa_skill(person, ras, typ, personer):
    for v in os.listdir(".bilder/.tarningar/"):
        v2 = v.replace(".png", "")
        globals()[v2 + "bild"] = pygame.image.load(".bilder/.tarningar/" + v)
    filh = open(".skills/General", "r", encoding="utf-8")
    gskills = filh.read().strip().split("\n")
    filh.close()
    filh = open(".skills/Agility", "r", encoding="utf-8")
    askills = filh.read().strip().split("\n")
    filh.close()
    filh = open(".skills/Strength", "r", encoding="utf-8")
    sskills = filh.read().strip().split("\n")
    filh.close()
    filh = open(".skills/Mutation", "r", encoding="utf-8")
    mskills = filh.read().strip().split("\n")
    filh.close()
    filh = open(".skills/Passing", "r", encoding="utf-8")
    pskills = filh.read().strip().split("\n")
    filh.close()

    filh = open(".lag/" + stor_forsta_bokstav(ras) + "/" + "Fåskills", "r", encoding="utf-8")
    vilkaskills = filh.read().strip().split("/")[personer.index(typ)].split(",")
    filh.close()

    e, t = random.randint(1, 6), random.randint(1, 6)

    totalt = e + t

    yh = 160
    xh = 100
    for vuh in vilkaskills[0]:
        for vh in locals()[vuh.lower() + "skills"]:
            if not person.skills.__contains__(vh):
                if not (vh == "grab" and person.skills.__contains__("frenzy")) and not \
                        (vh == "frenzy" and person.skills.__contains__("grab")):
                    locals()[vh + "knapp"] = knapp(gameDisplay, vh, (xh, yh), 30)
                    yh += 30
                    if yh > 600:
                        yh = 160
                        xh += 170
    if e == t:
        for vuh in vilkaskills[1]:
            for vh in locals()[vuh.lower() + "skills"]:
                if not person.skills.__contains__(vh):
                    if not (vh == "grab" and person.skills.__contains__("frenzy")) and not \
                            (vh == "frenzy" and person.skills.__contains__("grab")):
                        locals()[vh + "knapp"] = knapp(gameDisplay, vh, (xh, yh), 30)
                        yh += 30
                        if yh > 600:
                            yh = 160
                            xh += 170
    annat = []
    if totalt == 12:
        annat.append("+1 ST")
    if totalt == 11:
        annat.append("+1 AG")
    if totalt == 10:
        annat.append("+1 AV")
        annat.append("+1 MA")

    for vh in annat:
        locals()[vh + "knapp"] = knapp(gameDisplay, vh, (xh, yh), 30)
        yh += 30
        if yh > 600:
            yh = 160
            xh += 170

    skriv(gameDisplay, person.namn + " slår om en egenskap.", (10, 10), 50)
    gameDisplay.fill((255, 255, 255))
    gameDisplay.blit(globals()["Tärning" + str(e) + "bild"], (100, 100))
    gameDisplay.blit(globals()["Tärning" + str(t) + "bild"], (200, 100))
    for vuh in vilkaskills[0]:
        for vh in locals()[vuh.lower() + "skills"]:
            if not person.skills.__contains__(vh):
                if not (vh == "grab" and person.skills.__contains__("frenzy")) and not \
                        (vh == "frenzy" and person.skills.__contains__("grab")):
                    locals()[vh + "knapp"].rita()
                    if locals()[vh + "knapp"].ar_aktiv():
                        peka = True
    if e == t:
        for vuh in vilkaskills[1]:
            for vh in locals()[vuh.lower() + "skills"]:
                if not person.skills.__contains__(vh):
                    if not (vh == "grab" and person.skills.__contains__("frenzy")) and not \
                            (vh == "frenzy" and person.skills.__contains__("grab")):
                        locals()[vh + "knapp"].rita()
                        if locals()[vh + "knapp"].ar_aktiv():
                            peka = True
    for vh in annat:
        locals()[vh + "knapp"].rita()

    skriv(gameDisplay, person.namn + " (" + person.typ + ") ska få en egenskap", (10, 10), 60)

    alltsur = gameDisplay.copy()

    while True:
        for eventh in pygame.event.get():
            if eventh.type == pygame.MOUSEBUTTONDOWN:
                klar = False
                vilken = None
                for vuh in vilkaskills[0]:
                    for vh in locals()[vuh.lower() + "skills"]:
                        if not person.skills.__contains__(vh):
                            if not (vh == "grab" and person.skills.__contains__("frenzy")) and not \
                                    (vh == "frenzy" and person.skills.__contains__("grab")):
                                if locals()[vh + "knapp"].ar_aktiv():
                                    klar, vilken = True, vh
                if e == t:
                    for vuh in vilkaskills[1]:
                        for vh in locals()[vuh.lower() + "skills"]:
                            if not person.skills.__contains__(vh):
                                if not (vh == "grab" and person.skills.__contains__("frenzy")) and not \
                                        (vh == "frenzy" and person.skills.__contains__("grab")):
                                    if locals()[vh + "knapp"].ar_aktiv():
                                        klar, vilken = True, vh
                for vh in annat:
                    if locals()[vh + "knapp"].ar_aktiv():
                        klar = True
                        vilken = vh

                if klar:
                    if vilken == "+1 ST":
                        person.varden[1] += 1
                        vardeplus = 50000
                    elif vilken == "+1 AG":
                        person.varden[2] += 1
                        vardeplus = 40000
                    elif vilken == "+1 AV":
                        person.varden[3] += 1
                        vardeplus = 30000
                    elif vilken == "+1 MA":
                        person.varden[0] += 1
                        vardeplus = 30000
                    else:
                        person.skills.append(vilken)
                        dubbel = False
                        for vuh in vilkaskills[1]:
                            if vilken in locals()[vuh.lower() + "skills"]:
                                dubbel = True
                        if dubbel:
                            vardeplus = 30000
                        else:
                            vardeplus = 20000
                    person.level += 1
                    person.pengavarde += vardeplus
                    return

        peka = False
        for vuh in vilkaskills[0]:
            for vh in locals()[vuh.lower() + "skills"]:
                if not person.skills.__contains__(vh):
                    if not (vh == "grab" and person.skills.__contains__("frenzy")) and not \
                            (vh == "frenzy" and person.skills.__contains__("grab")):
                        if locals()[vh + "knapp"].ar_aktiv():
                            peka = True
        if e == t:
            for vuh in vilkaskills[1]:
                for vh in locals()[vuh.lower() + "skills"]:
                    if not person.skills.__contains__(vh):
                        if not (vh == "grab" and person.skills.__contains__("frenzy")) and not \
                                (vh == "frenzy" and person.skills.__contains__("grab")):
                            if locals()[vh + "knapp"].ar_aktiv():
                                peka = True
        for vh in annat:
            if locals()[vh + "knapp"].ar_aktiv():
                peka = True

        gameDisplay.blit(alltsur, (0, 0))

        if peka:
            gameDisplay.blit(pekmus, pygame.mouse.get_pos())
        else:
            gameDisplay.blit(mus, pygame.mouse.get_pos())
        pygame.display.update()


def redigera_lag(all_data, lagnamn, ras, coach, pengar, harapo, rerolls, hela_laget=None):
    apofil = open(".lag/" + stor_forsta_bokstav(ras) + "/ApoRR", "r")
    aporead = apofil.read().strip()
    apofil.close()
    kanhaapo = aporead.split("\n")[0]
    rrcost = int(aporead.split("\n")[1])
    if kanhaapo == "Ja":
        kanhaapo = True
    else:
        kanhaapo = False

    if harapo and not kanhaapo:
        gameDisplay.fill((255, 0, 0))
        skriv(gameDisplay, "Du fuskar, din lurk! Du ska bli grillad!", (30, 50), 90, (50, 0, 0))
        pygame.display.update()
        time.sleep(10)
        quit()
    if rerolls > 8:
        gameDisplay.fill((255, 0, 0))
        skriv(gameDisplay, "Du fuskar, din lurk! Du ska bli grillad!", (30, 50), 90, (50, 0, 0))
        pygame.display.update()
        time.sleep(10)
        quit()

    if hela_laget is None:
        hela_laget = []
    kostnader, maximalt, personer, skills, varden = all_data

    for lh in varden:
        if int(lh.split(",")[2]) > 4:
            gameDisplay.fill((255, 0, 0))
            skriv(gameDisplay, "Du fuskar, din lurk! Du ska bli grillad!", (30, 50), 90, (50, 0, 0))
            pygame.display.update()
            time.sleep(10)
            quit()

    yh = 150
    for vh in personer:
        locals()[vh + "knapp"] = knapp(gameDisplay, vh, (30, yh), 40)
        yh += 50
    spara_lag(hela_laget, lagnamn, ras, pengar, harapo, rerolls)

    apoknapp = knapp(gameDisplay, "Apotekare", (30, yh), 40)

    rrknapp = knapp(gameDisplay, "Re-roll", (30, yh + 50), 40)

    update = True
    peka = False
    alltsur = gameDisplay.copy()

    while True:
        for eventh in pygame.event.get():
            if eventh.type == pygame.QUIT:
                quit()
            if eventh.type == pygame.MOUSEBUTTONDOWN:
                if eventh.button == 1 or eventh.button == 3:
                    update = True
                if kanhaapo and apoknapp.ar_aktiv():
                    if eventh.button == 1:
                        if not harapo:
                            if pengar - 50000 >= 0:
                                harapo = True
                                pengar -= 50000
                                spara_lag(hela_laget, lagnamn, ras, pengar, harapo, rerolls)
                            else:
                                gameDisplay.fill((255, 0, 0))
                                skriv(gameDisplay, "Du har inte råd (" + str(50000) + ")!", (50, 50), 90, (50, 0, 0))
                                pygame.display.update()
                                time.sleep(1)
                        else:
                            gameDisplay.fill((255, 0, 0))
                            skriv(gameDisplay, "Man kan bara ha en apotekare!", (50, 50), 90, (50, 0, 0))
                            pygame.display.update()
                            time.sleep(1)
                    elif eventh.button == 3:
                        while True:
                            ut = False
                            for eventhh in pygame.event.get():
                                if eventhh.type == pygame.MOUSEBUTTONDOWN:
                                    ut = True
                            if ut:
                                break
                            gameDisplay.fill((255, 255, 255))
                            skriv(gameDisplay, "Apotekare", (10, 10), 70)
                            skriv(gameDisplay, "Kostnad: 50000", (20, 100))
                            gameDisplay.blit(mus, pygame.mouse.get_pos())
                            pygame.display.update()
                elif rrknapp.ar_aktiv():
                    if eventh.button == 1:
                        if rerolls < 8:
                            if pengar - rrcost >= 0:
                                rerolls += 1
                                pengar -= rrcost
                                spara_lag(hela_laget, lagnamn, ras, pengar, harapo, rerolls)
                            else:
                                gameDisplay.fill((255, 0, 0))
                                skriv(gameDisplay, "Du har inte råd (" + str(rrcost) + ")!", (50, 50), 90, (50, 0, 0))
                                pygame.display.update()
                                time.sleep(1)
                        else:
                            gameDisplay.fill((255, 0, 0))
                            skriv(gameDisplay, "Man kan bara ha åtta re-rolls!", (50, 50), 90, (50, 0, 0))
                            pygame.display.update()
                            time.sleep(1)
                    elif eventh.button == 3:
                        while True:
                            ut = False
                            for eventhh in pygame.event.get():
                                if eventhh.type == pygame.MOUSEBUTTONDOWN:
                                    ut = True
                            if ut:
                                break
                            gameDisplay.fill((255, 255, 255))
                            skriv(gameDisplay, "Re-roll", (10, 10), 70)
                            skriv(gameDisplay, "Kostnad: " + str(rrcost), (20, 100))
                            gameDisplay.blit(mus, pygame.mouse.get_pos())
                            pygame.display.update()
                else:
                    redan = False
                    for vh in hela_laget:
                        if locals()[vh.namn + "knapp"].ar_aktiv():
                            redan = True
                            nagot = False
                            gameDisplay.fill((255, 100, 255))
                            skriv(gameDisplay, vh.namn, (10, 10), 70)
                            skriv(gameDisplay, "Typ: " + vh.typ, (20, 100))
                            skriv(gameDisplay, "MA  ST  AG  AV", (20, 150))
                            skriv(gameDisplay, " " + str(vh.varden[0]) + "      " + str(vh.varden[1]) + "      " +
                                  str(vh.varden[2]) + "      " + str(vh.varden[3]), (20, 180), 29)
                            skriv(gameDisplay, "Värde: " + str(vh.pengavarde), (20, 400))
                            skriv(gameDisplay, "Skills: " + str(vh.skills).replace("[", "").
                                  replace("]", "").replace("'", ""), (20, 290))
                            skriv(gameDisplay, "Star Player Points: " + str(vh.spp), (20, 510))
                            skriv(gameDisplay, "Skadad: " + vh.skadad, (20, 620))
                            pygame.draw.rect(gameDisplay, (255, 255, 255), (690, 70, 200, 195))
                            skriv(gameDisplay, "Passar: " + str(vh.passar), (700, 80))
                            skriv(gameDisplay, "Touchdowns: " + str(vh.touchdowns), (700, 120))
                            skriv(gameDisplay, "Casualties: " + str(vh.casualties), (700, 160))
                            skriv(gameDisplay, "Intercpetions: " + str(vh.interceptions), (700, 200))
                            skriv(gameDisplay, "MVPs: " + str(vh.mvps), (700, 240))
                            alltsur = gameDisplay.copy()
                            while not nagot:
                                for eventhh in pygame.event.get():
                                    if eventhh.type == pygame.MOUSEBUTTONDOWN:
                                        nagot = True
                                    if eventhh.type == pygame.QUIT:
                                        quit()
                                gameDisplay.blit(alltsur, (0, 0))
                                gameDisplay.blit(mus, pygame.mouse.get_pos())

                                pygame.display.update()
                            break
                        if locals()[vh.namn + "fireknapp"].ar_aktiv():
                            redan = True
                            if pygame_input(
                                    gameDisplay, ("Vill du kicka " + vh.namn + "?"), "nej").lower().__contains__("ja"):
                                hela_laget.pop(hela_laget.index(vh))
                                os.remove(".skapade lag/" + lagnamn + "/.spelare/" + vh.namn)
                                spara_lag(hela_laget, lagnamn, ras, pengar, harapo, rerolls)
                            break
                        if (vh.spp >= 6 and vh.level == 0) or (vh.spp >= 16 and vh.level == 1) or (
                                vh.spp >= 31 and vh.level == 2) or (vh.spp >= 51 and vh.level == 3) or (
                                vh.spp >= 76 and vh.level == 4) or (vh.spp >= 176 and vh.level == 5):
                            if locals()[vh.namn + "skillknapp"].ar_aktiv():
                                redan = True
                                fa_skill(vh, ras, vh.typ, personer)
                                spara_lag(hela_laget, lagnamn, ras, pengar, harapo, rerolls)
                                break
                    if not redan:
                        for vh in personer:
                            if locals()[vh + "knapp"].ar_aktiv():
                                if eventh.button == 1 or eventh.button == 3:
                                    plats = personer.index(vh)
                                    vardeh = list(map(int, varden[plats].split(",")))
                                    kostnad = int(kostnader[plats])
                                    if skills[plats]:
                                        skilllist = skills[plats].split(",")
                                    else:
                                        skilllist = []
                                    if eventh.button == 1:
                                        if len(hela_laget) < 16:
                                            numh = 0
                                            for v2h in hela_laget:
                                                if v2h.typ == personer[plats]:
                                                    numh += 1
                                            if numh >= int(maximalt[plats]):
                                                gameDisplay.fill((255, 0, 0))
                                                skriv(gameDisplay, "Du kan inte ha fler!", (50, 50), 90, (50, 0, 0))
                                                pygame.display.update()
                                                time.sleep(1)
                                                break
                                            if pengar - int(kostnader[plats]) < 0:
                                                gameDisplay.fill((255, 0, 0))
                                                skriv(gameDisplay, "Du har inte råd för fler!", (50, 50), 90,
                                                      (50, 0, 0))
                                                pygame.display.update()
                                                time.sleep(1)
                                                break
                                            while True:
                                                spelarnamn = pygame_input(gameDisplay, "Vad ska spelaren heta?",
                                                                          mussur=mus)
                                                finns = False
                                                for v2h in hela_laget:
                                                    if v2h.namn == spelarnamn:
                                                        finns = True
                                                if not finns:
                                                    break
                                            if spelarnamn:
                                                hela_laget.append(spelare(spelarnamn, vh, vardeh, int(kostnader[plats]),
                                                                          skilllist))
                                                pengar -= kostnad
                                                spara_lag(hela_laget, lagnamn, ras, pengar, harapo, rerolls)
                                            break
                                        else:
                                            gameDisplay.fill((255, 0, 0))
                                            skriv(gameDisplay, "Man kan bara ha 16 spelare i sitt lag!", (25, 50), 90,
                                                  (50, 0, 0))
                                            pygame.display.update()
                                            time.sleep(1.5)
                                    elif eventh.button == 3:
                                        nagot = False
                                        while not nagot:
                                            for eventhh in pygame.event.get():
                                                if eventhh.type == pygame.MOUSEBUTTONDOWN:
                                                    nagot = True
                                                if eventhh.type == pygame.QUIT:
                                                    quit()
                                            gameDisplay.fill((255, 255, 255))
                                            gameDisplay.blit(pygame.transform.scale(
                                                pygame.image.load(".bilder/.lag/" + ras + "/" + vh + ".png"),
                                                (400, 400)), (400, 0))
                                            skriv(gameDisplay, vh, (10, 10), 70)
                                            skriv(gameDisplay, "MA  ST  AG  AV", (20, 100))
                                            skriv(gameDisplay,
                                                  " " + str(vardeh[0]) + "      " + str(vardeh[1]) + "      " +
                                                  str(vardeh[2]) + "      " + str(vardeh[3]), (20, 130), 29)
                                            skriv(gameDisplay, "Kostnad: " + str(kostnad), (20, 350))
                                            skriv(gameDisplay, "Skills: " + str(skilllist).replace("[", "").
                                                  replace("]", "").replace("'", ""), (20, 240))
                                            skriv(gameDisplay, "Maximalt: " + str(maximalt[plats]), (20, 460))

                                            gameDisplay.blit(mus, pygame.mouse.get_pos())

                                            pygame.display.update()
                                        break

        if update:
            gameDisplay.fill((65, 98, 173))
            skriv(gameDisplay, 'Du redigerar lag "' + lagnamn + '"', (20, 20), 80, (120, 30, 48))
            skriv(gameDisplay, "Pengar: " + str(pengar), (20, 100), 30, (30, 255, 20))
            skriv(gameDisplay, "Antal spelare: " + str(len(hela_laget)), (400, 100), 30, (30, 255, 20))
            yh = 150
            for vh in hela_laget:
                locals()[vh.namn + "fireknapp"] = knapp(gameDisplay, "Kicka", (800, yh), 28)
                locals()[vh.namn + "fireknapp"].rita()
                locals()[vh.namn + "knapp"] = knapp(gameDisplay, vh.typ + ": " + vh.namn, (400, yh), 28)
                locals()[vh.namn + "knapp"].rita()
                if (vh.spp >= 6 and vh.level == 0) or (vh.spp >= 16 and vh.level == 1) or (
                        vh.spp >= 31 and vh.level == 2) or (vh.spp >= 51 and vh.level == 3) or (
                        vh.spp >= 76 and vh.level == 4) or (vh.spp >= 176 and vh.level == 5):
                    locals()[vh.namn + "skillknapp"] = knapp(gameDisplay, "Få egenskap", (900, yh), 28)
                    locals()[vh.namn + "skillknapp"].rita()
                yh += 28
            yh += 28
            if harapo:
                skriv(gameDisplay, "Apotekare", (400, yh), 28)
                yh += 28
            if rerolls:
                if rerolls == 1:
                    skriv(gameDisplay, str(rerolls) + " re-roll", (400, yh), 28)
                else:
                    skriv(gameDisplay, str(rerolls) + " re-rolls", (400, yh), 28)
            peka = False
            for vh in personer:
                locals()[vh + "knapp"].rita()
                if locals()[vh + "knapp"].ar_aktiv():
                    peka = True
            if kanhaapo:
                apoknapp.rita()
                if apoknapp.ar_aktiv():
                    peka = True

            rrknapp.rita()
            if rrknapp.ar_aktiv():
                peka = True
            update = False
            alltsur = gameDisplay.copy()

        peka = False
        for vh in personer:
            if locals()[vh + "knapp"].ar_aktiv():
                peka = True
        if kanhaapo:
            if apoknapp.ar_aktiv():
                peka = True

        if rrknapp.ar_aktiv():
            peka = True

        for vh in hela_laget:
            if locals()[vh.namn + "knapp"].ar_aktiv():
                peka = True
            if locals()[vh.namn + "fireknapp"].ar_aktiv():
                peka = True
            if (vh.spp >= 6 and vh.level == 0) or (vh.spp >= 16 and vh.level == 1) or (
                    vh.spp >= 31 and vh.level == 2) or (vh.spp >= 51 and vh.level == 3) or (
                    vh.spp >= 76 and vh.level == 4) or (vh.spp >= 176 and vh.level == 5):
                if locals()[vh.namn + "skillknapp"].ar_aktiv():
                    peka = True

        gameDisplay.blit(alltsur, (0, 0))

        musposh = pygame.mouse.get_pos()
        if peka:
            gameDisplay.blit(pekmus, musposh)
        else:
            gameDisplay.blit(mus, musposh)

        pygame.display.update()


def oppna_lag():
    lagnamn = pygame_input(gameDisplay, "Vilket lag vill du redigera?", mussur=mus)
    while True:
        try:
            filh = open(".skapade lag/" + lagnamn + "/Ras", "r", encoding="utf-8")
            ras = filh.read().strip()
            filh.close()
            break
        except FileNotFoundError:
            lagnamn = pygame_input(gameDisplay, "Det finns inte! Vilket lag vill du redigera?", mussur=mus)
    kostnader, maximalt, personer, skills, varden = team_data(ras)

    filh = open(".skapade lag/" + lagnamn + "/Var", "r")
    if filh.read() != "inget":
        gameDisplay.fill((255, 0, 0))
        skriv(gameDisplay, "Det laget är i en match!", (30, 50), 90, (50, 0, 0))
        pygame.display.update()
        time.sleep(2)
        return
    filh.close()

    filerh = os.listdir(".skapade lag/" + lagnamn + "/.spelare/")
    hela_laget = []
    for vh in filerh:
        filh = open(".skapade lag/" + lagnamn + "/.spelare/" + vh, "rb")
        obj = pickle.load(filh)
        hela_laget.append(obj)
    filh = open(".skapade lag/" + lagnamn + "/Coach", "r", encoding="utf-8")
    coach = filh.read().strip()
    filh.close()

    filh = open(".skapade lag/" + lagnamn + "/Pengar", "r", encoding="utf-8")
    pengar = int(filh.read().strip())
    filh.close()

    harapofil = open(".skapade lag/" + lagnamn + "/Apo", "r", encoding="utf-8")
    harapo = harapofil.read().strip()
    harapofil.close()
    if harapo == "True":
        harapo = True
    else:
        harapo = False

    rrfil = open(".skapade lag/" + lagnamn + "/RR", "r", encoding="utf-8")
    rr = int(rrfil.read().strip())
    rrfil.close()

    redigera_lag((kostnader, maximalt, personer, skills, varden), lagnamn, ras, coach, pengar, harapo, rr, hela_laget)


def skapa_nytt_lag():
    ras = pygame_input(gameDisplay, "Vilken ras?", mussur=mus).lower()
    while ras not in raser:
        ras = pygame_input(gameDisplay, "Den rasen finns inte! Vilken ras?", mussur=mus).lower()
    kostnader, maximalt, personer, skills, varden = team_data(ras)
    lagnamn = pygame_input(gameDisplay, "Vad ska laget heta?", mussur=mus)
    while True:
        try:
            os.mkdir(".skapade lag/" + lagnamn)
            os.mkdir(".skapade lag/" + lagnamn + "/.spelare")
            break
        except FileExistsError:
            lagnamn = pygame_input(gameDisplay, "Det finns redan! Vad ska laget heta istället?", mussur=mus)
    coach = pygame_input(gameDisplay, "Vad ska coachen heta?", mussur=mus)
    filh = open(".skapade lag/" + lagnamn + "/Coach", "w", encoding="utf-8")
    filh.write(coach)
    filh.close()
    filh = open(".skapade lag/" + lagnamn + "/Var", "w", encoding="utf-8")
    filh.write("inget")
    filh.close()
    redigera_lag((kostnader, maximalt, personer, skills, varden), lagnamn, ras, coach, 1000000, False, 0)


skapa_lag = knapp(gameDisplay, "Skapa ett lag", (200, 300), 40)
redigera_lagknapp = knapp(gameDisplay, "Redigera ett lag", (200, 400), 40)
avsluta = knapp(gameDisplay, "Avsluta", (200, 500), 40)

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quit()
        if event.type == pygame.MOUSEBUTTONDOWN:
            musknapp = event.button
            if musknapp == 1:
                if skapa_lag.ar_aktiv():
                    skapa_nytt_lag()
                elif redigera_lagknapp.ar_aktiv():
                    oppna_lag()
                elif avsluta.ar_aktiv():
                    quit()

    gameDisplay.fill((70, 43, 70))
    skriv(gameDisplay, "Blood Bowl", (40, 20), 70, (50, 250, 100), True)
    skapa_lag.rita()
    redigera_lagknapp.rita()
    avsluta.rita()

    muspos = pygame.mouse.get_pos()
    if skapa_lag.ar_aktiv() or redigera_lagknapp.ar_aktiv() or avsluta.ar_aktiv():
        gameDisplay.blit(pekmus, muspos)
    else:
        gameDisplay.blit(mus, muspos)

    pygame.display.update()
