import os
import pickle
import time
import webbrowser

import pygame

from Functions import *

pygame.init()

vidd, hoejd = 1170, 675

gameDisplay = pygame.display.set_mode((vidd, hoejd))

mus = pygame.image.load(".bilder/.markörer/Mus.png")
pekmus = pygame.image.load(".bilder/.markörer/Pekmus.png")

pygame.mouse.set_visible(False)


raser = ["skogsalver", "orcher", "ogres", "lizardmen", "hobbitar", "odöda"]


def team_data(ras):
    fil = open(".lag/" + stor_forsta_bokstav(ras) + "/Kostnader")
    kostnader = fil.read().strip().split("/")
    fil.close()
    fil = open(".lag/" + stor_forsta_bokstav(ras) + "/Maximalt")
    maximalt = fil.read().strip().split("/")
    fil.close()
    fil = open(".lag/" + stor_forsta_bokstav(ras) + "/Personer")
    personer = fil.read().strip().split("/")
    fil.close()
    fil = open(".lag/" + stor_forsta_bokstav(ras) + "/Skills")
    skills = fil.read().strip().split("/")
    fil.close()
    fil = open(".lag/" + stor_forsta_bokstav(ras) + "/Värden")
    varden = fil.read().strip().split("/")
    fil.close()
    return kostnader, maximalt, personer, skills, varden


def spara_lag(hela_laget, lagnamn, ras, pengar):
    filh = open(".skapade lag/" + lagnamn + "/Ras", "w")
    filh.write(ras)
    filh.close()
    filh = open(".skapade lag/" + lagnamn + "/Pengar", "w")
    filh.write(str(pengar))
    filh.close()
    for vh in hela_laget:
        filh = open(".skapade lag/" + lagnamn + "/.spelare/" + vh.namn, "wb")
        pickle.dump(vh, filh)
        filh.close()


def redigera_lag(all_data, lagnamn, ras, coach, pengar, hela_laget=None):
    if hela_laget is None:
        hela_laget = []
    kostnader, maximalt, personer, skills, varden = all_data
    yh = 150
    for vh in personer:
        locals()[vh + "knapp"] = knapp(gameDisplay, vh, (30, yh), 40)
        yh += 50
    spara_lag(hela_laget, lagnamn, ras, pengar)

    while True:
        for eventh in pygame.event.get():
            if eventh.type == pygame.QUIT:
                quit()
            if eventh.type == pygame.MOUSEBUTTONDOWN:
                for vh in personer:
                    if locals()[vh + "knapp"].ar_aktiv():
                        plats = personer.index(vh)
                        numh = 0
                        for v2h in hela_laget:
                            if v2h.typ == personer[plats]:
                                numh += 1
                        if numh >= int(maximalt[plats]):
                            gameDisplay.fill((255, 0, 0))
                            skriv(gameDisplay, "Du kan inte ha fler!", (50, 50), 90, (50, 0, 0))
                            pygame.display.update()
                            time.sleep(1)
                            break
                        if pengar - int(kostnader[plats]) < 0:
                            gameDisplay.fill((255, 0, 0))
                            skriv(gameDisplay, "Du har inte råd för fler!", (50, 50), 90, (50, 0, 0))
                            pygame.display.update()
                            time.sleep(1)
                            break
                        while True:
                            spelarnamn = pygame_input(gameDisplay, "Vad ska spelaren heta?")
                            finns = False
                            for v2h in hela_laget:
                                if v2h.namn == spelarnamn:
                                    finns = True
                            if not finns:
                                break
                        vardeh = list(map(int, varden[plats].split(",")))
                        kostnad = int(kostnader[plats])
                        if skills[plats]:
                            skilllist = skills[plats].split(",")
                        else:
                            skilllist = []
                        hela_laget.append(spelare(spelarnamn, vh, vardeh, int(kostnader[plats]),
                                                  skilllist))
                        pengar -= kostnad
                        spara_lag(hela_laget, lagnamn, ras, pengar)
                        break

        gameDisplay.fill((65, 98, 173))
        skriv(gameDisplay, 'Du redigerar lag "' + lagnamn + '"', (20, 20), 80, (120, 30, 48))
        skriv(gameDisplay, "Pengar: " + str(pengar), (20, 100), 30)
        yh = 150
        for vh in hela_laget:
            skriv(gameDisplay, vh.typ + ": " + vh.namn, (400, yh))
            yh += 30

        peka = False
        for vh in personer:
            locals()[vh + "knapp"].rita()
            if locals()[vh + "knapp"].ar_aktiv():
                peka = True
        musposh = pygame.mouse.get_pos()
        if peka:
            gameDisplay.blit(pekmus, musposh)
        else:
            gameDisplay.blit(mus, musposh)

        pygame.display.update()


def oppna_lag():
    lagnamn = pygame_input(gameDisplay, "Vilket lag vill du redigera?")
    while True:
        try:
            filh = open(".skapade lag/" + lagnamn + "/Ras", "r")
            ras = filh.read().strip()
            filh.close()
            break
        except FileNotFoundError:
            lagnamn = pygame_input(gameDisplay, "Vilket lag vill du redigera?")
    kostnader, maximalt, personer, skills, varden = team_data(ras)

    filerh = os.listdir(".skapade lag/" + lagnamn + "/.spelare/")
    hela_laget = []
    for vh in filerh:
        filh = open(".skapade lag/" + lagnamn + "/.spelare/" + vh, "rb")
        obj = pickle.load(filh)
        hela_laget.append(obj)
    filh = open(".skapade lag/" + lagnamn + "/Coach", "r")
    coach = filh.read().strip()
    filh.close()

    filh = open(".skapade lag/" + lagnamn + "/Pengar", "r")
    pengar = int(filh.read().strip())
    filh.close()

    redigera_lag((kostnader, maximalt, personer, skills, varden), lagnamn, ras, coach, pengar, hela_laget)


def skapa_nytt_lag():
    ras = pygame_input(gameDisplay, "Vilken ras?").lower()
    while ras not in raser:
        ras = pygame_input(gameDisplay, "Vilken ras?").lower()
    kostnader, maximalt, personer, skills, varden = team_data(ras)
    print(personer)
    lagnamn = pygame_input(gameDisplay, "Vad ska laget heta?")
    while True:
        try:
            os.mkdir(".skapade lag/" + lagnamn)
            os.mkdir(".skapade lag/" + lagnamn + "/.spelare")
            break
        except FileExistsError:
            lagnamn = pygame_input(gameDisplay, "Det finns redan! Vad ska laget heta istället?")
    coach = pygame_input(gameDisplay, "Vad ska coachen heta?")
    filh = open(".skapade lag/" + lagnamn + "/Coach", "w")
    filh.write(coach)
    filh.close()
    filh = open(".skapade lag/" + lagnamn + "/Var", "w")
    filh.write("inget")
    filh.close()
    redigera_lag((kostnader, maximalt, personer, skills, varden), lagnamn, ras, coach, 1000000)


skapa_lag = knapp(gameDisplay, "Skapa ett lag", (200, 300), 40)
redigera_lagknapp = knapp(gameDisplay, "Redigera ett lag", (200, 400), 40)
starta_match = knapp(gameDisplay, "Starta en match", (200, 500), 40)

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quit()
        if event.type == pygame.MOUSEBUTTONDOWN:
            musknapp = event.button
            if musknapp == 1:
                if skapa_lag.ar_aktiv():
                    skapa_nytt_lag()
                elif redigera_lagknapp.ar_aktiv():
                    oppna_lag()
                elif starta_match.ar_aktiv():
                    webbrowser.open("Game.py")
                    quit()

    gameDisplay.fill((70, 43, 70))
    skriv(gameDisplay, "Blood Bowl", (40, 20), 70, (50, 250, 100), True)
    skapa_lag.rita()
    redigera_lagknapp.rita()
    starta_match.rita()

    muspos = pygame.mouse.get_pos()
    if skapa_lag.ar_aktiv() or redigera_lagknapp.ar_aktiv() or starta_match.ar_aktiv():
        gameDisplay.blit(pekmus, muspos)
    else:
        gameDisplay.blit(mus, muspos)

    pygame.display.update()
