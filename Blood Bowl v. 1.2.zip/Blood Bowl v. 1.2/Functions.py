def ta_bort_farg(bild, farg=(0, 0, 0)):
    import pygame
    x, y = bild.get_size()
    ny = pygame.Surface((x, y))
    for vy in range(0, y):
        for vx in range(0, x):
            ett, tva, tre, fyra = bild.get_at((vx, vy))
            print(ett)
            if ett == farg[0] and tva == farg[1] and tre == farg[2]:
                ny.set_at((vx, vy), (ett, tva, tre + 1))
            else:
                ny.set_at((vx, vy), (ett, tva, tre))

    return ny


def gor_bild_svartvit(bild):
    import pygame
    x, y = bild.get_size()

    ny = pygame.Surface((x, y))

    for vy in range(0, y):
        print(vy)
        for vx in range(0, x):
            ett, tva, tre, fyra = bild.get_at((vx, vy))
            enavde = (ett + tva + tre) / 3
            nyfarg = (enavde, enavde, enavde)
            ny.set_at((vx, vy), nyfarg)

    return ny


def skriv(surface, text, pos=(0, 0), storlek=30, farg=(0, 0, 0), fetstil=False):
    display = surface
    import pygame
    font = pygame.font.SysFont("", storlek, fetstil)
    bildh = font.render(text, True, farg)
    display.blit(bildh, pos)


def get_textwidth(text, storlek):
    import pygame
    font = pygame.font.SysFont("", storlek)
    s = font.render(text, True, (0, 0, 0))
    tx, ty = s.get_size()
    return tx


def pygame_input(surface, text, redan="", helskarm=True, rutplats=(0, 0)):
    display = surface
    import pygame
    pyper = True
    try:
        import pyperclip
    except ModuleNotFoundError:
        pyper = False
    xh, yh = rutplats
    inputtat = redan
    plats = len(inputtat)
    forebild = pygame.Surface((1200, 620))
    forebild.blit(display, (0, 0))
    while True:
        if helskarm:
            display.fill((255, 0, 0))
        else:
            display.blit(forebild, (0, 0))
            pygame.draw.rect(display, (255, 255, 255), (xh, yh, get_textwidth(inputtat, 40), 40))
        skriv(display, text, (30, 30), 75)
        ev = pygame.event.poll()
        if ev.type == pygame.QUIT:
            pygame.quit()
            quit()
        if ev.type == pygame.KEYDOWN:
            keysh = pygame.key.get_pressed()
            if keysh[pygame.K_LEFT]:
                plats -= 1
                if plats < 0:
                    plats = 0
            if keysh[pygame.K_RIGHT]:
                plats += 1
                if plats > len(inputtat):
                    plats = len(inputtat)
            keyh = pygame.key.name(ev.key)
            klippt = False
            if keysh[pygame.K_LCTRL] or keysh[pygame.K_RCTRL]:
                if keysh[pygame.K_v] and pyper:
                    keyh = pyperclip.paste()
                    klippt = True
            shift = keysh[pygame.K_LSHIFT]
            if not shift:
                shift = keysh[pygame.K_RSHIFT]
            altgr = keysh[pygame.K_RCTRL]
            if not altgr:
                altgr = keysh[pygame.K_LCTRL]
            if keyh == "backspace":
                pa = -1
            elif keyh == "space":
                pa = " "
            elif keyh == "return":
                return inputtat
            else:
                if len(keyh) == 1:
                    if shift:
                        keyh = keyh.upper()
                        if keyh == "-":
                            keyh = "_"
                        elif keyh == "1":
                            keyh = "!"
                        elif keyh == "+":
                            keyh = "?"
                        elif keyh == "8":
                            keyh = "("
                        elif keyh == "9":
                            keyh = ")"
                        elif keyh == "3":
                            keyh = "#"
                        elif keyh == "0":
                            keyh = "="
                        elif keyh == "2":
                            keyh = '"'
                        elif keyh == "4":
                            keyh = "¤"
                        elif keyh == "5":
                            keyh = "%"
                        elif keyh == "'":
                            keyh = "*"
                        elif keyh == "6":
                            keyh = "&"
                        elif keyh == ".":
                            keyh = ":"
                        elif keyh == ",":
                            keyh = ";"
                        elif keyh == "<":
                            keyh = ">"
                        elif keyh == "7":
                            keyh = "/"
                    if altgr:
                        if keyh == "U":
                            keyh = "Ü"
                        if keyh == "u":
                            keyh = "ü"
                    pa = keyh
                else:
                    if klippt is False:
                        pa = ""
                    else:
                        pa = keyh

            if pa != "":
                inputtatny = ""
                numh = 0
                for vh in inputtat + "#":
                    if plats == numh:
                        if pa == -1:
                            inputtatny = inputtatny[:-1]
                        else:
                            inputtatny += pa
                    inputtatny += vh
                    numh += 1
                inputtat = inputtatny[:-1]
                if pa == -1:
                    plats -= 1
                    if plats < 0:
                        plats = 0
                else:
                    plats += 1
        if helskarm:
            skriv(display, inputtat, (10, 300), 40)
            pygame.draw.line(display, (0, 0, 0), (10 + get_textwidth(inputtat[:plats], 40), 300),
                             (10 + get_textwidth(inputtat[:plats], 40), 330))
        else:
            skriv(display, inputtat, rutplats, 40)
            pygame.draw.line(display, (0, 0, 0), (xh + get_textwidth(inputtat[:plats], 40), yh),
                             (xh + get_textwidth(inputtat[:plats], 40), yh + 30))
        pygame.display.update()


def get_textsize(text, storlek):
    import pygame
    font = pygame.font.SysFont("", storlek)
    s = font.render(text, True, (0, 0, 0))
    tx, ty = s.get_size()
    return tx, ty


def fa_pos(ruta):
    x = (ruta % 26) * 45
    y = int(ruta / 26) * 45
    if ruta > -1:
        return x, y
    else:
        return x, -45


def vilken_ruta(pos):
    musx, musy = pos
    xrund, yrund = int(musx / 45), int(musy / 45)
    return yrund * 26 + xrund


def stor_forsta_bokstav(string):
    tebaks = ""
    numh = 0
    for vh in string:
        if numh == 0:
            tebaks += vh.upper()
        else:
            tebaks += vh
        numh += 1
    return tebaks


def kolla_langden(ruta, sikte):
    x1, y1 = fa_pos(ruta)
    x2, y2 = fa_pos(sikte)
    mellanx = x1 - x2
    if str(mellanx).find("-") != -1:
        mellanx = -mellanx
    mellanrutor = round(mellanx / 45)
    mellany = y1 - y2
    if str(mellany).find("-") != -1:
        mellany = -mellany
    hoejdrutor = round(mellany / 45)

    langd = ""

    if hoejdrutor == 13:
        if mellanrutor < 2:
            langd = "bomb"
    if hoejdrutor == 12:
        if mellanrutor < 5:
            langd = "bomb"
    if hoejdrutor == 11:
        if mellanrutor < 7:
            langd = "bomb"
    if hoejdrutor == 10:
        if mellanrutor < 3:
            langd = "long"
        elif mellanrutor < 9:
            langd = "bomb"
    if hoejdrutor == 9:
        if mellanrutor < 5:
            langd = "long"
        elif mellanrutor < 10:
            langd = "bomb"
    if hoejdrutor == 8:
        if mellanrutor < 7:
            langd = "long"
        elif mellanrutor < 11:
            langd = "bomb"
    if hoejdrutor == 7:
        if mellanrutor < 8:
            langd = "long"
        elif mellanrutor < 11:
            langd = "bomb"
    if hoejdrutor == 6:
        if mellanrutor < 4:
            langd = "short"
        elif mellanrutor < 9:
            langd = "long"
        elif mellanrutor < 12:
            langd = "bomb"
    if hoejdrutor == 5:
        if mellanrutor < 5:
            langd = "short"
        elif mellanrutor < 9:
            langd = "long"
        elif mellanrutor < 12:
            langd = "bomb"
    if hoejdrutor == 4:
        if mellanrutor < 6:
            langd = "short"
        elif mellanrutor < 10:
            langd = "long"
        elif mellanrutor < 13:
            langd = "bomb"
    if hoejdrutor == 3:
        if mellanrutor < 2:
            langd = "quick"
        elif mellanrutor < 7:
            langd = "short"
        elif mellanrutor < 10:
            langd = "long"
        elif mellanrutor < 13:
            langd = "bomb"
    if hoejdrutor == 2:
        if mellanrutor < 3:
            langd = "quick"
        elif mellanrutor < 7:
            langd = "short"
        elif mellanrutor < 11:
            langd = "long"
        elif mellanrutor < 13:
            langd = "bomb"
    if hoejdrutor == 1:
        if mellanrutor < 4:
            langd = "quick"
        elif mellanrutor < 7:
            langd = "short"
        elif mellanrutor < 11:
            langd = "long"
        elif mellanrutor < 14:
            langd = "bomb"
    if hoejdrutor == 0:
        if mellanrutor < 4:
            langd = "quick"
        elif mellanrutor < 7:
            langd = "short"
        elif mellanrutor < 11:
            langd = "long"
        elif mellanrutor < 14:
            langd = "bomb"
    # if vader == 12 and (langd == "bomb" or langd == "long"):
    #    langd = ""
    return langd


def vettigt_s(string):
    if string[-1].lower() in ["x", "s", "z"]:
        return string
    else:
        return string + "s"


class knapp:
    def __init__(self, surface, text, pos=(0, 0), storlek=50, textfarg=(0, 0, 0)):
        self.text = text
        self.pos = pos
        self.storlek = storlek
        self.vidd = 0
        self.hoejd = 0
        self.farg = textfarg
        self.surface = surface

    def ar_aktiv(self):
        import pygame
        musx, musy = pygame.mouse.get_pos()
        self.vidd, self.hoejd = get_textsize(self.text, self.storlek)
        if self.pos[0] + self.vidd > musx > self.pos[0] and self.pos[1] < musy < self.pos[1] + self.hoejd:
            return True
        return False

    def rita(self):
        skriv(self.surface, self.text, self.pos, self.storlek, self.farg)


class spelare:
    def __init__(self, namn="name", typ="Orch_blitzer", varden=(6, 3, 3, 9), pengavarde=80000, skills=["block"],
                 skador=[]):
        self.namn, self.typ, self.varden, self.pengavarde, self.skills, self.skador = namn, typ, varden, pengavarde, \
                                                                                      skills, skador
        self.spp = 0
        self.level = 0


class spelareimatch:
    def __init__(self, spelaren):
        self.spelare = spelaren
        self.ruta = 0
        self.star = True
        self.tacklezone = True
        self.skadad = ""
        self.har_gjort = False
        self.fardig = False
        self.steg_kvar = self.spelare.varden[0]
        self.har_bollen = False
        self.har_blitzat = False
        self.har_blockat = False
        self.ska_blitza = False
        self.ska_passa = False
        self.ska_handoffa = False
