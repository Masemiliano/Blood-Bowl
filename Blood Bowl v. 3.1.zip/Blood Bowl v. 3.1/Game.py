import ctypes
import os
import pickle
import random
import shutil
import time

import pygame

from Functions import *

pygame.init()

rerollallt = False
splashaskador = True
autospara = True
hemligakommandon = False
riktigapixlar = False
egetdrag = True
fullskarm = False
gammalboll = False
ruthjalp = True
fragablockar = True
visafps = False
animeringar = False
rgb = (30, 100, 255)

fil = open(".hemliga inställningar/Rerolla allt", "r", encoding="utf-8")
if fil.read().lower().__contains__("true"):
    rerollallt = True
fil.close()
fil = open(".hemliga inställningar/Splasha skador", "r", encoding="utf-8")
if fil.read().lower().__contains__("false"):
    splashaskador = False
fil.close()
fil = open(".hemliga inställningar/Autospara", "r", encoding="utf-8")
if fil.read().lower().__contains__("false"):
    autospara = False
fil.close()
fil = open(".hemliga inställningar/Hemliga kommandon", "r", encoding="utf-8")
if fil.read().lower().__contains__("true"):
    hemligakommandon = True
fil.close()
fil = open(".hemliga inställningar/Riktiga pixlar", "r", encoding="utf-8")
if fil.read().lower().__contains__("true"):
    riktigapixlar = True
fil.close()
fil = open(".hemliga inställningar/Visa eget drag", "r", encoding="utf-8")
if fil.read().lower().__contains__("false"):
    egetdrag = False
fil.close()
fil = open(".hemliga inställningar/Fullskärm", "r", encoding="utf-8")
if fil.read().lower().__contains__("true"):
    fullskarm = True
fil.close()
fil = open(".hemliga inställningar/Gammal boll", "r", encoding="utf-8")
if fil.read().lower().__contains__("true"):
    gammalboll = True
fil.close()
fil = open(".hemliga inställningar/RGB", "r", encoding="utf-8")
lines = fil.readlines()
if lines[0].lower().__contains__("true"):
    rgb = (int(lines[1].split(", ")[0]), int(lines[1].split(", ")[1]), int(lines[1].split(", ")[2]))
fil.close()
fil = open(".hemliga inställningar/Ruthjälp", "r", encoding="utf-8")
if fil.read().lower().__contains__("false"):
    ruthjalp = False
fil.close()
fil = open(".hemliga inställningar/Fråga om blockar", "r", encoding="utf-8")
if fil.read().lower().__contains__("false"):
    fragablockar = False
fil.close()
fil = open(".hemliga inställningar/Visa fps", "r", encoding="utf-8")
if fil.read().lower().__contains__("true"):
    visafps = True
fil.close()
fil = open(".hemliga inställningar/Tärningsvänt", "r", encoding="utf-8")
try:
    tarningsvant = int(fil.read().strip())
except ValueError:
    tarningsvant = 2
fil.close()
fil = open(".hemliga inställningar/Animeringar", "r", encoding="utf-8")
if fil.read().lower().__contains__("true"):
    animeringar = True
fil.close()

if riktigapixlar:
    try:
        ctypes.windll.user32.SetProcessDPIAware()  # detta gör så att pixlar faktiskt är pixlar i pygame
    except AttributeError:
        print("Du har riktia pixlar på, men den inställningen fungerar inte på din plattform.")

sx, sy = pygame.display.Info().current_w, pygame.display.Info().current_h

vidd, hoejd = 1380, 675

if fullskarm:
    gameDisplay = pygame.display.set_mode((sx, sy), pygame.FULLSCREEN)
else:
    gameDisplay = pygame.display.set_mode((vidd + 50, hoejd), pygame.RESIZABLE | pygame.SCALED)

pygame.display.set_caption("Blood Bowl")
pygame.display.set_icon(pygame.image.load(".bilder/.markörer/Pekmus.png").convert_alpha())

mus = pygame.image.load(".bilder/.markörer/Mus.png").convert_alpha()
pekmus = pygame.image.load(".bilder/.markörer/Pekmus.png").convert_alpha()

vadertillbild = "Nice"
vader = "Nice"
eu, tu = random.randint(1, 6), random.randint(1, 6)

if eu + tu == 12:
    vader = "blizzard"
    vadertillbild = "Snö"
if eu + tu == 11:
    vader = "pouring rain"
    vadertillbild = "Regn"
if eu + tu == 3:
    vader = "very sunny"
    vadertillbild = "Soligt"
if eu + tu == 2:
    vader = "sweltering heat"
    vadertillbild = "Hett"

if gammalboll:
    boll = pygame.image.load(".bilder/.spelplansgrejer/Gammal boll.png").convert_alpha()
else:
    boll = pygame.image.load(".bilder/.spelplansgrejer/Boll.png").convert_alpha()

pygame.mouse.set_visible(False)

lag1namn = pygame_input(gameDisplay, "Lag 1:", mussur=mus)
while True:
    try:
        fil = open(".skapade lag/" + lag1namn + "/Pengar", "r")
        fil.close()
        break
    except FileNotFoundError:
        lag1namn = pygame_input(gameDisplay, "ERROR! Lag 1:", mussur=mus)

spelarfiler = os.listdir(".skapade lag/" + lag1namn + "/.spelare/")
hela_laget1 = []
for v in spelarfiler:
    fil = open(".skapade lag/" + lag1namn + "/.spelare/" + v, "rb")
    hela_laget1.append(pickle.load(fil))

# följande handlar om att ladda en match automatiskt genom att skriva in bara ett lags namn
matchen = ""

varfil = open(".skapade lag/" + lag1namn + "/Var", "r", encoding="utf-8")
var1 = varfil.read()
varfil.close()
if var1 != "inget":
    matchen = var1

#

if matchen:
    lag1namn, lag2namn = matchen.split(" VS ")
    spelarfiler = os.listdir(".skapade lag/" + lag1namn + "/.spelare/")
    hela_laget1 = []
    for v in spelarfiler:
        fil = open(".skapade lag/" + lag1namn + "/.spelare/" + v, "rb")
        hela_laget1.append(pickle.load(fil))
        fil.close()
else:
    lag2namn = pygame_input(gameDisplay, "Lag 2:", mussur=mus)
    while True:
        try:
            fil = open(".skapade lag/" + lag2namn + "/Pengar", "r")
            fil.close()
            break
        except FileNotFoundError:
            lag2namn = pygame_input(gameDisplay, "ERROR! Lag 2:", mussur=mus)
    varfil = open(".skapade lag/" + lag2namn + "/Var", "r", encoding="utf-8")
    var2 = varfil.read()
    varfil.close()
    if var2 != "inget":
        pygame.quit()
        input("Lag2 var redan i en match, men inte i match med lag1. Därför stängde vi ner programmet, för ett lag kan "
              "inte vara i flera matcher samtidigt.")
        exit()
spelarfiler = os.listdir(".skapade lag/" + lag2namn + "/.spelare/")
hela_laget2 = []
for v in spelarfiler:
    fil = open(".skapade lag/" + lag2namn + "/.spelare/" + v, "rb")
    hela_laget2.append(pickle.load(fil))
    fil.close()

ras1f, ras2f = open(".skapade lag/" + lag1namn + "/Ras", "r", encoding="utf-8"), \
               open(".skapade lag/" + lag2namn + "/Ras", "r", encoding="utf-8")
ras1, ras2 = ras1f.read(), ras2f.read()
ras1f.close()
ras2f.close()

for v in os.listdir(".bilder/.lag/"):
    for v2 in os.listdir(".bilder/.lag/" + v):
        if v == stor_forsta_bokstav(ras1) or v == stor_forsta_bokstav(ras2):
            v3 = v2.replace(".png", "")
            globals()[v3 + "bild"] = pygame.image.load(".bilder/.lag/" + v + "/" + v2).convert_alpha()
for v in os.listdir(".bilder/.markörer/"):
    v2 = v.replace(".png", "")
    globals()[v2 + "bild"] = pygame.image.load(".bilder/.markörer/" + v).convert_alpha()
for v in os.listdir(".bilder/.tarningar/"):
    v2 = v.replace(".png", "")
    globals()[v2 + "bild"] = pygame.image.load(".bilder/.tarningar/" + v).convert_alpha()
    globals()[v2 + "litenbild"] = pygame.transform.scale(globals()[v2 + "bild"], (20, 20))

alla_spelare1 = []
for v in hela_laget1:
    obj = spelareimatch(v)
    if v.skadad:
        obj.skadad = v.skadad + "_b"
    alla_spelare1.append(obj)
alla_spelare2 = []
for v in hela_laget2:
    obj = spelareimatch(v)
    if v.skadad:
        obj.skadad = v.skadad + "_b"
    alla_spelare2.append(obj)

fil1, fil2 = open(".skapade lag/" + lag1namn + "/Coach", "r", encoding="utf-8"), \
             open(".skapade lag/" + lag2namn + "/Coach", "r", encoding="utf-8")
coach1, coach2 = fil1.read().strip(), fil2.read().strip()
fil1.close()
fil2.close()

fil1, fil2 = open(".skapade lag/" + lag1namn + "/RR", "r"), open(".skapade lag/" + lag2namn + "/RR", "r")
rerolls1, rerolls2 = int(fil1.read().strip()), int(fil2.read().strip())
fil1.close()
fil2.close()

bribes1, bribes2 = 0, 0

fil1, fil2 = open(".skapade lag/" + lag1namn + "/Pengar", "r"), open(".skapade lag/" + lag2namn + "/Pengar", "r")
pengar1, pengar2 = int(fil1.read().strip()), int(fil2.read().strip())
fil1.close()
fil2.close()

farhaapo1, farhaapo2 = False, False
apofil = open(".lag/" + stor_forsta_bokstav(ras1) + "/ApoRR", "r")
aporead = apofil.read().strip()
apofil.close()
rrcost1 = int(aporead.split("\n")[1])
kanhaapo = aporead.split("\n")[0]
if kanhaapo == "Ja":
    farhaapo1 = True
else:
    farhaapo1 = False
apofil = open(".lag/" + stor_forsta_bokstav(ras2) + "/ApoRR", "r")
aporead = apofil.read().strip()
apofil.close()
rrcost2 = int(aporead.split("\n")[1])
kanhaapo = aporead.split("\n")[0]
if kanhaapo == "Ja":
    farhaapo2 = True
else:
    farhaapo2 = False

aglist = [None, 6, 5, 4, 3, 2, 1]

tarningsslag = ["Väder: " + vader + " (" + str(eu + tu) + ")"]

listahall = [25, 26, 27, -1, 1, -27, -26, -25]

nedrakutgang = 200
paplaninfo, nedrakning = [], nedrakutgang

kanskilla, kanproa = False, False


def spara_match(splasha=True, kickoffh=False, vemborjar=1):
    vagh = ".matcher/" + lag1namn + " VS " + lag2namn
    try:
        os.mkdir(vagh)
    except FileExistsError:
        pass
    try:
        os.mkdir(vagh + "/1")
    except FileExistsError:
        pass
    try:
        os.mkdir(vagh + "/2")
    except FileExistsError:
        pass
    for vh in alla_spelare1:
        filh = open(vagh + "/1/" + vh.spelare.namn, "wb")
        pickle.dump(vh, filh)
        filh.close()
    for vh in alla_spelare2:
        filh = open(vagh + "/2/" + vh.spelare.namn, "wb")
        pickle.dump(vh, filh)
        filh.close()
    filh = open(".skapade lag/" + lag1namn + "/Var", "w", encoding="utf-8")
    filh.write(lag1namn + " VS " + lag2namn)
    filh.close()
    filh = open(".skapade lag/" + lag2namn + "/Var", "w", encoding="utf-8")
    filh.write(lag1namn + " VS " + lag2namn)
    filh.close()

    filh = open(vagh + "/Lag1", "w", encoding="utf-8")
    filh.write(str(lag1namn))
    filh.close()
    filh = open(vagh + "/Lag2", "w", encoding="utf-8")
    filh.write(str(lag2namn))
    filh.close()

    filh = open(vagh + "/T", "w", encoding="utf-8")
    filh.write(str(tur))
    filh.close()
    filh = open(vagh + "/B", "w", encoding="utf-8")
    filh.write(str(bollruta))
    filh.close()
    filh = open(vagh + "/Bö", "w", encoding="utf-8")
    filh.write(str(borjar))
    filh.close()
    filh = open(vagh + "/PH", "w", encoding="utf-8")
    listh = [True, True]
    if not handoffat:
        listh[0] = ""
    if not passat:
        listh[1] = ""
    filh.write(str(listh[0]) + "\n" + str(listh[1]))
    filh.close()
    filh = open(vagh + "/D", "w", encoding="utf-8")
    filh.write(str(drag))
    filh.close()

    filh = open(vagh + "/TD", "w", encoding="utf-8")
    filh.write(str(td1) + "\n" + str(td2))
    filh.close()

    filh = open(vagh + "/Tä", "w", encoding="utf-8")
    stringh = ""
    for sh in tarningsslag:
        stringh += sh + "\n"
    filh.write(stringh.strip())
    filh.close()

    filh = open(vagh + "/RR", "w", encoding="utf-8")
    filh.write(str(anvantrr) + "\n" + str(rerolls1) + "/" + str(rerolls2) + "\n" + str(bribes1) + "/" + str(bribes2)
               + "\n" + str(bwbs1) + "/" + str(bwbs2))
    filh.close()

    filh = open(vagh + "/Apo", "w", encoding="utf-8")
    filh.write(str(kanapo1) + "\n" + str(kanapo2))
    filh.close()

    filh = open(vagh + "/F", "w", encoding="utf-8")
    filh.write(str(foulat))
    filh.close()

    filh = open(vagh + "/KO", "w", encoding="utf-8")
    filh.write(str(kickoffh) + "\n" + str(vemborjar))
    filh.close()

    filh = open(vagh + "/V", "w", encoding="utf-8")
    filh.write(vadertillbild + "\n" + vader)
    filh.close()

    if splasha:
        splash_message("Match sparad", tid=2.0)


def ladda_match():
    try:
        global tur, bollruta, borjar, passat, handoffat, drag, td1, td2, tarningsslag, anvantrr, rerolls1, rerolls2, \
            kanapo1, kanapo2, foulat, vadertillbild, vader, bribes1, bribes2, bwbs1, bwbs2
        vagh = ".matcher/" + lag1namn + " VS " + lag2namn
        numh = 0
        for vh in alla_spelare1:
            filh = open(vagh + "/1/" + vh.spelare.namn, "rb")
            alla_spelare1[numh] = pickle.load(filh)
            filh.close()
            numh += 1
        numh = 0
        for vh in alla_spelare2:
            filh = open(vagh + "/2/" + vh.spelare.namn, "rb")
            alla_spelare2[numh] = pickle.load(filh)
            filh.close()
            numh += 1
        filh = open(vagh + "/T", "r", encoding="utf-8")
        tur = int(filh.read().strip())
        filh.close()
        filh = open(vagh + "/B", "r", encoding="utf-8")
        bollruta = int(filh.read().strip())
        filh.close()
        filh = open(vagh + "/Bö", "r", encoding="utf-8")
        borjar = int(filh.read().strip())
        filh.close()
        filh = open(vagh + "/PH", "r", encoding="utf-8")
        ett, tva = filh.read().split("\n")
        if ett:
            handoffat = True
        else:
            handoffat = False
        if tva:
            passat = True
        else:
            passat = False
        filh.close()

        filh = open(vagh + "/D", "r", encoding="utf-8")
        drag = int(filh.read())
        filh.close()

        filh = open(vagh + "/TD", "r", encoding="utf-8")
        tdlist = filh.read().split("\n")
        td1, td2 = int(tdlist[0]), int(tdlist[1])
        filh.close()

        filh = open(vagh + "/Tä", "r", encoding="utf-8")
        tarningsslag = filh.read().split("\n")
        filh.close()

        filh = open(vagh + "/RR", "r", encoding="utf-8")
        red = filh.read()
        anvantrr = red.split("\n")[0].strip()
        if anvantrr == "True":
            anvantrr = True
        else:
            anvantrr = False
        rerolls1, rerolls2 = int(red.split("\n")[1].split("/")[0]), int(red.split("\n")[1].split("/")[1])
        bribes1, bribes2 = int(red.split("\n")[2].split("/")[0]), int(red.split("\n")[2].split("/")[1])
        bwbs1, bwbs2 = int(red.split("\n")[3].split("/")[0]), int(red.split("\n")[3].split("/")[1])
        filh.close()

        filh = open(vagh + "/Apo", "r", encoding="utf-8")
        data = filh.read().split("\n")
        kanapo1 = int(data[0])
        kanapo2 = int(data[1])
        filh.close()

        filh = open(vagh + "/F", "r", encoding="utf-8")
        if filh.read() == "True":
            foulat = True
        else:
            foulat = False
        filh.close()

        filh = open(vagh + "/V", "r", encoding="utf-8")
        lasning = filh.read().split("\n")
        vadertillbild = lasning[0]
        vader = lasning[1]
        filh.close()

        filh = open(vagh + "/KO", "r", encoding="utf-8")
        lasning = filh.read()
        filh.close()
        if lasning.split("\n")[0] == "True":
            return "kick-off", int(lasning.split("\n")[1])

        return None, None
    except Exception as e:
        print(e)
        splash_message("Error!!!")
        pygame_input(gameDisplay, str(e))
        pygame_input(gameDisplay, "Vänligen kontakta kundsupport.")
        quit()


def inducements():
    global rerolls1, rerolls2, bribes1, bribes2

    def pettycash(lagh):
        gameDisplay.fill((200, 16, 79))
        nonlocal pettycash1, pettycash2
        if fraga(gameDisplay, "Vill " + globals()["lag" + str(lagh) + "namn"] + " överföra guld till petty cash (" +
                              str(globals()["pengar" + str(lagh)]) + " i treasury)?",
                 mus, pekmus):
            forslag = pygame_input(gameDisplay, "Hur många tusen?")
            while True:
                try:
                    gameDisplay.fill((200, 16, 79))
                    if lagh == 1:
                        pettycash1 = int(round(int(forslag) * 1000, -4))
                        if pengar1 < pettycash1:
                            raise ArithmeticError
                    else:
                        pettycash2 = int(round(int(forslag) * 1000, -4))
                        if pengar2 < pettycash2:
                            raise ArithmeticError
                    if fraga(gameDisplay, "Är du säker på att överföra " + str(int(round(int(forslag) * 1000, -4))) +
                                          " till petty cash?", mus, pekmus):
                        break
                    else:
                        forslag = pygame_input(gameDisplay, "Okej då, hur många tusen istället?")
                        gameDisplay.fill((200, 16, 79))

                except ValueError:
                    forslag = pygame_input(gameDisplay, "ERROR! Hur många tusen?")
                except ArithmeticError:
                    forslag = pygame_input(gameDisplay, "För lite i treasury! Hur många tusen?")

    teamvalue1, teamvalue2 = 0, 0
    for vh in alla_spelare1:
        teamvalue1 += vh.spelare.pengavarde
    for vh in alla_spelare2:
        teamvalue2 += vh.spelare.pengavarde
    teamvalue1 += rerolls1 * rrcost1
    teamvalue2 += rerolls2 * rrcost2
    if harapo1:
        teamvalue1 += 50000
    if harapo2:
        teamvalue2 += 50000

    pettycash1, pettycash2 = 0, 0

    if teamvalue1 > teamvalue2:
        pettycash(1)
        pettycash(2)
    else:
        pettycash(2)
        pettycash(1)

    teamvalue1 += pettycash1
    teamvalue2 += pettycash2

    indmoney1, indmoney2 = 0, 0

    bytt = False

    if teamvalue1 > teamvalue2:
        vemstur = 1
        indmoney2 += teamvalue1 - teamvalue2
    else:
        vemstur = 2
        indmoney1 += teamvalue2 - teamvalue1

    indmoney1 += pettycash1
    indmoney2 += pettycash2

    yborj = 100

    rrh, aph, bwh = 0, 0, 0

    babesknapp = knapp(gameDisplay, "Bloodweiser Babe 0/2", (0, 0 + yborj))
    bribesknapp = knapp(gameDisplay, "Bribe 0/3", (0, 50 + yborj))
    rerollknapp = knapp(gameDisplay, "Extra Team Training 0/4", (0, 100 + yborj))
    hafmaschefknapp = knapp(gameDisplay, "Hafling Master Chef 0/1", (0, 150 + yborj))
    apoknapp = knapp(gameDisplay, "Wandering Apothecary 0/2", (0, 200 + yborj))
    igorknapp = knapp(gameDisplay, "Igor 0/1", (0, 200 + yborj))
    wizardknapp = knapp(gameDisplay, "Wizard 0/1", (0, 250 + yborj))
    klarknapp = knapp(gameDisplay, "Klar", (0, 350 + yborj), 50, (0, 255, 50))

    kor = True
    while kor:
        for eventh in pygame.event.get():
            if eventh.type == pygame.QUIT:
                quit()
            if eventh.type == pygame.MOUSEBUTTONDOWN:
                if klarknapp.ar_aktiv():
                    rrh, aph, bwh = 0, 0, 0
                    babesknapp = knapp(gameDisplay, "Bloodweiser Babe 0/2", (0, 0 + yborj))
                    bribesknapp = knapp(gameDisplay, "Bribe 0/3", (0, 50 + yborj))
                    rerollknapp = knapp(gameDisplay, "Extra Team Training 0/4", (0, 100 + yborj))
                    hafmaschefknapp = knapp(gameDisplay, "Hafling Master Chef 0/1", (0, 150 + yborj))
                    apoknapp = knapp(gameDisplay, "Wandering Apothecary 0/2", (0, 200 + yborj))
                    igorknapp = knapp(gameDisplay, "Igor 0/1", (0, 200 + yborj))
                    wizardknapp = knapp(gameDisplay, "Wizard 0/1", (0, 250 + yborj))
                    if vemstur == 1:
                        if bytt:
                            kor = False
                        else:
                            vemstur = 2
                            bytt = True
                    else:
                        if bytt:
                            kor = False
                        else:
                            vemstur = 1
                            bytt = True
                elif rerollknapp.ar_aktiv():
                    if rrh < 4 and locals()["indmoney" + str(vemstur)] >= 100000:
                        splitt = rerollknapp.text.split("/")
                        rerollknapp.text = splitt[0][:-1] + str(int(splitt[0][-1]) + 1) + "/" + splitt[1]
                        rrh += 1
                        if vemstur == 1:
                            rerolls1 += 1
                            indmoney1 -= 100000
                        else:
                            rerolls2 += 1
                            indmoney2 -= 100000
                elif bribesknapp.ar_aktiv():
                    if locals()["indmoney" + str(vemstur)] >= 100000 and globals()["bribes" + str(vemstur)] < 3:
                        splitt = bribesknapp.text.split("/")
                        bribesknapp.text = splitt[0][:-1] + str(int(splitt[0][-1]) + 1) + "/" + splitt[1]
                        globals()["bribes" + str(vemstur)] += 1
                        if vemstur == 1:
                            indmoney1 -= 100000
                        else:
                            indmoney2 -= 100000
                elif apoknapp.ar_aktiv() and globals()["farhaapo" + str(vemstur)]:
                    if locals()["indmoney" + str(vemstur)] >= 100000 and aph < 2:
                        splitt = apoknapp.text.split("/")
                        apoknapp.text = splitt[0][:-1] + str(int(splitt[0][-1]) + 1) + "/" + splitt[1]
                        globals()["kanapo" + str(vemstur)] += 1
                        if vemstur == 1:
                            indmoney1 -= 100000
                        else:
                            indmoney2 -= 100000
                        aph += 1
                elif babesknapp.ar_aktiv():
                    if locals()["indmoney" + str(vemstur)] >= 50000 and bwh < 2:
                        splitt = babesknapp.text.split("/")
                        babesknapp.text = splitt[0][:-1] + str(int(splitt[0][-1]) + 1) + "/" + splitt[1]
                        globals()["bwbs" + str(vemstur)] += 1
                        if vemstur == 1:
                            indmoney1 -= 50000
                        else:
                            indmoney2 -= 50000
                        bwh += 1
        gameDisplay.fill((200, 16, 79))
        skriv(gameDisplay, vettigt_s(
            globals()["lag" + str(vemstur) + "namn"]) + " inducements", (0, 0), 70, fetstil=True)
        skriv(gameDisplay, str(locals()["indmoney" + str(vemstur)]), (0, 50), 50)
        babesknapp.rita()
        bribesknapp.rita()
        rerollknapp.rita()
        hafmaschefknapp.rita()
        klarknapp.rita()
        if globals()["farhaapo" + str(vemstur)]:
            apoknapp.rita()
        else:
            igorknapp.rita()
        wizardknapp.rita()

        if babesknapp.ar_aktiv() or bribesknapp.ar_aktiv() or rerollknapp.ar_aktiv() or hafmaschefknapp.ar_aktiv() or \
                (globals()["farhaapo" + str(vemstur)] and apoknapp.ar_aktiv()) or (not globals()["farhaapo" + str(
            vemstur)] and igorknapp.ar_aktiv()) or wizardknapp.ar_aktiv() or klarknapp.ar_aktiv():
            gameDisplay.blit(pekmus, pygame.mouse.get_pos())
        else:
            gameDisplay.blit(mus, pygame.mouse.get_pos())

        pygame.display.update()
    filh = open(".skapade lag/" + lag1namn + "/Pengar", "w")
    filh.write(str(pengar1 - pettycash1))
    filh.close()
    filh = open(".skapade lag/" + lag2namn + "/Pengar", "w")
    filh.write(str(pengar2 - pettycash2))
    filh.close()


def trilla(person, splasha=True, anfallare=None, injurydirect=False, bonus=0, foulperson=None):
    harmajty = False
    harklor = False
    if anfallare is not None:
        harmajty = anfallare.spelare.skills.__contains__("mighty blow")
        harklor = anfallare.spelare.skills.__contains__("claws") or anfallare.spelare.skills.__contains__("claw")
    if foulperson is not None:
        harmajty = foulperson.spelare.skills.__contains__("dirty player")
    if harklor:
        paplaninfo.append(("Claws", fa_pos(anfallare.ruta)))
    elif harmajty:
        paplaninfo.append(("Mighty Blow", fa_pos(anfallare.ruta)))
    anvantmajty = False

    e, t = 0, 0
    person.star = False
    person.fastvaxt = False
    if not injurydirect:
        e, t = random.randint(1, 6), random.randint(1, 6)
        if foulperson is not None:
            if e == t:
                mutad, mutslag = False, 0
                if globals()["bribes" + str(vilket_lag(foulperson))] > 0 and fraga(
                        gameDisplay, "Domaren upptäckte " + foulperson.spelare.namn + "! Vill du muta domaren?",
                        mus, pekmus):
                    mutad = True
                    mutslag = random.randint(1, 6)
                    tarningsslag.append("T6 (muta): " + str(mutslag))
                if not mutad or mutslag == 1:
                    foulperson.skadad = "utvisad"
                    foulperson.ruta = 1000
                    splash_message(foulperson.spelare.namn + " blev utvisad!", tid=1.5)
                if mutad:
                    globals()["bribes" + str(vilket_lag(foulperson))] -= 1
        slag = e + t
        slag += bonus
        tarningsslag.append("2T6 ('" + person.spelare.namn + "' rustning): " + str(e) + "+" + str(t) + "=" + str(slag))
    else:
        slag = 12
    if slag > person.spelare.varden[3] or (harmajty and slag + 1 > person.spelare.varden[3]) or (
            harklor and slag > 7) or (harklor and harmajty and slag + 1 > 7):
        if (harmajty and slag + 1 > person.spelare.varden[3] >= slag and not (harklor and slag + 1 > 7)) \
                or (harmajty and harklor and slag <= person.spelare.varden[3] and slag + 1 > 7 >= slag):
            anvantmajty = True
            tarningsslag.pop(-1)
            tarningsslag.append("2T6 ('" + person.spelare.namn + "' rustning): " + str(e) + "+" + str(t) +
                                "=" + str(slag + 1))
        e, t = random.randint(1, 6), random.randint(1, 6)
        if foulperson is not None:
            if e == t:
                mutad, mutslag = False, 0
                if globals()["bribes" + str(vilket_lag(foulperson))] > 0 and fraga(
                        gameDisplay, "Domaren upptäckte " + foulperson.spelare.namn + "! Vill du muta domaren?",
                        mus, pekmus):
                    mutad = True
                    mutslag = random.randint(1, 6)
                    tarningsslag.append("T6 (muta): " + str(mutslag))
                if not mutad or mutslag == 1:
                    foulperson.skadad = "utvisad"
                    foulperson.ruta = 1000
                    splash_message(foulperson.spelare.namn + " blev utvisad!", tid=1.5)
                if mutad:
                    globals()["bribes" + str(vilket_lag(foulperson))] -= 1
        slag2 = e + t
        slag2 += person.spelare.nig
        if harmajty and not anvantmajty:
            slag2 += 1
        tarningsslag.append("2T6 ('" + person.spelare.namn + "' injury-tabellen): " + str(e) + "+" + str(t) + "=" +
                            str(slag2))
        if slag2 == 8 and person.spelare.skills.__contains__("thick skull"):
            paplaninfo.append(("thick skull", fa_pos(person.ruta)))
        if slag2 > 7 or (slag2 > 6 and person.spelare.skills.__contains__("stunty")):
            if slag2 > 9 or (slag2 > 8 and person.spelare.skills.__contains__("stunty")):
                if anfallare:
                    anfallare.spelare.spp += 2
                    anfallare.spelare.casualties += 1
                    paplaninfo.append(("+2 SPP", fa_pos(anfallare.ruta)))
                skada = "badly hurt"
                if slag2 != 9:
                    skada = casualty(person, tarningsslag)
                if splasha and splashaskador:
                    if skada == "död":
                        splash_message(person.spelare.namn + " är " + skada + "!")
                    else:
                        splash_message(person.spelare.namn + " blev skadad: " + skada + "!")

                #
                if globals()["kanapo" + str(vem_star_har(person.ruta, True)[1])]:
                    apoja = knapp(gameDisplay, "Ja", (10, 70))
                    aponej = knapp(gameDisplay, "Nej", (10, 110))
                    rita(False)
                    gameDisplay.blit(globals()["Cirkelrödbild"], fa_pos(person.ruta))
                    skriv(gameDisplay, "Vill du använda apotekare?", (0, 0), 50)
                    apoja.rita()
                    aponej.rita()
                    alltsurh = gameDisplay.copy().convert()
                    japp = True
                    while japp:
                        for eventh in pygame.event.get():
                            if eventh.type == pygame.MOUSEBUTTONDOWN:
                                if apoja.ar_aktiv():
                                    globals()["kanapo" + str(vilket_lag(person))] -= 1
                                    skada2 = casualty(person, tarningsslag)
                                    ettknapp = knapp(gameDisplay, "Apotekarslag: " + skada2, (10, 70))
                                    tvaknapp = knapp(gameDisplay, "Från början: " + skada, (10, 120))
                                    rita(False)
                                    gameDisplay.blit(globals()["Cirkelrödbild"], fa_pos(person.ruta))
                                    ettknapp.rita()
                                    tvaknapp.rita()
                                    alltsurh = gameDisplay.copy().convert()
                                    jojo = True
                                    while jojo:
                                        for event2h in pygame.event.get():
                                            if event2h.type == pygame.MOUSEBUTTONDOWN:
                                                if ettknapp.ar_aktiv():
                                                    if skada2 == "badly hurt":
                                                        skada = ""
                                                    else:
                                                        skada = skada2
                                                    jojo = False
                                                elif tvaknapp.ar_aktiv():
                                                    if skada == "badly hurt":
                                                        skada = ""
                                                    jojo = False
                                        gameDisplay.blit(alltsurh, (0, 0))
                                        if ettknapp.ar_aktiv() or tvaknapp.ar_aktiv():
                                            gameDisplay.blit(pekmus, pygame.mouse.get_pos())
                                        else:
                                            gameDisplay.blit(mus, pygame.mouse.get_pos())
                                        pygame.display.update()
                                    japp = False
                                    continue
                                elif aponej.ar_aktiv():
                                    japp = False
                                    continue
                        gameDisplay.blit(alltsurh, (0, 0))
                        if apoja.ar_aktiv() or aponej.ar_aktiv():
                            gameDisplay.blit(pekmus, pygame.mouse.get_pos())
                        else:
                            gameDisplay.blit(mus, pygame.mouse.get_pos())
                        pygame.display.update()

                #
                if skada:
                    if not person.spelare.skills.__contains__("regeneration") or tarning(
                            person.spelare.namn + " försöker använda regeneration, 4+", "regeneration", mojligrr=False
                    ) < 4:
                        if skada != "badly hurt":
                            person.spelare.skadad = skada
                        person.skadad = skada
                        if skada == "-1 MA":
                            if person.spelare.varden[0] - 1 > 0:
                                person.spelare.varden[0] -= 1
                        elif skada == "-1 AV":
                            if person.spelare.varden[3] - 1 > 0:
                                person.spelare.varden[3] -= 1
                        elif skada == "-1 AG":
                            if person.spelare.varden[2] - 1 > 0:
                                person.spelare.varden[2] -= 1
                        elif skada == "-1 ST":
                            if person.spelare.varden[1] - 1 > 0:
                                person.spelare.varden[1] -= 1
                        elif skada == "niggling injury":
                            person.spelare.nig += 1
                person.ruta = 1000
                return skada
            elif not person.spelare.skills.__contains__("thick skull") or slag2 == 9:
                person.skadad = "knocked-out"
                person.ruta = 1000
                if splasha and splashaskador:
                    splash_message(person.spelare.namn + " blev knocked-out!")
                return "knocked-out"
            else:
                person.skadad = "stunned"
                if splasha and splashaskador:
                    splash_message(person.spelare.namn + " blev stunned!")
                return "stunned"
        else:
            person.skadad = "stunned"
            if splasha and splashaskador:
                splash_message(person.spelare.namn + " blev stunned!")
            return "stunned"


def vem_star_har(ruta, return_team=False):
    for vh in alla_spelare1:
        if vh.ruta == ruta:
            if return_team:
                return vh, 1
            else:
                return vh
    for vh in alla_spelare2:
        if vh.ruta == ruta:
            if return_team:
                return vh, 2
            else:
                return vh
    if return_team:
        return None, None


def vilket_lag(person):
    for vh in alla_spelare1:
        if vh == person:
            return 1
    for vh in alla_spelare2:
        if vh == person:
            return 2


def valj_person(lag):
    yh = 0
    knappar = []
    for vh in lag:
        if vh.ruta == 1000:
            if vh.skadad:
                skad = " (" + vh.skadad + ")"
                fargh = (255, 0, 0)
            else:
                skad = ""
                fargh = (0, 0, 0)
            locals()["knapp" + vh.spelare.namn] = knapp(
                gameDisplay, vh.spelare.typ + ": " + vh.spelare.namn + skad, (0, yh), 40, fargh)
            knappar.append(vh.spelare.namn)
        yh += 40
    rita(False)
    for vh in knappar:
        locals()["knapp" + vh].rita()
    alltsurh = gameDisplay.copy().convert()
    while True:
        gameDisplay.blit(alltsurh, (0, 0))
        for eventh in pygame.event.get():
            if eventh.type == pygame.MOUSEBUTTONDOWN:
                if eventh.button == 1:
                    for vh in lag:
                        if vh.ruta == 1000:
                            if locals()["knapp" + vh.spelare.namn].ar_aktiv():
                                return vh
                if eventh.button == 3:
                    return None

        peka = False
        for vh in knappar:
            if locals()["knapp" + vh].ar_aktiv():
                peka = True
        musposh = pygame.mouse.get_pos()
        if peka:
            gameDisplay.blit(pekmus, musposh)
        else:
            gameDisplay.blit(mus, musposh)

        pygame.display.update()


def intercept(rutor, lagsomkastar):
    if lagsomkastar == 1:
        intlag = 2
    else:
        intlag = 1

    cont = False  # continue
    for rh in rutor:
        if vem_star_har(rh, True)[1] == intlag:
            cont = True

    if not cont:
        return

    rita(False)
    bakgrundenh = gameDisplay.copy()


    while True:
        musposh = pygame.mouse.get_pos()
        rutanh = vilken_ruta(musposh)
        person, lagh = vem_star_har(rutanh, True)

        gameDisplay.blit(bakgrundenh, (0, 0))

        if rutanh in rutor and lagh == intlag and person.star and person.tacklezone:
            gameDisplay.blit(globals()["Grön markörbild"], fa_pos(rutanh))
            rita_stats(person)
        else:
            gameDisplay.blit(globals()["Cancelbild"], fa_pos(rutanh))

        skriv(gameDisplay, "Välj en person som ska försöka intercepta", (10, 10))

        gameDisplay.blit(mus, musposh)

        pygame.display.update()

        for eventh in pygame.event.get():
            if eventh.type == pygame.MOUSEBUTTONDOWN:
                if eventh.button == 3:
                    return None
                if eventh.button == 1:
                    person = vem_star_har(rutanh)
                    if rutanh in rutor and vem_star_har(rutanh, True)[1] == intlag and \
                            person.star and person.tacklezone:
                        plush = aglist[person.spelare.varden[2]]

                        plush += 2

                        plush += tackle_zones(person)

                        if person.spelare.skills.__contains__("very long legs"):
                            plush -= 1
                            paplaninfo.append(("very long legs", fa_pos(person.ruta)))

                        if plush > 6:
                            plush = 6
                        if plush < 2:
                            plush = 2

                        if tarning(person.spelare.namn + " försöker intercepta med " + str(plush) + "+...",
                                   "interception", person, "catch", plush) >= plush:
                            person.spelare.spp += 2
                            person.spelare.interceptions += 1
                            paplaninfo.append(("+2 SPP", fa_pos(person.ruta)))
                            return person
                        else:
                            return None


def passa(person):
    global bollruta, passat, passfailnu  # förklaring till passfailnu finns i yttersta scopet, passat är om man har
    # passat det draget
    rita(False)
    alltsurh = gameDisplay.copy().convert()
    blittrutorh = []
    locked = None

    def las_ruta():
        nonlocal locked, blittrutorh
        locked = rutah
        # under här blittas personer som kan intercepta
        if rutah != person.ruta and langd:
            blittrutorh = []
            for rhh in interceptrutor(bollruta, rutah):
                phh, lhh = vem_star_har(rhh, True)
                if phh is not None and phh.star and phh.tacklezone and lhh != vilket_lag(person):
                    blittrutorh.append(rhh)

    while True:
        gameDisplay.blit(alltsurh, (0, 0))
        musposh = pygame.mouse.get_pos()
        rutah = vilken_ruta(musposh)

        rutasomgaller = rutah

        if locked:
            rutasomgaller = locked

        langd = kolla_langden(person.ruta, rutasomgaller)

        farg = (30, 30, 30)

        if rutasomgaller < 390:
            if langd == "bomb":
                farg = (255, 0, 0)
            elif langd == "long":
                farg = (255, 97, 3)
            elif langd == "short":
                farg = (255, 215, 0)
            elif langd == "quick":
                farg = (0, 255, 0)

        darpos = fa_pos(rutasomgaller)

        pos1, pos2 = fa_pos(person.ruta), darpos
        pygame.draw.line(gameDisplay, farg, (pos1[0] + 22, pos1[1] + 22), (pos2[0] + 22, pos2[1] + 22), 5)

        for rh in blittrutorh:
            gameDisplay.blit(globals()["Cirkelrödbild"], (fa_pos(rh)))

        if langd == "" or rutasomgaller > 389:
            gameDisplay.blit(globals()["Cancelbild"], darpos)
        else:
            if vem_star_har(rutasomgaller) is not None:
                if vem_star_har(rutasomgaller, True)[1] == tur:
                    gameDisplay.blit(globals()["Grön markörbild"], darpos)
                else:
                    gameDisplay.blit(globals()["Röd markörbild"], darpos)
            else:
                gameDisplay.blit(globals()["Röd markörbild"], darpos)

        if locked:
            skriv(gameDisplay, "Tryck igen för att passa", (10, 10))
            skriv(gameDisplay, "Högerklicka för att avbryta", (10, 45))

        gameDisplay.blit(mus, musposh)
        pygame.display.update()

        for eventh in pygame.event.get():
            if eventh.type == pygame.MOUSEBUTTONDOWN:
                blittrutorh = []
                if eventh.button == 1:
                    if locked is None:
                        if langd:
                            las_ruta()
                    else:
                        if rutah != locked:
                            if kolla_langden(person.ruta, rutah):
                                las_ruta()
                        else:
                            if gor_nagot(person, tur):
                                rutanh = locked

                                langd = kolla_langden(person.ruta, rutanh)
                                if langd != "" and rutanh < 390 and (
                                        vader != "blizzard" or langd == "short" or langd == "quick"):

                                    interceptor = intercept(interceptrutor(bollruta, rutanh), tur)

                                    if interceptor is not None:
                                        person.har_bollen = False
                                        interceptor.har_bollen = True
                                        bollruta = interceptor.ruta
                                        animera(person.ruta, interceptor.ruta)
                                        rita()
                                        nasta_drag("Turnover (interception)!")
                                        return

                                    modify = 0
                                    if vader == "very sunny":
                                        modify -= 1
                                    if langd == "bomb":
                                        modify -= 2
                                    elif langd == "long":
                                        modify -= 1
                                    elif langd == "quick":
                                        modify += 1
                                    if not person.spelare.skills.__contains__("nerves of steel"):
                                        modify -= tackle_zones(person)
                                    modify -= disturbing_presence(person.ruta)
                                    if person.spelare.skills.__contains__("stunty"):
                                        modify -= 1
                                    if person.spelare.skills.__contains__("accurate"):
                                        modify += 1
                                    if person.spelare.skills.__contains__("strong arm") and langd != "quick":
                                        modify += 1
                                    ag = int(person.spelare.varden[2])
                                    mer = aglist[ag]
                                    slag = tarning(person.spelare.namn + " försöker passa, med " + str(mer - modify) + "+",
                                                   "pass", person, "pass", mer - modify)
                                    oslag = slag
                                    slag += modify
                                    person.har_bollen = False
                                    if slag <= 1 or oslag == 1:
                                        passfailnu = True
                                        try:
                                            if ball_bounce() == "denfor":
                                                inkast()
                                        except BreakOut:
                                            return
                                        bra = False
                                    else:
                                        if animeringar:
                                            animera(bollruta, rutanh)

                                        bollruta = rutanh

                                        ute = False
                                        acc = True
                                        if slag < mer and oslag != 6:
                                            acc = False
                                            for _ in range(0, 3):
                                                if ball_scatter() == "denfor":
                                                    inkast()
                                                    ute = True
                                                    break
                                        if not ute:
                                            ph, lh = vem_star_har(bollruta, True)
                                            if ph is not None:
                                                if acc:
                                                    if fanga(True, passperson=person) == "denfor":
                                                        inkast()
                                                else:
                                                    if fanga(False) == "denfor":
                                                        inkast()
                                            else:
                                                try:
                                                    if ball_bounce() == "denfor":
                                                        inkast()
                                                except BreakOut:
                                                    return
                                        bra = False
                                        if tur == 1:
                                            for vh in alla_spelare1:
                                                if vh.har_bollen:
                                                    bra = True
                                        if tur == 2:
                                            for vh in alla_spelare2:
                                                if vh.har_bollen:
                                                    bra = True
                                    person.fardig = True
                                    passat = True
                                    if not bra:
                                        nasta_drag("Turnover")
                                    return
                if eventh.button == 3:
                    if locked:
                        locked = None
                    else:
                        return


def handoffa(person):
    global bollruta, handoffat
    rita(False)
    alltsurh = gameDisplay.copy().convert()
    while True:
        gameDisplay.blit(alltsurh, (0, 0))

        musposh = pygame.mouse.get_pos()
        rutanh = vilken_ruta(musposh)
        ja = False
        for numh in listahall:
            if not far_nagot_ut(person.ruta, numh):
                if rutanh == person.ruta + numh:
                    ja = True

        vem, lag = vem_star_har(rutanh, True)
        if vem is not None:
            if lag == tur:
                bra = True
            else:
                bra = "nja"
        else:
            bra = False
        if ja:
            if bra == "nja":
                gameDisplay.blit(globals()["Röd markörbild"], fa_pos(rutanh))
            elif bra:
                gameDisplay.blit(globals()["Grön markörbild"], fa_pos(rutanh))
            else:
                gameDisplay.blit(globals()["Cancelbild"], fa_pos(rutanh))
        else:
            gameDisplay.blit(globals()["Cancelbild"], fa_pos(rutanh))

        gameDisplay.blit(mus, musposh)

        for eventh in pygame.event.get():
            if eventh.type == pygame.MOUSEBUTTONDOWN:
                if eventh.button == 1:
                    if ja:
                        if bra:
                            if gor_nagot(person, tur):
                                person.har_bollen = False
                                if animeringar:
                                    animera(bollruta, rutanh)
                                bollruta = rutanh
                                fanga(True)
                                turnover = True
                                if tur == 1:
                                    for vh in alla_spelare1:
                                        if vh.har_bollen:
                                            turnover = False
                                if tur == 2:
                                    for vh in alla_spelare2:
                                        if vh.har_bollen:
                                            turnover = False
                                person.fardig = True
                                handoffat = True
                                if turnover:
                                    nasta_drag("Turnover")
                                return
                        else:
                            return
                    else:
                        return
                if eventh.button == 3:
                    return
        pygame.display.update()


def throw_team_mate(person):
    global bollruta, passat
    rita(False)
    alltsurh = gameDisplay.copy().convert()
    nagot = False
    kastperson = None
    while not nagot:
        gameDisplay.blit(alltsurh, (0, 0))

        rutanh = vilken_ruta(pygame.mouse.get_pos())
        ja = False
        for numh in listahall:
            if rutanh == person.ruta + numh:
                ja = True

        bra = False
        vem, lag = vem_star_har(rutanh, True)
        if vem is not None:
            if lag == tur:
                if vem.spelare.skills.__contains__("right stuff") and vem.star:
                    bra = True
        if ja:
            if bra:
                gameDisplay.blit(globals()["Grön markörbild"], fa_pos(rutanh))
            else:
                gameDisplay.blit(globals()["Cancelbild"], fa_pos(rutanh))
        else:
            gameDisplay.blit(globals()["Cancelbild"], fa_pos(rutanh))

        for eventh in pygame.event.get():
            if eventh.type == pygame.MOUSEBUTTONDOWN:
                if eventh.button == 1:
                    if ja and bra:
                        kastperson = vem
                        nagot = True
                if eventh.button == 3:
                    return
        gameDisplay.blit(mus, pygame.mouse.get_pos())
        pygame.display.update()

    rita(False)
    gameDisplay.blit(globals()["Cirkelgrönbild"], fa_pos(kastperson.ruta))
    gameDisplay.blit(globals()["Cirkelvitbild"], fa_pos(person.ruta))
    alltsurh = gameDisplay.copy().convert()
    turno = False
    while True:
        musposh = pygame.mouse.get_pos()
        rutah = vilken_ruta(musposh)

        langd = kolla_langden(person.ruta, rutah)

        farg = (30, 30, 30)

        if langd == "short":
            farg = (255, 215, 0)
        elif langd == "quick":
            farg = (0, 255, 0)

        gameDisplay.blit(alltsurh, (0, 0))

        pos1, pos2 = fa_pos(person.ruta), fa_pos(rutah)
        pygame.draw.line(gameDisplay, farg, (pos1[0] + 22, pos1[1] + 22), (pos2[0] + 22, pos2[1] + 22), 5)

        if langd == "quick" or langd == "short":
            gameDisplay.blit(globals()["Grön markörbild"], fa_pos(rutah))
        else:
            gameDisplay.blit(globals()["Cancelbild"], fa_pos(rutah))

        gameDisplay.blit(mus, musposh)

        for eventh in pygame.event.get():
            if eventh.type == pygame.MOUSEBUTTONDOWN:
                if eventh.button == 3:
                    return
                if eventh.button == 1:
                    if langd == "quick" or langd == "short":
                        if gor_nagot(person, tur):
                            passat = True
                            person.fardig = True
                            if not person.spelare.skills.__contains__("always hungry") or tarning(
                                    person.spelare.namn + " försöker att inte bli hungrig , 2+", "always hungry",
                                    person, lyckas=2) >= 2:
                                modify = 0
                                if langd == "short":
                                    modify += 1
                                modify += tackle_zones(person)
                                modify += disturbing_presence(person.ruta)
                                if person.spelare.skills.__contains__("strong arm") and langd == "short":
                                    modify -= 1
                                if person.spelare.skills.__contains__("accurate"):
                                    modify -= 1
                                slag = tarning(person.spelare.namn + " försöker kasta " + kastperson.spelare.namn + ", "
                                               + str(2 + modify) + "+", "TTM", person, "pass", 2 + modify)
                                oslag = slag
                                slag -= modify
                                if (slag >= 2 or slag == 6 or oslag == 6) and oslag != 1:
                                    kastperson.ruta = rutah
                                    if kastperson.har_bollen:
                                        bollruta = rutah
                                    for _ in range(0, 3):
                                        hall = random.choice(listahall)
                                        tarningsslag.append("T8 (person-scatter): " + str(listahall.index(hall) + 1))
                                        if not far_spelaren_ut(kastperson, hall):
                                            kastperson.ruta += hall
                                            if kastperson.har_bollen:
                                                bollruta += hall
                                            rita(True)
                                            pygame.display.update()
                                        else:
                                            splash_message(kastperson.spelare.namn + " kastades av plan!", tid=2.0)
                                            kastperson.ruta = 1000
                                            trilla(kastperson, True, None, True)
                                            turno = True
                                            if kastperson.har_bollen:
                                                kastperson.har_bollen = False
                                                inkast()
                                            break
                            else:
                                if tarning(person.spelare.namn + " försöker att inte äta upp " +
                                           kastperson.spelare.namn + ", 2+", "always hungry", person, lyckas=2) == 1:
                                    kastperson.skadad = "död"
                                    kastperson.spelare.skadad = "död"
                                    splash_message(kastperson.spelare.namn + " blev uppäten!")
                                    if kastperson.har_bollen:
                                        kastperson.har_bollen = False
                                        try:
                                            if ball_bounce() == "denfor":
                                                inkast()
                                        except BreakOut:
                                            return

                            if kastperson.skadad != "död":
                                if kastperson.ruta != 1000:
                                    nandar, vemdar, failland = False, None, False
                                    for vh in alla_spelare1:
                                        if vh.ruta == kastperson.ruta and not vh == kastperson:
                                            nandar, vemdar = True, vh
                                            break
                                    for vh in alla_spelare2:
                                        if vh.ruta == kastperson.ruta and not vh == kastperson:
                                            nandar, vemdar = True, vh
                                            break
                                    if nandar:
                                        failland = True
                                        trilla(vemdar)
                                        if vilket_lag(vemdar) == tur:
                                            turno = True
                                    while nandar:
                                        hall = random.choice(listahall)
                                        tarningsslag.append("T8 (person-bounce): " + str(listahall.index(hall) + 1))
                                        if not far_spelaren_ut(kastperson, hall):
                                            kastperson.ruta += hall
                                            if kastperson.har_bollen:
                                                bollruta += hall
                                            rita(True)
                                            pygame.display.update()
                                        else:
                                            splash_message(kastperson.spelare.namn + " studsade av plan!", tid=2.0)
                                            kastperson.ruta = 1000
                                            trilla(kastperson, True, None, True)
                                            turno = True
                                            if kastperson.har_bollen:
                                                kastperson.har_bollen = False
                                                inkast()
                                            break
                                        nandar = False
                                        for vh in alla_spelare1:
                                            if vh.ruta == kastperson.ruta and not vh == kastperson:
                                                nandar, vemdar = True, vh
                                                break
                                        for vh in alla_spelare2:
                                            if vh.ruta == kastperson.ruta and not vh == kastperson:
                                                nandar, vemdar = True, vh
                                                break
                                        if not nandar:
                                            tarningsslag.pop(-1)
                                    ag = int(kastperson.spelare.varden[2])
                                    mer = aglist[ag]
                                    modify = tackle_zones(kastperson)
                                    slag = tarning(
                                        kastperson.spelare.namn + " försöker landa, " + str(mer +
                                                                                            modify) + "+",
                                        "landning", lyckas=mer,
                                        vemgornat=kastperson)
                                    nu = kastperson.ruta
                                    hadeboll = kastperson.har_bollen
                                    if not failland and (slag - modify >= mer or slag == 6) and slag != 1:
                                        pass
                                    else:
                                        trilla(kastperson)
                                        if kastperson.har_bollen:
                                            kastperson.har_bollen = False
                                            try:
                                                if ball_bounce() == "denfor":
                                                    inkast()
                                            except BreakOut:
                                                return
                                            turno = True
                                    if nu == bollruta and hadeboll is False:
                                        try:
                                            if ball_bounce() == "denfor":
                                                inkast()
                                        except BreakOut:
                                            return
                        if turno:
                            nasta_drag("Turnover")

                        return

        pygame.display.update()


def leap(person):
    global bollruta
    rita(False)
    alltsurh = gameDisplay.copy().convert()
    nagot = False
    while not nagot:
        gameDisplay.blit(alltsurh, (0, 0))

        rutanh = vilken_ruta(pygame.mouse.get_pos())
        ja = False
        for numh in listahall:
            if rutanh == person.ruta + numh:
                if not far_nagot_ut(person.ruta, numh):
                    ja = True
            for num2h in listahall:
                if rutanh == person.ruta + numh + num2h:
                    if not far_nagot_ut(person.ruta, numh) and not far_nagot_ut(person.ruta + numh, num2h):
                        ja = True

        bra = False
        vem = vem_star_har(rutanh)
        if vem is None:
            bra = True
        if ja:
            if bra:
                gameDisplay.blit(globals()["Grön markörbild"], fa_pos(rutanh))
            else:
                gameDisplay.blit(globals()["Cancelbild"], fa_pos(rutanh))
        else:
            gameDisplay.blit(globals()["Cancelbild"], fa_pos(rutanh))

        for eventh in pygame.event.get():
            if eventh.type == pygame.MOUSEBUTTONDOWN:
                if eventh.button == 1:
                    if ja and bra:
                        person.ruta = rutanh
                        if person.har_bollen:
                            bollruta = rutanh
                        globals()["personglobal"] = person
                        exec("personglobal.leapanvant = True", globals())
                        ag = person.spelare.varden[2]
                        mer = aglist[ag]
                        person.steg_kvar -= 2
                        turno = False
                        vll = 0
                        if person.spelare.skills.__contains__("very long legs"):
                            vll = 1
                        slag = tarning(person.spelare.namn + " försöker leapa, " + str(mer - vll) + "+", "leap", person,
                                       None, mer)
                        if (slag < mer - vll or slag == 1) or (person.steg_kvar == -1 and tarning(
                                person.spelare.namn + " tar ett extrasteg för att leapa, 2+", "extrasteg", person,
                                "sure feet", extrasteglyckas) <= extrasteglyckas) or (
                                person.steg_kvar < -1 and (tarning(
                            person.spelare.namn + " tar ett extrasteg för att leapa, 2+", "extrasteg", person,
                            "sure feet", extrasteglyckas) <= extrasteglyckas or tarning(
                            person.spelare.namn + " tar ett extrasteg för att leapa, 2+", "extrasteg", person,
                            "sure feet", extrasteglyckas) <= extrasteglyckas)):
                            person.star = False
                            trilla(person)
                            if person.har_bollen:
                                person.har_bollen = False
                                try:
                                    if ball_bounce() == "denfor":
                                        inkast()
                                except BreakOut:
                                    return
                            turno = True
                        if rutanh == bollruta and not person.har_bollen:
                            pick_up(person)
                        if turno:
                            nasta_drag("Turnover")
                        nagot = True
                elif eventh.button == 3:
                    return
        gameDisplay.blit(mus, pygame.mouse.get_pos())
        pygame.display.update()


def action(person):
    personenslag = vem_star_har(person.ruta, True)[1]
    if personenslag == 1:
        da = 2
    else:
        da = 1
    kanpassa = person.ska_passa and person.har_bollen and not passat
    kanhandoffa = person.ska_handoffa and person.har_bollen and not handoffat
    kanresasig = not person.star
    kanthrowteammate = person.ska_passa and person.star and not passat and tackle_zones_ruta(
        person.ruta, da, "right stuff")[1] is True and person.spelare.skills.__contains__("throw team-mate")

    kanleapa = person.star and person.spelare.skills.__contains__("leap") and (
            person.steg_kvar > -1 or (person.steg_kvar > -2 and person.spelare.skills.__contains__("sprint")))
    if kanleapa:
        globals()["harleapat"] = False
        globals()["personglobal"] = person
        exec("if personglobal.leapanvant:\n    harleapat = True", globals())
        if globals()["harleapat"]:
            kanleapa = False

    avbrytknapp = knapp(gameDisplay, "Avbryt", (1180, 20), 45)
    yh = 80
    passknapp, handoffknapp, resasigknapp, throwteammateknapp, leapknapp = None, None, None, None, None
    if kanpassa:
        passknapp = knapp(gameDisplay, "Passa", (1180, yh), 45)
        yh += 60
    if kanhandoffa:
        handoffknapp = knapp(gameDisplay, "Hand-offa", (1180, yh), 45)
        yh += 60
    if kanresasig:
        resasigknapp = knapp(gameDisplay, "Resa sig", (1180, yh), 45)
        yh += 60
    if kanthrowteammate:
        throwteammateknapp = knapp(gameDisplay, "Throw team-mate", (1178, yh), 34)
        yh += 60
    if kanleapa:
        leapknapp = knapp(gameDisplay, "Leapa", (1178, yh), 45)
        yh += 60
    rita(False)
    if person.star:
        gameDisplay.blit(globals()["Cirkelvitbild"], fa_pos(person.ruta))
    else:
        gameDisplay.blit(globals()["Cirkelgulbild"], fa_pos(person.ruta))
    avbrytknapp.rita()
    if kanpassa:
        passknapp.rita()
    if kanhandoffa:
        handoffknapp.rita()
    if kanresasig:
        resasigknapp.rita()
    if kanthrowteammate:
        throwteammateknapp.rita()
    if kanleapa:
        leapknapp.rita()
    alltsurh = gameDisplay.copy().convert()
    while True:
        for eventh in pygame.event.get():
            if eventh.type == pygame.MOUSEBUTTONDOWN:
                if eventh.button == 1:
                    if avbrytknapp.ar_aktiv():
                        return
                    if kanpassa and passknapp.ar_aktiv():
                        if person.fardig is False:
                            try:
                                passa(person)
                            except BreakOut:
                                pass
                            return
                    if kanhandoffa and handoffknapp.ar_aktiv():
                        if person.fardig is False:
                            try:
                                handoffa(person)
                            except BreakOut:
                                pass
                            return
                    if kanresasig and resasigknapp.ar_aktiv():
                        if gor_nagot(person, tur):
                            if aktiv.steg_kvar > 2 or aktiv.spelare.skills.__contains__("jump up"):
                                aktiv.star = True
                                if not aktiv.spelare.skills.__contains__("jump up"):
                                    aktiv.steg_kvar -= 3
                            else:
                                if tarning(aktiv.spelare.namn + " försöker ställa sig upp, 4+", "resa sig", aktiv,
                                           None, 4) > 3:
                                    aktiv.star = True
                                    aktiv.steg_kvar -= 3
                                else:
                                    aktiv.fardig = True
                            return
                    if kanthrowteammate and throwteammateknapp.ar_aktiv():
                        throw_team_mate(person)
                        return
                    if kanleapa and leapknapp.ar_aktiv():
                        leap(person)
                        return
                if eventh.button == 3:
                    return
        gameDisplay.blit(alltsurh, (0, 0))
        if avbrytknapp.ar_aktiv() or (kanpassa and passknapp.ar_aktiv()) or (kanhandoffa and handoffknapp.ar_aktiv()) \
                or (kanresasig and resasigknapp.ar_aktiv()) or (kanthrowteammate and throwteammateknapp.ar_aktiv()) or (
                kanleapa and leapknapp.ar_aktiv()):
            gameDisplay.blit(pekmus, pygame.mouse.get_pos())
        else:
            gameDisplay.blit(mus, pygame.mouse.get_pos())
        pygame.display.update()


def declare_action(person):
    fardeclara = person.steg_kvar == person.spelare.varden[0] and not person.har_gjort
    if not fardeclara:
        return
    farblitza = not har_blitzat(tur) and not person.ska_passa and not person.ska_handoffa and not person.ska_foula
    farpassa = not har_passat(tur) and not person.ska_blitza and not person.ska_handoffa and not person.ska_foula
    farhandoffa = not har_handoffat(tur) and not person.ska_blitza and not person.ska_passa and not person.ska_foula
    farfoula = not har_foulat() and not person.ska_blitza and not person.ska_handoffa and not person.ska_passa

    yh = 20
    avbrytknapp = knapp(gameDisplay, "Avbryt", (1180, yh), 40)
    yh += 60
    blitzknapp = knapp(gameDisplay, "Blitz", (1180, yh), 40)
    if farblitza:
        yh += 60
    passknapp = knapp(gameDisplay, "Pass", (1180, yh), 40)
    if farpassa:
        yh += 60
    handoffknapp = knapp(gameDisplay, "Handoff", (1180, yh), 40)
    if farhandoffa:
        yh += 60
    foulknapp = knapp(gameDisplay, "Foul", (1180, yh), 40)

    rita(False)
    if person.star:
        gameDisplay.blit(globals()["Cirkelvitbild"], fa_pos(person.ruta))
    else:
        gameDisplay.blit(globals()["Cirkelgulbild"], fa_pos(person.ruta))
    avbrytknapp.rita()
    if farblitza:
        blitzknapp.rita()
    if farpassa:
        passknapp.rita()
    if farhandoffa:
        handoffknapp.rita()
    if farfoula:
        foulknapp.rita()
    alltsurh = gameDisplay.copy().convert()

    while True:
        for eventh in pygame.event.get():
            if eventh.type == pygame.MOUSEBUTTONDOWN:
                if eventh.button == 1:
                    if avbrytknapp.ar_aktiv():
                        return
                    if farblitza and blitzknapp.ar_aktiv():
                        person.ska_blitza = True
                        return
                    if farpassa and passknapp.ar_aktiv():
                        person.ska_passa = True
                        return
                    if farhandoffa and handoffknapp.ar_aktiv():
                        person.ska_handoffa = True
                        return
                    if farfoula and foulknapp.ar_aktiv():
                        person.ska_foula = True
                        return
                elif eventh.button == 3:
                    return
        gameDisplay.blit(alltsurh, (0, 0))
        if avbrytknapp.ar_aktiv() or (blitzknapp.ar_aktiv() and farblitza) or (passknapp.ar_aktiv() and farpassa) \
                or (handoffknapp.ar_aktiv() and farhandoffa) or (foulknapp.ar_aktiv() and farfoula):
            gameDisplay.blit(pekmus, pygame.mouse.get_pos())
        else:
            gameDisplay.blit(mus, pygame.mouse.get_pos())
        pygame.display.update()


def hogerklick(person):
    declareknapp = knapp(gameDisplay, "Declara", (1180, 20))
    gorknapp = knapp(gameDisplay, "Gör något", (1180, 80))
    rita(False)
    if person.star:
        gameDisplay.blit(globals()["Cirkelvitbild"], fa_pos(person.ruta))
    else:
        gameDisplay.blit(globals()["Cirkelgulbild"], fa_pos(person.ruta))
    declareknapp.rita()
    gorknapp.rita()
    alltsurh = gameDisplay.copy().convert()
    while True:
        gameDisplay.blit(alltsurh, (0, 0))
        if declareknapp.ar_aktiv() or gorknapp.ar_aktiv():
            gameDisplay.blit(pekmus, pygame.mouse.get_pos())
        else:
            gameDisplay.blit(mus, pygame.mouse.get_pos())
        pygame.display.update()
        for eventh in pygame.event.get():
            if eventh.type == pygame.MOUSEBUTTONDOWN:
                if eventh.button == 1:
                    if declareknapp.ar_aktiv():
                        declare_action(person)
                        return
                    if gorknapp.ar_aktiv():
                        action(person)
                        return
                if eventh.button == 3:
                    return


def rita(visamus=True, tarningar=True, visaboll=True, exkluderagubbe=None):
    gameDisplay.fill(rgb)
    gameDisplay.blit(spelplan, (0, 0))
    # gameDisplay.fill((255, 50, 50))

    if visaboll:
        gameDisplay.blit(boll, fa_pos(bollruta))

    for numh in range(0, 390):
        vh = vem_star_har(numh)
        if vh is not None and vh != exkluderagubbe:
            bh = globals()[vh.spelare.typ + "bild"]
            bhs = bh.get_size()[1]

            if vh.star is False:
                if vh.nerehall == 1:
                    bh = pygame.transform.rotate(bh, -90)
                elif vh.nerehall == 2:
                    bh = pygame.transform.rotate(bh, 90)
                else:
                    vh.nerehall = random.randint(1, 2)
                    if vh.nerehall == 1:
                        bh = pygame.transform.rotate(bh, -90)
                    elif vh.nerehall == 2:
                        bh = pygame.transform.rotate(bh, 90)
            else:
                vh.nerehall = 0

            if bhs == 45 or vh.star is False:
                gameDisplay.blit(bh, fa_pos(vh.ruta))
            else:
                gameDisplay.blit(bh, (fa_pos(vh.ruta)[0], fa_pos(vh.ruta)[1] - (bhs - 45)))
            if vh.tacklezone is False:
                skriv(gameDisplay, "ITZ", fa_pos(vh.ruta))
            if vh.fastvaxt:
                skriv(gameDisplay, "VXT", fa_pos(vh.ruta))
            if vh.skadad.__contains__("stunned"):
                if vh.spelare.typ == "Ghoul":
                    skriv(gameDisplay, "S", fa_pos(vh.ruta), farg=(255, 255, 255))
                else:
                    skriv(gameDisplay, "S", fa_pos(vh.ruta))
            elif vh.star is False:
                if vh.spelare.typ == "Ghoul":
                    skriv(gameDisplay, "N", fa_pos(vh.ruta), farg=(255, 255, 255))
                else:
                    skriv(gameDisplay, "N", fa_pos(vh.ruta))
            if vh.ska_blitza is True:
                gameDisplay.blit(globals()["Blitzbild"], fa_pos(vh.ruta))
            if vh.ska_passa is True:
                gameDisplay.blit(globals()["Passbild"], fa_pos(vh.ruta))
            if vh.ska_handoffa is True:
                gameDisplay.blit(globals()["Handoffbild"], fa_pos(vh.ruta))
            if vh.ska_foula is True:
                gameDisplay.blit(globals()["Foulbild"], fa_pos(vh.ruta))

    if tarningar:
        numh = -16
        for yu in range(260, 660, 25):
            try:
                if tarningsslag[numh].split(": ")[0] == "Block":
                    skriv(gameDisplay, "Block:", (1180, yu), 20)
                    valu = int(tarningsslag[numh].split(": ")[2])
                    xu = 1250
                    num2 = 0
                    for vh in tarningsslag[numh].split(": ")[1].split(", "):
                        if num2 == valu:
                            pygame.draw.rect(gameDisplay, (0, 255, 50), (xu - 2, yu - 7, 24, 24))
                            gameDisplay.blit(globals()[vh + "litenbild"], (xu, yu - 5))
                        else:
                            gameDisplay.blit(globals()[vh + "litenbild"], (xu, yu - 5))
                        xu += 30
                        num2 += 1
                elif tarningsslag[numh].__contains__("'"):
                    su = tarningsslag[numh].split("'")
                    skriv(gameDisplay, su[0] + su[2].strip(), (1180, yu), 20)
                else:
                    skriv(gameDisplay, tarningsslag[numh], (1180, yu), 20)
            except IndexError:
                pass
            numh += 1

    if visamus:
        musposh = pygame.mouse.get_pos()
        gameDisplay.blit(mus, musposh)


def animera(franruta, tillruta, uppimitten=False, gubbe=False):
    # p1 och p2 är positionen i mitten av rutorna, i pixlar
    p1 = fa_pos(franruta)
    p1 = (p1[0], p1[1])
    p2 = fa_pos(tillruta)
    p2 = (p2[0], p2[1])

    # kollar avståndet mellan rutornas mitt, både höjd-avståndet och längd-avståndet (i pixlar)
    distance1 = abs(p1[0] - p2[0])
    distance2 = abs(p1[1] - p2[1])

    # dessa håller reda på hur linjen dras. Om båda är ett, så ökar den ena med ett när den andra gör det
    forhallande1 = 1
    forhallande2 = 1

    # här kollar den hur många pixlar den ena ska röra sig när den andra rör sig en pixel. Om ingen av avstånden är
    # större så blir det såklart 1:1 som definierat ovanför
    if distance1 == 0:
        forhallande1 = 0
        forhallande2 = 2
    if distance2 == 0:
        forhallande2 = 0
        forhallande1 = 2

    if not (distance1 == 0 or distance2 == 0):
        if distance1 > distance2:
            forhallande1 = distance1 / distance2
        if distance2 > distance1:
            forhallande2 = distance2 / distance1

    # avstånden och förhållandena är alltid positiva, så här fixar den så att de blir negativa om de ska vara det
    if p1[0] > p2[0]:
        forhallande1 *= -1
    if p1[1] > p2[1]:
        forhallande2 *= -1

    nu1, nu2 = p1[0], p1[1]

    vagh = []

    while True:
        if forhallande1 == 0 and forhallande2 == 0:
            break

        if uppimitten:
            nu1 += forhallande1 * 0.7
            nu2 += forhallande2 * 0.7
        else:
            nu1 += forhallande1 * 1.5
            nu2 += forhallande2 * 1.5

        vagh.append((nu1, nu2))

        if forhallande1 > 0:
            if int(nu1) >= p2[0]:
                break
        elif forhallande1 < 0:
            if int(nu1) <= p2[0]:
                break
        if forhallande2 > 0:
            if int(nu2) >= p2[1]:
                break
        elif forhallande2 < 0:
            if int(nu2) <= p2[1]:
                break

    if gubbe:
        rita(False, exkluderagubbe=gubbe)
        bh = globals()[gubbe.spelare.typ + "bild"]
    else:
        rita(False, visaboll=False)
        bh = boll
    bakgrundenh = gameDisplay.copy()
    clockh = pygame.time.Clock()

    storlek = 1
    exponentiell = 0.2
    for numh in range(0, len(vagh)):
        clockh.tick(120)

        nu1, nu2 = vagh[numh]

        sh = bh.get_size()

        gameDisplay.blit(bakgrundenh, (0, 0))

        # den är anpassad så att bollen inte förskjuts neråt om den förstoras
        gameDisplay.blit(pygame.transform.scale(bh, (sh[0] * storlek, sh[1] * storlek)),
                         (nu1 - ((sh[0] * storlek - sh[0]) / 2), nu2 -((sh[1] * storlek - sh[1]) / 2)))

        gameDisplay.blit(mus, pygame.mouse.get_pos())

        pygame.display.update()

        if uppimitten:
            exponentiell -= 0.2 / (len(vagh) / 2)
            storlek += exponentiell


def rita_stats(person, stegkvar=False, vilkety=230):
    if stegkvar:
        pygame.draw.rect(gameDisplay, (255, 255, 255), (1175, vilkety - 5, 450, 155))
    else:
        pygame.draw.rect(gameDisplay, (255, 255, 255), (1175, vilkety - 5, 450, 135))
    skriv(gameDisplay, person.spelare.namn, (1180, vilkety), 30)
    skriv(gameDisplay, person.spelare.typ, (1180, vilkety + 25), 20)
    skriv(gameDisplay, "MA ST AG AV", (1180, vilkety + 45), 20)
    skriv(gameDisplay, " " + str(person.spelare.varden).replace("[", "").replace("]", "").replace(
        ",", "   "), (1180, vilkety + 65), 20)
    if stegkvar:
        skriv(gameDisplay, str(person.steg_kvar) + " steg kvar", (1180, vilkety + 105), 20)
        skriv(gameDisplay, str(person.spelare.spp) + " SPP", (1180, vilkety + 125), 20)
    else:
        skriv(gameDisplay, str(person.spelare.spp) + " SPP", (1180, vilkety + 105), 20)
    if person.spelare.skills:
        skriv(gameDisplay, str(person.spelare.skills).replace("[", "").replace("]", "").replace(
            "'", ""),
              (1180, vilkety + 85), 20)
    else:
        skriv(gameDisplay, "inga skills", (1180, vilkety + 85), 20)


def visa_info_om(person):
    nagot = False
    gameDisplay.fill((255, 100, 255))
    skriv(gameDisplay, person.namn, (10, 10), 70)
    skriv(gameDisplay, "Typ: " + person.typ, (20, 100))
    skriv(gameDisplay, "MA  ST  AG  AV", (20, 150))
    skriv(gameDisplay, " " + str(person.varden[0]) + "      " + str(person.varden[1]) + "      " +
          str(person.varden[2]) + "      " + str(person.varden[3]), (20, 180), 29)
    skriv(gameDisplay, "Värde: " + str(person.pengavarde), (20, 400))
    skriv(gameDisplay, "Skills: " + str(person.skills).replace("[", "").
          replace("]", "").replace("'", ""), (20, 290))
    skriv(gameDisplay, "Star Player Points: " + str(person.spp), (20, 510))
    pygame.draw.rect(gameDisplay, (255, 255, 255), (690, 70, 200, 195))
    skriv(gameDisplay, "Passar: " + str(person.passar), (700, 80))
    skriv(gameDisplay, "Touchdowns: " + str(person.touchdowns), (700, 120))
    skriv(gameDisplay, "Casualties: " + str(person.casualties), (700, 160))
    skriv(gameDisplay, "Intercpetions: " + str(person.interceptions), (700, 200))
    skriv(gameDisplay, "MVPs: " + str(person.mvps), (700, 240))
    alltsurh = gameDisplay.copy().convert()
    while not nagot:
        for eventhh in pygame.event.get():
            if eventhh.type == pygame.MOUSEBUTTONDOWN:
                nagot = True
        gameDisplay.blit(alltsurh, (0, 0))
        gameDisplay.blit(mus, pygame.mouse.get_pos())

        pygame.display.update()


def splash_message(string, farg=(255, 0, 0), tid=1.0):
    delat = ""
    nu = ""
    for s in string.split(" "):
        if get_textwidth(nu + s, 90) > 1300:
            delat += "++?;;"
            nu = ""
        if nu != "":
            nu += s + " "
        else:
            nu += s
        if nu != "":
            delat += s + " "
        else:
            delat += s

    gameDisplay.fill(farg)

    yh = 50
    for rad in delat.split("++?;;"):
        skriv(gameDisplay, rad, (50, yh), 90, (50, 0, 0))
        yh += 90
    pygame.display.update()
    time.sleep(tid)


def gor_nagot(person, turh, blockah=False):
    if person.fardig is False and person.skadad == "":
        mer, t, t2 = 0, "", ""
        if person.spelare.skills.__contains__("really stupid"):
            mer = 4
            la = vem_star_har(person.ruta, True)[1]
            if la == 1:
                la = 2
            else:
                la = 1
            if tackle_zones_ruta(person.ruta, la, rakna_inte_med="really stupid"):
                mer = 2
            t, t2 = "bli korkad", "really stupid"
        elif person.spelare.skills.__contains__("bone-head"):
            mer = 2
            t, t2 = "bli korkad", "bone-head"
        elif person.spelare.skills.__contains__("take root") and person.fastvaxt is False:
            mer = 2
            t, t2 = "växa fast", "take root"
        elif person.spelare.skills.__contains__("wild animal"):
            if person.ska_blitza or blockah:
                mer = 2
            else:
                mer = 4
            t, t2 = "bli vild och galen", "wild animal"

        if not mer or person.har_gjort or tarning(person.spelare.namn + " försöker att inte " + t + ", "
                                                  + str(mer) + "+", t2, person, None, mer) >= mer:
            if turh == 1:
                lagh = alla_spelare1
            else:
                lagh = alla_spelare2
            for vh in lagh:
                if not vh.spelare.namn == person.spelare.namn:
                    if vh.har_gjort:
                        vh.fardig = True
            person.tacklezone = True
            person.har_gjort = True
            return True
        else:
            if person.spelare.skills.__contains__("really stupid"):
                person.tacklezone = False
                person.fardig = True
            elif person.spelare.skills.__contains__("bone-head"):
                person.tacklezone = False
                person.fardig = True
            elif person.spelare.skills.__contains__("wild animal"):
                person.fardig = True
            elif person.spelare.skills.__contains__("take root"):
                person.fastvaxt = True
                person.har_gjort = True
                return True
            return False
    else:
        return False


def reroll(person, medvad="vanlig", ritkod="", baraja=False, specialsurface=None, barajarutor=None):
    global anvantrr
    if medvad == "vanlig":
        anvand = knapp(gameDisplay, "Använd reroll", (50, 250), textfarg=(100, 255, 50))
        anvandej = knapp(gameDisplay, "Använd inte reroll", (50, 300), textfarg=(100, 255, 50))
    else:
        anvand = knapp(gameDisplay, "Använd " + medvad, (50, 250), textfarg=(100, 255, 50))
        anvandej = knapp(gameDisplay, "Använd inte " + medvad, (50, 300), textfarg=(100, 255, 50))
    rita(False)
    alltsurh = gameDisplay.copy().convert()
    while True:
        for eventh in pygame.event.get():
            if eventh.type == pygame.MOUSEBUTTONDOWN:
                if eventh.button == 1:
                    if anvand.ar_aktiv():
                        if not person.spelare.skills.__contains__("loner") or medvad != "vanlig" or tarning(
                                person.spelare.namn + " försöker använda en re-roll, 4+", "loner", mojligrr=False) > 3:
                            if medvad == "vanlig":
                                anvantrr = True
                                globals()["rerolls" + str(tur)] -= 1
                            else:
                                exec("person." + medvad.replace(" ", "_").replace("-", "") + "anvant = True")
                            return True
                        else:
                            if person.spelare.skills.__contains__("loner"):
                                if medvad == "vanlig":
                                    anvantrr = True
                                    globals()["rerolls" + str(tur)] -= 1
                            return False
                    elif not baraja:
                        if anvandej.ar_aktiv():
                            return False
                    if baraja:
                        utja = True
                        if barajarutor:
                            musx, musy = pygame.mouse.get_pos()
                            utja = False
                            for vh in barajarutor:
                                if vh[0] + vh[2] >= musx >= vh[0]:
                                    if vh[1] + vh[3] >= musy >= vh[1]:
                                        utja = True
                                        break
                        if utja:
                            return False
        gameDisplay.blit(alltsurh, (0, 0))
        exec(ritkod)
        if specialsurface is not None:
            gameDisplay.blit(specialsurface, (0, 0))
        anvand.rita()
        if not baraja:
            anvandej.rita()
        skriv(gameDisplay, "Rerolls: " + str(globals()["rerolls" + str(tur)]), (50, 350), 50)
        if anvand.ar_aktiv() or (anvandej.ar_aktiv() and not baraja):
            gameDisplay.blit(pekmus, pygame.mouse.get_pos())
        else:
            gameDisplay.blit(mus, pygame.mouse.get_pos())
        pygame.display.update()


def tarning(message="", tema=None, vemgornat=None, rrskill=None, lyckas=6, mojligrr=True, vanta=True):
    global kanskilla, kanproa  # det här är väldigt komplicerat, kanskilla behöver vara global för att kunna ändras på
    # inne i exec(), och det behöver den för att kunna göra custom utrakningar om alla skills
    if lyckas > 6:
        lyckas = 6
    if lyckas < 2:
        lyckas = 2
    slag = random.randint(1, 6)
    if tema is None:
        tarningsslag.append("T6: " + str(slag))
    else:
        tarningsslag.append("T6 (" + tema + "): " + str(slag))
    rita()
    gameDisplay.blit(globals()["Tärning" + str(slag) + "bild"], (20, 20))
    skriv(gameDisplay, message, (20, 65), 50)
    if tarningsvant or vanta:
        pygame.display.update()
    if not vanta:
        time.sleep(tarningsvant)
    else:
        time.sleep(2)

    if mojligrr and tur == vem_star_har(vemgornat.ruta, True)[1]:
        kanskilla = False
        kanproa = False

        globals()["vemgornatglobal"] = vemgornat  # den kan inte komma åt vemgornat inne i exec(), därför skapas här en
        # global kopia
        if rrskill is not None:
            if vemgornat.spelare.skills.__contains__(rrskill):
                exec("if not globals()['vemgornatglobal']." + rrskill.replace(" ", "_").replace("-", "") +
                     "anvant:\n    kanskilla = True", globals())
        if vemgornat.spelare.skills.__contains__("pro") and not kanskilla:
            exec("if not globals()['vemgornatglobal'].proanvant:\n    kanproa = True", globals())

        if slag < lyckas or rerollallt:
            rita(False)
            gameDisplay.blit(globals()["Tärning" + str(slag) + "bild"], (20, 20))
            skriv(gameDisplay, message, (20, 65), 50)
            proig = False
            if kanproa:
                if reroll(vemgornat, "pro", specialsurface=gameDisplay.copy().convert()):
                    proig = True
                else:
                    rita(False)
                    gameDisplay.blit(globals()["Tärning" + str(slag) + "bild"], (20, 20))
                    skriv(gameDisplay, message, (20, 65), 50)
                    pygame.display.update()
            if (proig and tarning(vemgornat.spelare.namn +
                                  " fösöker använda pro, 4+", "pro", vemgornat,
                                  lyckas=4) > 3) or (
                    proig is False and kanskilla and reroll(
                vemgornat, rrskill, specialsurface=gameDisplay.copy().convert())) or (
                    proig is False and not anvantrr and globals()["rerolls" + str(tur)] > 0 and
                    reroll(vemgornat, specialsurface=gameDisplay.copy().convert())):
                slag = random.randint(1, 6)
                tarningsslag.append("T6 (reroll): " + str(slag))
                rita()
                gameDisplay.blit(globals()["Tärning" + str(slag) + "bild"], (20, 20))
                skriv(gameDisplay, message, (20, 65), 50)
                pygame.display.update()
                time.sleep(2)
    return slag


def nasta_drag(message):
    global bollruta, tur, aktiv, drag, info, passat, handoffat, anvantrr, rerolls1, rerolls2, foulat, passfailnu
    passfailnu = False
    foulat = False
    anvantrr = False
    passat, handoffat = False, False
    rita(False)
    skriv(gameDisplay, message, (50, 50), 90, (50, 0, 0))
    pygame.display.update()
    time.sleep(1)
    aktiv = None
    info = None
    if tur == 1:
        for vh in alla_spelare1:
            vh.fardig = False
            vh.har_gjort = False
            vh.steg_kvar = vh.spelare.varden[0]
            vh.ska_blitza = False
            vh.har_blockat = False
            vh.ska_passa = False
            vh.ska_handoffa = False
            vh.ska_foula = False
            for s in vh.spelare.skills:
                if s in ["dodge", "pass", "sure feet", "sure hands", "catch", "pro", "break tackle", "leap"]:
                    exec("vh." + s.replace(" ", "_").replace("-", "") + "anvant = False")
        # fixa stunned
        for vh in alla_spelare2:
            if vh.skadad == "stunned":
                vh.skadad = "stunnednu"
                vh.fardig = True
            elif vh.skadad == "stunnednu":
                vh.skadad = ""
        tur = 2
    else:
        for vh in alla_spelare2:
            vh.fardig = False
            vh.har_gjort = False
            vh.steg_kvar = vh.spelare.varden[0]
            vh.ska_blitza = False
            vh.har_blockat = False
            vh.ska_passa = False
            vh.ska_handoffa = False
            vh.ska_foula = False
            for s in vh.spelare.skills:
                if s in ["dodge", "pass", "sure feet", "sure hands", "catch", "pro", "break tackle", "leap"]:
                    exec("vh." + s.replace(" ", "_").replace("-", "") + "anvant = False")
        # fixa stunned
        for vh in alla_spelare1:
            if vh.skadad == "stunned":
                vh.skadad = "stunnednu"
                vh.fardig = True
            elif vh.skadad == "stunnednu":
                vh.skadad = ""
        tur = 1
    drag += 1
    if drag == 17:
        splash_message("Halvlek", (0, 255, 0))
        fil1h, fil2h = open(".skapade lag/" + lag1namn + "/RR", "r"), open(".skapade lag/" + lag2namn + "/RR", "r")
        rerolls1, rerolls2 = int(fil1h.read().strip()), int(fil2h.read().strip())
        fil1h.close()
        fil2h.close()
        drag = 17
        if tur == 1:
            set_up(1)
        else:
            set_up(2)
    elif drag == 33:
        slut()
    if autospara:
        spara_match(False)
        tarningsslag.append("Matchen autosparades")


def slut():
    spara_match(False)
    filh = open(".skapade lag/" + lag1namn + "/Var", "w", encoding="utf-8")
    filh.write("inget")
    filh.close()
    filh = open(".skapade lag/" + lag2namn + "/Var", "w", encoding="utf-8")
    filh.write("inget")
    filh.close()

    filh = open(".skapade lag/" + lag1namn + "/Pengar", "r", encoding="utf-8")
    pengar1 = int(filh.read().strip())
    filh.close()
    filh = open(".skapade lag/" + lag2namn + "/Pengar", "r", encoding="utf-8")
    pengar2 = int(filh.read().strip())
    filh.close()
    filh = open(".skapade lag/" + lag1namn + "/Pengar", "w", encoding="utf-8")
    nyap1 = random.randint(1, 6) * 10000
    filh.write(str(pengar1 + nyap1))
    filh.close()
    filh = open(".skapade lag/" + lag2namn + "/Pengar", "w", encoding="utf-8")
    nyap2 = random.randint(1, 6) * 10000
    filh.write(str(pengar2 + nyap2))
    filh.close()

    mvp1 = random.choice(alla_spelare1)
    mvp2 = random.choice(alla_spelare2)
    mvp1.spelare.spp += 5
    mvp1.spelare.mvps += 1
    mvp2.spelare.spp += 5
    mvp2.spelare.mvps += 1

    for vh in alla_spelare1:
        filh = open(".skapade lag/" + lag1namn + "/.spelare/" + vh.spelare.namn, "wb")
        if vh.skadad != "död":
            if vh.skadad.__contains__("_b"):
                vh.spelare.skadad = ""
            pickle.dump(vh.spelare, filh)
            filh.close()
        else:
            filh.close()
            os.remove(".skapade lag/" + lag1namn + "/.spelare/" + vh.spelare.namn)
    for vh in alla_spelare2:
        filh = open(".skapade lag/" + lag2namn + "/.spelare/" + vh.spelare.namn, "wb")
        if vh.skadad != "död":
            if vh.skadad.__contains__("_b"):
                vh.spelare.skadad = ""
            pickle.dump(vh.spelare, filh)
            filh.close()
        else:
            filh.close()
            os.remove(".skapade lag/" + lag2namn + "/.spelare/" + vh.spelare.namn)
    splash_message("Matchen är slut!", tid=1.5)
    if not td1 == td2:
        if td1 > td2:
            sh = "1"
        else:
            sh = "2"
        pygame_input(gameDisplay, globals()["lag" + str(sh) + "namn"] + " vann med " + str(td1) + " – " + str(td2) +
                     ".")
    else:
        pygame_input(gameDisplay, "Det blev lika!")
    pygame_input(gameDisplay, lag1namn + " fick " + str(nyap1) + ".")
    pygame_input(gameDisplay, lag2namn + " fick " + str(nyap2) + ".")
    pygame_input(gameDisplay, mvp1.spelare.namn + " fick 5 SPP för MVP.")
    pygame_input(gameDisplay, mvp2.spelare.namn + " fick 5 SPP för MVP.")

    shutil.rmtree(".matcher/" + lag1namn + " VS " + lag2namn + "/")

    quit()


def ball_bounce(sidbry=0):
    tebaks = ""
    global bollruta
    rita()
    pygame.display.update()
    hallsiffra = random.randint(1, 8)
    tarningsslag.append("T8 (bounce): " + str(hallsiffra))
    hall = listahall[hallsiffra - 1]
    if sidbry:
        if far_bollen_ut(bollruta, hall, True, sidbry):
            tebaks = "denfor"
    else:
        if far_bollen_ut(bollruta, hall):
            tebaks = "denfor"
    if tebaks != "denfor":
        time.sleep(1)
        rita()
        pygame.display.update()
        if animeringar:
            animera(bollruta, bollruta + hall)
        bollruta += hall
        if vem_star_har(bollruta) is not None:
            if vem_star_har(bollruta).star is True:
                tebaks = fanga(sidbry=sidbry)
            else:
                try:
                    tebaks = ball_bounce()
                except BreakOut:
                    return
    return tebaks


def ball_scatter(sidbry=0):
    tebaks = ""
    global bollruta
    rita()
    pygame.display.update()
    hallsiffra = random.randint(1, 8)
    tarningsslag.append("T8 (scatter): " + str(hallsiffra))
    hall = listahall[hallsiffra - 1]
    if sidbry:
        if far_bollen_ut(bollruta, hall, True, sidbry):
            tebaks = "denfor"
    else:
        if far_bollen_ut(bollruta, hall):
            tebaks = "denfor"
    if tebaks != "denfor":
        rita()
        pygame.display.update()
        bollruta += hall
    return tebaks


def inkast():
    splash_message("Inkast!")
    global bollruta
    t3 = random.randint(1, 3)
    tarningsslag.append("T3 (throw-in): " + str(t3))
    # följande kan var confusing, förklaring:
    # om bollen far ut på kortsidan, så kan bollruta inte plussas ut från skärmen, för då hamnar den på andra sidan
    # plan. Om det gjorts, så hade den inte "fått" åka in igen
    # "fore" är till för att om den far ut på kortsidan, så kan ju inte inkastet ske från den oplussade bollrutan, för
    # då hade det ju blivit fel. Därför måste den börja customizat och sedan fara ett steg mindre (m.h.a. "borja").
    fore = [0, 0, 0]
    borja = 0
    if fa_pos(bollruta)[0] == 1125 or fa_pos(bollruta)[0] == 0:
        borja = 1
    if fa_pos(bollruta)[0] == 1125:
        listahallh = [25, -1, -27]
        fore = [26, 0, -26]
    elif fa_pos(bollruta)[0] == 0:
        listahallh = [27, 1, -25]
        fore = [26, 0, -26]
    else:
        if fa_pos(bollruta)[1] > 300:
            listahallh = [-27, -26, -25]
            bollruta += 26
        else:
            listahallh = [25, 26, 27]
            bollruta -= 26
    hall = listahallh[t3 - 1]
    if fore[t3 - 1]:
        if not far_bollen_ut(bollruta, fore[t3 - 1]):
            bollruta += fore[t3 - 1]
    langd = random.randint(1, 6)
    tarningsslag.append("T6: (throw-in): " + str(langd))

    studs = True
    for numh in range(borja, langd):
        if far_bollen_ut(bollruta, hall):
            studs = False
            inkast()
            break
        else:
            bollruta += hall
    if studs:
        if vem_star_har(bollruta) is not None:
            if vem_star_har(bollruta).star is True:
                n = fanga(False)
                if n == "denfor":
                    inkast()
            else:
                try:
                    if ball_bounce() == "denfor":
                        inkast()
                except BreakOut:
                    return
        else:
            try:
                if ball_bounce() == "denfor":
                    inkast()
            except BreakOut:
                return


def tackle_zones(person, rakna_inte_med=None):
    zoner = 0
    for numh in listahall:
        if not far_spelaren_ut(person, numh):
            p, lag = vem_star_har(person.ruta + numh, True)
            if p is not None and lag != vem_star_har(person.ruta, True)[1]:
                if p.star and p.tacklezone:
                    if rakna_inte_med is None or not p.spelare.skills.__contains__(rakna_inte_med):
                        zoner += 1
    return zoner


def tackle_zones_ruta(ruta, personenslag, hittaskill=None, rakna_inte_med=None):
    hittatskill = False
    mangd = 0
    zoner = 0
    for numh in listahall:
        if not far_nagot_ut(ruta, numh):
            p, lag = vem_star_har(ruta + numh, True)
            if p is not None and lag != personenslag:
                if p.star and p.tacklezone:
                    if rakna_inte_med is None or not p.spelare.skills.__contains__(rakna_inte_med):
                        zoner += 1
                    if hittatskill is not None:
                        if p.spelare.skills.__contains__(hittaskill):
                            paplaninfo.append((hittaskill, fa_pos(p.ruta)))
                            hittatskill = True
                            mangd += 1
    if hittaskill:
        return zoner, hittatskill, mangd
    else:
        return zoner


def disturbing_presence(ruta):
    antal = 0
    kollat = []
    for n1 in listahall:
        for n2 in listahall:
            for n3 in listahall:
                if not far_nagot_ut(ruta, n1) and not far_nagot_ut(ruta + n1, n2) and not far_nagot_ut(ruta + n1 +
                                                                                                       n2, n3):
                    if not kollat.__contains__(ruta + n1 + n2 + n3):
                        kollat.append(ruta + n1 + n2 + n3)
                        vemdar = vem_star_har(ruta + n1 + n2 + n3)
                        if vemdar is not None:
                            if vilket_lag(vemdar) != vem_star_har(ruta, True)[1]:
                                if vem_star_har(ruta + n1 + n2 + n3).spelare.skills.__contains__("disturbing presence"):
                                    paplaninfo.append(("disturbing presence", fa_pos(vem_star_har(ruta + n1 + n2 + n3)
                                                                                     .ruta)))
                                    antal += 1
    return antal


def fanga(accurate=False, sidbry=0, passperson=None):
    global drag
    person, lag = vem_star_har(bollruta, True)
    if person.star and person.tacklezone:
        ag = person.spelare.varden[2]
        mer = aglist[ag]
        h = 0
        if accurate:
            h += 1
        if vader == "pouring rain":
            h -= 1
        numh = tarning(person.spelare.namn + " försöker fånga bollen med " + str(
            mer + tackle_zones(person) + disturbing_presence(person.ruta) - h) + "+",
                       "fångning", person, "catch", mer + tackle_zones(person) + disturbing_presence(person.ruta) - h)
        numhm = numh
        if accurate:
            numhm = numh + 1
        if not person.spelare.skills.__contains__("nerves of steel"):
            numhm -= tackle_zones(person)
        if vader == "pouring rain":
            numhm -= 1
        numhm -= disturbing_presence(person.ruta)
        if (numhm >= mer and numh != 1 and numhm > 1) or numh == 6:
            person.har_bollen = True
            if passperson is not None and vilket_lag(passperson) == vilket_lag(person):
                passperson.spelare.spp += 1
                passperson.spelare.passar += 1
                paplaninfo.append(("+1 SPP", fa_pos(passperson.ruta)))
            for vh in alla_spelare1:
                if i_touch_down(vh):
                    if tur != 1:
                        if passfailnu:
                            drag -= 1
                            nasta_drag("Fixar...")
                            drag -= 1
                        else:
                            nasta_drag("Fixar...")
                    touch_down(1, vh)
                    raise BreakOut
            for vh in alla_spelare2:
                if i_touch_down(vh):
                    if tur != 2:
                        if passfailnu:
                            drag -= 1
                            nasta_drag("Fixar...")
                            drag -= 1
                        else:
                            nasta_drag("Fixar...")
                    touch_down(2, vh)
                    raise BreakOut
        else:
            return ball_bounce(sidbry)
    else:
        return ball_bounce(sidbry)


def pick_up(person):
    global passfailnu
    tebaks = "YEAH"
    ag = person.spelare.varden[2]
    mer = aglist[ag]
    mer -= 1
    if vader == "pouring rain":
        mer += 1
    numh = tarning(person.spelare.namn + " försöker ta upp bollen med " + str(mer + tackle_zones(person)) + "+",
                   "ta upp bollen", person, "sure hands", mer + tackle_zones(person))
    numhm = numh
    numhm -= tackle_zones(person)
    if (numhm >= mer and numh != 1 and numhm != 1) or numh == 6:
        person.har_bollen = True
    else:
        try:
            tebaks = ball_bounce()
        except BreakOut:
            return
        passfailnu = True
    return tebaks


def i_touch_down(person):
    if person.har_bollen:
        xh, yh = fa_pos(person.ruta)
        lagh = vem_star_har(person.ruta, True)[1]
        if lagh == 1:
            if xh == 0:
                return True
        else:
            if xh == 1125:
                return True
    return False


def i_touch_down_ruta(ruta, lagh):
    xh, yh = fa_pos(ruta)
    if lagh == 1:
        if xh == 0:
            return True
    else:
        if xh == 1125:
            return True


def touch_down(lag, person):
    person.spelare.spp += 3
    person.spelare.touchdowns += 1
    splash_message(person.spelare.namn + " gjorde touchdown!!!", (0, 255, 0), 2.0)
    globals()["td" + str(lag)] += 1
    nasta_drag("Ny drive")
    if drag != 17:
        if tur == 1:
            set_up(2)
        else:
            set_up(1)


def ga(person, plush, vanta=True):
    global bollruta
    pd, ld = vem_star_har(person.ruta + plush, True)
    ph, lh = vem_star_har(person.ruta, True)
    ag = person.spelare.varden[2]
    meran = aglist[ag] - 2
    if meran < 2:
        meran = 2
    if meran > 6:
        meran = 6
    anda = False
    if person.star is False and (person.spelare.skills.__contains__(
            "jump up") and pd is not None and ld != lh and pd.star):
        if tarning(
                person.spelare.namn + " försöker resa sig upp och blocka, " + str(aglist[ag] - 2) + "+", "jump-up",
                person, None, aglist[ag] - 2) >= meran:
            anda = True
    if not person.skadad.__contains__("stunned") and (person.star or anda):
        person.star = True
        xnu, ynu = fa_pos(person.ruta)
        pospluslista = [25, (-45, 45), 26, (0, 45), 27, (45, 45), -1, (-45, 0), 1, (45, 0), -27,
                        (-45, -45),
                        -26, (0, -45), -25, (45, -45)]
        xp, yp = pospluslista[pospluslista.index(plush) + 1]  # plusx, plusy
        if -1 < xnu + xp < 1169 and -1 < ynu + yp < 674:  # checkar så att man inte går av plan
            denstar = True
            bf, blag = vem_star_har(person.ruta + plush, True)
            if bf is None:
                b = False
            else:
                b = True
                if not bf.star:
                    denstar = False
            if (denstar or (person.ska_foula and foulat is False)) and blag != tur and not (person.fastvaxt and not b):
                if (not b or not denstar or blocka(
                        person, vem_star_har(person.ruta + plush), barafraga=True) == "jadå") \
                        and gor_nagot(person, tur, b):
                    if int(person.steg_kvar) > -2 or \
                            (int(person.steg_kvar) > -3 and person.spelare.skills.__contains__("sprint")):
                        if not b:
                            if not person.fastvaxt:
                                if not person.har_blockat or person.ska_blitza:
                                    dodgning = kanske_dodga(person, plush, vanta)
                                    if animeringar:
                                        animera(person.ruta, person.ruta + plush, False, person)
                                    person.ruta += plush
                                    if person.har_bollen:
                                        bollruta += plush
                                    person.steg_kvar -= 1

                                    if dodgning != "fail":
                                        if person.steg_kvar < 0:
                                            if tarning(person.spelare.namn + " försöker ta ett extrasteg",
                                                       "extrasteg", person, "sure feet", 2, vanta=vanta) < \
                                                    extrasteglyckas:
                                                trilla(person)
                                                if person.har_bollen or bollruta == person.ruta:
                                                    try:
                                                        if ball_bounce() == "denfor":
                                                            inkast()
                                                    except BreakOut:
                                                        return
                                                person.har_bollen = False
                                                rita()
                                                pygame.display.update()
                                                nasta_drag("Turnover")
                                        if person is not None:
                                            if person.star and person.ruta == bollruta and person.har_bollen is False:
                                                plock = pick_up(person)
                                                if plock == "denfor":
                                                    inkast()
                                                if plock != "YEAH":
                                                    nasta_drag("Turnover")
                                    else:
                                        trilla(person)
                                        if person.har_bollen or bollruta == person.ruta:
                                            try:
                                                if ball_bounce() == "denfor":
                                                    inkast()
                                            except BreakOut:
                                                return
                                        person.har_bollen = False
                                        rita()
                                        pygame.display.update()
                                        nasta_drag("Turnover")
                        elif vem_star_har(person.ruta + plush, True)[1] != tur:
                            if vem_star_har(person.ruta + plush).star:
                                if (person.steg_kvar == person.spelare.varden[0] or person.ska_blitza) and not \
                                        person.har_blockat and not person.ska_passa and not person.ska_handoffa:
                                    person.steg_kvar -= 1
                                    if person.steg_kvar < 0 and tarning(
                                            person.spelare.namn + " försöker ta ett extrasteg för att blocka",
                                            "extrasteg", person, "sure feet", 2, vanta=vanta) < extrasteglyckas:
                                        trilla(person)
                                        person.har_bollen = False
                                        if person.har_bollen or bollruta == person.ruta:
                                            try:
                                                if ball_bounce() == "denfor":
                                                    inkast()
                                            except BreakOut:
                                                return
                                        rita()
                                        pygame.display.update()
                                        nasta_drag("Turnover")
                                    else:
                                        nasta = blocka(person, vem_star_har(person.ruta + plush))
                                        person.har_blockat = True
                                        if not person.ska_blitza:
                                            person.fardig = True
                                        if nasta:
                                            nasta_drag("Turnover")
                            else:
                                if person.ska_foula and not foulat:
                                    foula(person, vem_star_har(person.ruta + plush))


def kanske_dodga(person, plush, vanta):
    global kanskilla
    if tackle_zones(person) > 0:
        tackle = tackle_zones_ruta(person.ruta, vem_star_har(person.ruta, True)[1], "tackle")[1]
        zones = tackle_zones_ruta(person.ruta + plush, vem_star_har(person.ruta, True)[1], None, "titchy")
        ag = person.spelare.varden[2]
        if person.spelare.skills.__contains__("break tackle"):
            kanskilla = False
            globals()["vemgornatglobal"] = person
            exec("if not globals()['vemgornatglobal'].break_tackleanvant:\n    kanskilla = True", globals())
            if kanskilla:
                exec("person.break_tackleanvant = True")
                ag = person.spelare.varden[1]
        mer = aglist[ag]
        mer -= 1
        mer += tackle_zones_ruta(person.ruta, vilket_lag(person), "prehensile tail")[2]
        if person.spelare.skills.__contains__("titchy"):
            mer -= 1
        if not person.spelare.skills.__contains__("stunty") or person.spelare.skills.__contains__("secret weapon"):
            mer += zones
        if person.spelare.skills.__contains__("stunty"):
            paplaninfo.append(("stunty", fa_pos(person.ruta + plush)))
        if not tackle:
            slag = tarning(person.spelare.namn + " försöker dodga, med " + str(mer) + "+", "dodge",
                           person, "dodge", mer, vanta=vanta)
        else:
            slag = tarning(person.spelare.namn + " försöker dodga, med " + str(mer) + "+", "dodge",
                           person, None, mer, vanta=vanta)
        if (slag >= mer or slag == 6) and slag != 1:
            return "lyckad"
        else:
            return "fail"
    else:
        return "lyckad"


def putt(p, m, original=False):  # person, mot
    if m.fastvaxt:
        return "heblevinge"

    if m.spelare.skills.__contains__("stand firm"):
        rita(False)
        if anvanda_skill(gameDisplay, "stand firm", gameDisplay.copy().convert(), m.spelare.namn, mus, pekmus):
            rita(False)
            return "heblevinge"

    # börjar bara om den inte returnat pga stand firm
    tebaks = ""
    global bollruta
    riktningindex = m.ruta - p.ruta
    riktlista = [-27, (-1, -27, -26), -26, (-27, -26, -25), -25, (-26, -25, 1), -1, (-27, -1, 25), 1, (-25, 1, 27),
                 25, (-1, 25, 26), 26, (25, 26, 27), 27, (26, 27, 1)]
    riktningar = riktlista[riktlista.index(riktningindex) + 1]
    vem = "anfallaren"
    if original:
        if p.spelare.skills.__contains__("grab") and not m.spelare.skills.__contains__("side step"):
            alltocku = True
            for numh in listahall:
                if vem_star_har(m.ruta + numh) is None:
                    alltocku = False
            if not alltocku:
                rita(False)
                if anvanda_skill(gameDisplay, "grab", gameDisplay.copy().convert(), p.spelare.namn, mus, pekmus):
                    riktningar = (-27, -26, -25, -1, 1, 25, 26, 27)
    if m.spelare.skills.__contains__("side step") and not p.spelare.skills.__contains__("grab"):
        alltocku = True
        for numh in listahall:
            if vem_star_har(m.ruta + numh) is None:
                alltocku = False
        if not alltocku:
            riktningar = (-27, -26, -25, -1, 1, 25, 26, 27)
            vem = "försvararen"
    hallen = []
    numhh = 0
    kanskeut = []
    for vh in riktningar:
        hallen.append(True)
        if vem_star_har(m.ruta + vh) is not None:
            hallen[numhh] = False
        if far_spelaren_ut(m, vh):
            hallen[numhh] = False
            kanskeut.append(True)
        else:
            kanskeut.append(False)
        numhh += 1
    alla = True
    for vh in hallen:
        if vh:
            alla = False
    if alla:
        numhh = 0
        for _ in hallen:
            hallen[numhh] = True
            numhh += 1
    ut = False
    uth = False
    if alla and kanskeut.__contains__(True):
        uth = True
    utknapp = knapp(gameDisplay, "Putta ut!", (1180, 20), 45, (255, 10, 10))
    # kanskeut är antalet av de möjliga puttrutorna som är utanför plan, och utrak är sedan hur många puttrutor det
    # finns totalt. Om det är lika många, d.v.s. att alla puttrutor är utanför plan, så blir ut True

    rita(False)
    if uth:
        utknapp.rita()
    alltsurh = gameDisplay.copy().convert()
    while True:
        gameDisplay.blit(alltsurh, (0, 0))
        for eventhh in pygame.event.get():
            if eventhh.type == pygame.MOUSEBUTTONDOWN and eventhh.button == 1:
                rutanh = vilken_ruta(pygame.mouse.get_pos())
                vart = rutanh - m.ruta
                if uth and utknapp.ar_aktiv():
                    ut = True
                if (vart in riktningar and hallen[riktningar.index(vart)] and not kanskeut[riktningar.index(vart)]) \
                        or ut:
                    fore = m.ruta
                    if ut:
                        splash_message(m.spelare.namn + " blev utsmashad!", tid=2.0)
                        m.ruta = 1000
                        trilla(m, True, None, True)
                    elif vem_star_har(rutanh) is not None:
                        tebaks = putt(m, vem_star_har(m.ruta + vart))
                        if tebaks == "heblevinge":
                            return "heblevinge"
                    if m.ruta != 1000:
                        m.ruta += vart
                    if m.har_bollen:
                        if ut:
                            tebaks = "inkast"
                        else:
                            bollruta += vart
                    if m.ruta == bollruta and not m.har_bollen:
                        if tebaks != "inkast":
                            tebaks = "paboll"
                    if original:
                        folja = False
                        if p.spelare.skills.__contains__("frenzy"):
                            folja = True
                        if not p.fastvaxt and not p.spelare.skills.__contains__("frenzy"):
                            ja, nej = knapp(gameDisplay, "Följ efter", (20, 20)), knapp(gameDisplay, "Stanna", (20, 70))
                            folja, stopp = False, False

                            rita(False)
                            ja.rita()
                            nej.rita()
                            alltsurh = gameDisplay.copy().convert()
                            while not stopp:
                                for event2hh in pygame.event.get():
                                    if event2hh.type == pygame.MOUSEBUTTONDOWN and event2hh.button == 1:
                                        if ja.ar_aktiv():
                                            folja = True
                                            stopp = True
                                        elif nej.ar_aktiv():
                                            folja = False
                                            stopp = True
                                gameDisplay.blit(alltsurh, (0, 0))
                                if ja.ar_aktiv() or nej.ar_aktiv():
                                    gameDisplay.blit(pekmus, pygame.mouse.get_pos())
                                else:
                                    gameDisplay.blit(mus, pygame.mouse.get_pos())
                                pygame.display.update()
                        if folja:
                            p.ruta = fore
                            if p.har_bollen:
                                bollruta = fore
                    return tebaks
        numhh = 0
        for vh in hallen:
            if vh and not kanskeut[numhh]:
                gameDisplay.blit(globals()["Grön markörbild"], fa_pos(m.ruta + riktningar[numhh]))
            numhh += 1
        if uth and utknapp.ar_aktiv():
            gameDisplay.blit(pekmus, pygame.mouse.get_pos())
        else:
            gameDisplay.blit(mus, pygame.mouse.get_pos())
        if vem == "försvararen":
            skriv(gameDisplay, "Försvararen väljer putten.", (20, 140), 40)
        pygame.display.update()


def blocka(person, motperson, frenzat=False, kanrra=True, barafraga=False):
    global kanproa
    st1, st2 = person.spelare.varden[1], motperson.spelare.varden[1]

    if not barafraga and person.spelare.skills.__contains__("dauntless"):
        if st1 < st2:
            over = st2 - st1 + 1
            if tarning(person.spelare.namn + " försöker använda dauntless, " + str(over) + "+", "dauntless", person,
                       None, over) >= over:
                st1 = st2

    if person.ska_blitza and person.spelare.skills.__contains__("horns"):
        st1 += 1
    if motperson.ska_blitza and motperson.spelare.skills.__contains__("horns"):
        st2 += 1
    perlag = vem_star_har(person.ruta, True)[1]
    extra2 = 0
    for numh in listahall:
        if not far_spelaren_ut(person, numh):
            if person.ruta + numh != motperson.ruta:
                ph, lh = vem_star_har(person.ruta + numh, True)
                if ph is not None:
                    if lh != perlag:
                        if ph.star and ph.tacklezone:
                            if tackle_zones(ph) == 1 or ph.spelare.skills.__contains__("guard"):
                                extra2 += 1
                                paplaninfo.append(("-", fa_pos(ph.ruta)))
    motlag = vem_star_har(motperson.ruta, True)[1]
    extra1 = 0
    for numh in listahall:
        if not far_spelaren_ut(motperson, numh):
            if motperson.ruta + numh != person.ruta:
                ph, lh = vem_star_har(motperson.ruta + numh, True)
                if ph is not None:
                    if lh != motlag:
                        if ph.star and ph.tacklezone:
                            if tackle_zones(ph) == 1 or ph.spelare.skills.__contains__("guard"):
                                extra1 += 1
                                paplaninfo.append(("+", fa_pos(ph.ruta)))

    st1 += extra1
    st2 += extra2

    # print(st1)
    # print(st2)

    text = "Det finns inte så mycket att välja på"
    if st1 > st2:
        text = "Anfallaren väljer tärning"
    if st1 < st2:
        text = "Försvararen väljer tärning"

    tva, tre = False, False
    if st1 < st2 or st1 > st2:
        tva = True
    if st1 * 2 < st2 or st1 > st2 * 2:
        tre = True

    if barafraga:
        if fragablockar:
            rita(False)
            tplus = "?"
            if st1 < st2:
                tplus = " till motståndaren?"
            if not ((tre and fraga(gameDisplay, "Vill du blocka med tre tärningar" + tplus, mus, pekmus, True)) or (
                    not tre and tva and fraga(gameDisplay, "Vill du blocka med två tärningar" + tplus, mus,
                                              pekmus, True)) or (
                            not tva and not tre and fraga(gameDisplay, "Vill du blocka med en tärning?", mus, pekmus,
                                                          True))):
                return "nej"
            else:
                return "jadå"
        else:
            return "jadå"

    blocklista = ["Dödskalle", "Putt", "Putt", "Both down", "Defender down", "Defender stumbles"]
    val1, val2, val3 = random.choice(blocklista), random.choice(blocklista), random.choice(blocklista)

    rerollrutor = [(20, 20, 40, 40)]  # används för att reroll-funktionen ska veta var man kan trycka för att välja
    # tärningar

    plushar = val1
    if tva:
        plushar += ", " + val2
        rerollrutor.append((100, 20, 40, 40))
    if tre:
        plushar += ", " + val3
        rerollrutor.append((180, 20, 40, 40))

    def ritah():
        rita(False)
        gameDisplay.blit(globals()["Cirkelvitbild"], fa_pos(person.ruta))
        gameDisplay.blit(globals()["Cirkelrödbild"], fa_pos(motperson.ruta))

        gameDisplay.blit(globals()[val1 + "bild"], (20, 20))

        if tva:
            gameDisplay.blit(globals()[val2 + "bild"], (100, 20))
        if tre:
            gameDisplay.blit(globals()[val3 + "bild"], (180, 20))

        skriv(gameDisplay, "Block mellan " + person.spelare.namn + " och " + motperson.spelare.namn + ".", (20, 65), 50)
        skriv(gameDisplay, text, (20, 140), 40)

        rita_stats(person, False, 50)
        skriv(gameDisplay, "VS", (1250, 188), 50)
        rita_stats(motperson, False, 230)

    ritah()

    tryck = False

    if tur == vem_star_har(person.ruta, True)[1] and kanrra:
        kanproa = False
        globals()["vemgornatglobal"] = person  # den kan inte komma åt vemgornat inne i exec(), därför skapas här en
        if person.spelare.skills.__contains__("pro"):
            exec("if not globals()['vemgornatglobal'].proanvant:\n    kanproa = True", globals())
        if (not anvantrr and globals()["rerolls" + str(tur)] > 0) or kanproa:
            if kanproa and reroll(person, "pro", "", False, gameDisplay.copy().convert()):
                if tarning(person.spelare.namn +
                           " fösöker använda pro, 4+", "pro", person,
                           lyckas=4) > 3:
                    if frenzat:
                        if person.spelare.skills.__contains__("frenzy") and motperson.star and motperson.ruta != 1000:
                            return blocka(person, motperson, True, False)
                    return blocka(person, motperson, kanrra=False)
            elif ritah() is None and reroll(person, "vanlig", "", True, gameDisplay.copy().convert(), rerollrutor):
                if frenzat:
                    if person.spelare.skills.__contains__("frenzy") and motperson.star and motperson.ruta != 1000:
                        return blocka(person, motperson, True, False)
                return blocka(person, motperson, kanrra=False)
            else:
                tryck = True

    def func():
        musx, musy = pygame.mouse.get_pos()
        if ((20 <= musx <= 60) or (100 <= musx <= 140 and tva) or (180 <= musx <= 220 and tre)) and 20 <= musy \
                <= 60:
            if 20 <= musx <= 60:
                valt = val1
                tarningsslag.append("Block: " + plushar + ": " + str(0))
            elif 100 <= musx <= 160 and tva:
                valt = val2
                tarningsslag.append("Block: " + plushar + ": " + str(1))
            else:
                valt = val3
                tarningsslag.append("Block: " + plushar + ": " + str(2))
            nastah = False
            if valt == "Dödskalle":
                trilla(person, anfallare=motperson)
                if person.har_bollen:
                    try:
                        if ball_bounce() == "denfor":
                            inkast()
                    except BreakOut:
                        return
                person.har_bollen = False
                rita()
                pygame.display.update()
                nastah = True
            if valt == "Both down":
                if not motperson.spelare.skills.__contains__("block"):
                    trilla(motperson, anfallare=person)
                if not person.spelare.skills.__contains__("block"):
                    trilla(person, anfallare=motperson)
                    if person.har_bollen:
                        try:
                            if ball_bounce() == "denfor":
                                inkast()
                        except BreakOut:
                            return
                    person.har_bollen = False
                    rita()
                    pygame.display.update()
                    nastah = True
                if not motperson.spelare.skills.__contains__("block"):
                    if motperson.har_bollen:
                        try:
                            if ball_bounce() == "denfor":
                                inkast()
                        except BreakOut:
                            return
                    motperson.har_bollen = False
            if valt == "Defender stumbles":
                putten = putt(person, motperson, True)
                if (not motperson.spelare.skills.__contains__("dodge")) or person.spelare.skills.__contains__(
                        "tackle"):
                    if motperson.ruta != 1000:
                        trilla(motperson, anfallare=person)
                if putten == "paboll":
                    try:
                        if ball_bounce() == "denfor":
                            inkast()
                    except BreakOut:
                        return
                if putten == "inkast":
                    inkast()
                if (not motperson.spelare.skills.__contains__("dodge")) or person.spelare.skills.__contains__(
                        "tackle"):
                    if motperson.har_bollen:
                        try:
                            if ball_bounce() == "denfor":
                                inkast()
                        except BreakOut:
                            return
                    motperson.har_bollen = False
                if not frenzat:
                    if person.spelare.skills.__contains__("frenzy") and motperson.star and motperson.ruta != 1000:
                        if person.steg_kvar != -2 or (person.steg_kvar != -3 and person.spelare.skills.__contains__(
                                "sprint")):
                            if person.steg_kvar > 0 or tarning(person.spelare.namn + " försöker ta ett extrasteg för "
                                                                                     "att blocka", "extrasteg", person,
                                                               lyckas=2) >= extrasteglyckas:
                                person.steg_kvar -= 1
                                nastah = blocka(person, motperson, True)
            if valt == "Defender down":
                putten = putt(person, motperson, True)
                if motperson.ruta != 1000:
                    trilla(motperson, anfallare=person)
                if putten == "paboll":
                    try:
                        if ball_bounce() == "denfor":
                            inkast()
                    except BreakOut:
                        return
                if putten == "inkast":
                    inkast()
                if motperson.har_bollen:
                    try:
                        if ball_bounce() == "denfor":
                            inkast()
                    except BreakOut:
                        return
                motperson.har_bollen = False
            if valt == "Putt":
                putten = putt(person, motperson, True)
                if putten == "paboll":
                    try:
                        if ball_bounce() == "denfor":
                            inkast()
                    except BreakOut:
                        return
                if putten == "inkast":
                    inkast()
                if not frenzat:
                    if person.spelare.skills.__contains__("frenzy") and motperson.ruta != 1000:
                        if person.steg_kvar != -2 or (person.steg_kvar != -3 and person.spelare.skills.__contains__(
                                "sprint")):
                            if person.steg_kvar > 0 or tarning(person.spelare.namn + " försöker ta ett extrasteg för "
                                                                                     "att blocka", "extrasteg", person,
                                                               lyckas=2) >= extrasteglyckas:
                                person.steg_kvar -= 1
                                nastah = blocka(person, motperson, True)
            if i_touch_down(person):
                if tur != vem_star_har(person.ruta, True)[1]:
                    nasta_drag("Fixar...")
                touch_down(vem_star_har(person.ruta, True)[1], person)
            if i_touch_down(motperson):
                if tur != vem_star_har(motperson.ruta, True)[1]:
                    nasta_drag("Fixar...")
                touch_down(vem_star_har(motperson.ruta, True)[1], motperson)
            if extra1 > 0:
                paplaninfo.append(("+" + str(extra1), fa_pos(person.ruta)))
            if extra2 > 0:
                paplaninfo.append(("+" + str(extra2), fa_pos(motperson.ruta)))
            return nastah
        else:
            return None

    if tryck:
        f = func()
        if f is not None:
            return f

    ritah()

    alltsurh = gameDisplay.copy().convert()

    while True:
        for eventh in pygame.event.get():
            if eventh.type == pygame.MOUSEBUTTONDOWN and eventh.button == 1:
                f = func()
                if f is not None:
                    return f
        gameDisplay.blit(alltsurh, (0, 0))
        gameDisplay.blit(mus, pygame.mouse.get_pos())
        pygame.display.update()


def foula(person, motperson):
    global foulat
    perlag, motlag = vem_star_har(person.ruta, True)[1], vem_star_har(motperson.ruta, True)[1]
    bonus = 0
    for numh in listahall:
        if not far_spelaren_ut(person, numh):
            if person.ruta + numh != motperson.ruta:
                ph, lh = vem_star_har(person.ruta + numh, True)
                if ph is not None:
                    if lh != perlag:
                        if ph.star and ph.tacklezone:
                            if tackle_zones(ph) == 1:
                                bonus -= 1
    for numh in listahall:
        if not far_spelaren_ut(motperson, numh):
            if motperson.ruta + numh != person.ruta:
                ph, lh = vem_star_har(motperson.ruta + numh, True)
                if ph is not None:
                    if lh != motlag:
                        if ph.star and ph.tacklezone:
                            if tackle_zones(ph) == 0:
                                bonus += 1
    trilla(motperson, bonus=bonus, foulperson=person)
    foulat = True
    person.fardig = True
    if person.skadad == "utvisad" and person.ruta == 1000:
        if person.har_bollen:
            if ball_bounce() == "denfor":
                inkast()
        nasta_drag("Turnover")


def har_blitzat(turh):
    blitzat = False
    if turh == 1:
        for vh in alla_spelare1:
            if vh.ska_blitza:
                blitzat = True
    else:
        for vh in alla_spelare2:
            if vh.ska_blitza:
                blitzat = True
    return blitzat


def har_passat(turh):
    passath = False
    if turh == 1:
        for vh in alla_spelare1:
            if vh.ska_passa:
                passath = True
    else:
        for vh in alla_spelare2:
            if vh.ska_passa:
                passath = True
    return passath


def har_handoffat(turh):
    passath = False
    if turh == 1:
        for vh in alla_spelare1:
            if vh.ska_handoffa:
                passath = True
    else:
        for vh in alla_spelare2:
            if vh.ska_handoffa:
                passath = True
    return passath


def har_foulat():
    foulath = False
    if tur == 1:
        for vh in alla_spelare1:
            if vh.ska_foula:
                foulath = True
    else:
        for vh in alla_spelare2:
            if vh.ska_foula:
                foulath = True
    return foulath


def ge_boll(turh):
    splash_message("Touchback! (bollen for ut)", (0, 255, 0), 2)
    global bollruta
    rita(False)
    alltsurh = gameDisplay.copy().convert()
    while True:
        for eventh in pygame.event.get():
            if eventh.type == pygame.MOUSEBUTTONDOWN:
                musposh = pygame.mouse.get_pos()
                rutanh = vilken_ruta(musposh)
                dar = vem_star_har(rutanh, True)
                if dar[0] is not None and dar[1] == turh:
                    bollruta = rutanh
                    vem_star_har(rutanh).har_bollen = True
                    return
        gameDisplay.blit(alltsurh, (0, 0))
        musposh = pygame.mouse.get_pos()
        gameDisplay.blit(mus, musposh)
        rutanh = vilken_ruta(musposh)
        dar = vem_star_har(rutanh, True)
        if dar[0] is not None and dar[1] == turh:
            gameDisplay.blit(globals()["Grön markörbild"], fa_pos(vilken_ruta(musposh)))
            rita_stats(dar[0])
        else:
            gameDisplay.blit(globals()["Cancelbild"], fa_pos(vilken_ruta(musposh)))
        gameDisplay.blit(mus, musposh)
        pygame.display.update()


def kickoffreturn():
    global bollruta
    rita(False)
    skriv(gameDisplay, "Välj en kick-off-returner", (10, 10), 40)
    alltsurh = gameDisplay.copy().convert()
    while True:
        for eventh in pygame.event.get():
            if eventh.type == pygame.MOUSEBUTTONDOWN:
                musposh = pygame.mouse.get_pos()
                rutanh = vilken_ruta(musposh)
                dar = vem_star_har(rutanh, True)
                if eventh.button == 3:
                    return
                if eventh.button == 1:
                    if dar[0] is not None and dar[1] == tur and dar[0].spelare.skills.__contains__("kick-off return"):
                        steg = 0
                        rita(False)
                        alltsurh = gameDisplay.copy().convert()
                        while True:
                            for event2h in pygame.event.get():
                                if event2h.type == pygame.KEYDOWN:
                                    keyh = pygame.key.get_pressed()
                                    if keyh[pygame.K_SPACE]:
                                        return
                                    plush = 0
                                    if keyh[pygame.K_KP1]:
                                        plush = 25
                                    if keyh[pygame.K_KP2]:
                                        plush = 26
                                    if keyh[pygame.K_KP3]:
                                        plush = 27
                                    if keyh[pygame.K_KP4]:
                                        plush = -1
                                    if keyh[pygame.K_KP6]:
                                        plush = 1
                                    if keyh[pygame.K_KP7]:
                                        plush = -27
                                    if keyh[pygame.K_KP8]:
                                        plush = -26
                                    if keyh[pygame.K_KP9]:
                                        plush = -25
                                    if plush:
                                        if not far_spelaren_ut(dar[0], plush, True, tur):
                                            if vem_star_har(dar[0].ruta + plush) is None:
                                                dar[0].ruta += plush
                                                if dar[0].har_bollen:
                                                    bollruta += plush
                                                steg += 1
                                                if steg == 3:
                                                    return
                                                rita()
                                                alltsurh = gameDisplay.copy().convert()
                                gameDisplay.blit(alltsurh, (0, 0))
                                musposh = pygame.mouse.get_pos()
                                gameDisplay.blit(globals()["Cirkelvitbild"], fa_pos(dar[0].ruta))
                                gameDisplay.blit(mus, musposh)
                                pygame.display.update()
        gameDisplay.blit(alltsurh, (0, 0))
        musposh = pygame.mouse.get_pos()
        gameDisplay.blit(mus, musposh)
        rutanh = vilken_ruta(musposh)

        dar = vem_star_har(rutanh, True)
        if dar[0] is not None and dar[1] == tur and dar[0].spelare.skills.__contains__("kick-off return"):
            gameDisplay.blit(globals()["Grön markörbild"], fa_pos(vilken_ruta(musposh)))
        else:
            gameDisplay.blit(globals()["Cancelbild"], fa_pos(vilken_ruta(musposh)))
        gameDisplay.blit(mus, musposh)
        pygame.display.update()


def rakna_klar(lag, nu):
    klart = True
    vad = ""
    kantn = 0
    kantu = 0
    linjen = 0
    for vh in lag:
        if vh.skadad and vh.ruta != 1000:
            vad = vh.spelare.namn + " (" + vh.spelare.typ + ") är på plan, men är skadad (" + vh.skadad + ")!"
            klart = False
        if nu == 1:
            if fa_pos(vh.ruta)[0] < 585 and vh.ruta != 1000:
                klart = False
                vad = "Du har spelare på fel sida!"
            if 584 < fa_pos(vh.ruta)[0] < 630 and vh.ruta != 1000 and 179 < fa_pos(vh.ruta)[1] < 495:
                linjen += 1
        if nu == 2:
            if fa_pos(vh.ruta)[0] > 584 and vh.ruta != 1000:
                klart = False
                vad = "Du har spelare på fel sida!"
            if 585 > fa_pos(vh.ruta)[0] > 539 and vh.ruta != 1000 and 179 < fa_pos(vh.ruta)[1] < 495:
                linjen += 1
        if fa_pos(vh.ruta)[1] > 494 and vh.ruta != 1000:
            kantn += 1
        if fa_pos(vh.ruta)[1] < 180 and vh.ruta != 1000:
            kantu += 1

    if kantu > 2:
        klart = False
        vad = "Du har för många i övre wide zone!"
    if kantn > 2:
        klart = False
        vad = "Du har för många i nedre wide zone!"
    if linjen < 3 and not vad:
        klart = False
        vad = "Du har inte tre personer på linjen!"

    return klart, vad


def set_up(vem_borjar, andragangen=False):
    global bollruta, tur, td1, td2
    bollruta = 0
    klarknapp = knapp(gameDisplay, "Klar", (1200, 20), textfarg=(0, 255, 0))
    sparaknapp = knapp(gameDisplay, "Spara", (1200, 100), 40, textfarg=(0, 100, 0))
    laddaknapp = knapp(gameDisplay, "Ladda", (1200, 150), 40, textfarg=(0, 100, 0))

    if andragangen is False:
        ejskadade1 = 0
        for vh in alla_spelare1:
            if not vh.skadad:
                ejskadade1 += 1
            vh.fardig = False
            vh.har_gjort = False
            vh.steg_kvar = vh.spelare.varden[0]
            vh.har_bollen = False
            vh.har_blockat = False
            vh.ska_blitza = False
            vh.ska_passa = False
            vh.star = True
            vh.fastvaxt = False
            vh.tacklezone = True
            vh.ska_foula = False
            if vh.skadad == "för varm":
                vh.skadad = ""
            if vh.skadad.__contains__("stunned"):
                vh.skadad = ""
            if vh.skadad.__contains__("knocked-out"):
                kodslag = random.randint(1, 6)
                if kodslag > 3 - bwbs1:
                    vh.skadad = ""
                tarningsslag.append("T6 (" + vh.spelare.namn + " knocked-out): " + str(kodslag))
            # rita(True)
            # pygame.display.update()
            # time.sleep(0.1)
            if vader == "sweltering heat":
                if vh.ruta != 1000:
                    slagh = random.randint(1, 6)
                    if slagh == 1:
                        tarningsslag.append("T6 (värmen " + vh.spelare.namn + "): " + str(slagh))
                        vh.skadad = "för varm"

            vh.ruta = 1000
        if ejskadade1 < 3 and pygame_input(gameDisplay, coach1 + " måste ge upp.") != "nejnejnej":
            td2 += 50
            slut()

        ejskadade2 = 0
        for vh in alla_spelare2:
            if not vh.skadad:
                ejskadade2 += 1
            vh.fardig = False
            vh.har_gjort = False
            vh.steg_kvar = vh.spelare.varden[0]
            vh.har_bollen = False
            vh.har_blockat = False
            vh.ska_blitza = False
            vh.ska_passa = False
            vh.star = True
            vh.fastvaxt = False
            vh.tacklezone = True
            vh.ska_foula = False
            if vh.skadad == "för varm":
                vh.skadad = ""
            if vh.skadad.__contains__("stunned"):
                vh.skadad = ""
            if vh.skadad.__contains__("knocked-out"):
                kodslag = random.randint(1, 6)
                if kodslag > 3 - bwbs2:
                    vh.skadad = ""
                tarningsslag.append("T6 (" + vh.spelare.namn + " knocked-out): " + str(kodslag))

            # rita(True)
            # pygame.display.update()
            # time.sleep(0.1)
            if vader == "sweltering heat":
                if vh.ruta != 1000:
                    slagh = random.randint(1, 6)
                    if slagh == 1:
                        tarningsslag.append("T6 (värmen " + vh.spelare.namn + "): " + str(slagh))
                        vh.skadad = "för varm"
            vh.ruta = 1000

        if ejskadade2 < 3 and pygame_input(gameDisplay, coach2 + " måste ge upp.") != "nejnejnej":
            td1 += 50
            slut()

    nu = vem_borjar
    if nu == 1:
        nulagh = alla_spelare1
        coach = coach1
        tur = 2
    else:
        nulagh = alla_spelare2
        coach = coach2
        tur = 1
    utsatta = 0

    spara_match(False, True, vem_borjar)

    splash_message(coach + " börjar ställa upp.", (0, 255, 0))

    andra = False

    updateh = True
    alltsurh = gameDisplay.copy().convert()

    while True:
        for eventh in pygame.event.get():
            if eventh.type == pygame.QUIT:
                quit()
            if eventh.type == pygame.KEYDOWN:
                updateh = True
                keyh = pygame.key.get_pressed()
                if keyh[pygame.K_a]:
                    if nu == 2:
                        for vh in alla_spelare2:
                            vh.ruta = 1000
                        numh = 0
                        for vh in alla_spelare2:
                            if vh.skadad == "":
                                vh.ruta = 64 + 26 * numh
                                numh += 1
                                if numh > 10:
                                    break
                    if nu == 1:
                        for vh in alla_spelare1:
                            vh.ruta = 1000
                        numh = 0
                        for vh in alla_spelare1:
                            if vh.skadad == "":
                                vh.ruta = 65 + 26 * numh
                                numh += 1
                                if numh > 10:
                                    break
                if keyh[pygame.K_c]:
                    if nu == 2:
                        for vh in alla_spelare2:
                            vh.ruta = 1000
                    if nu == 1:
                        for vh in alla_spelare1:
                            vh.ruta = 1000
            if eventh.type == pygame.MOUSEBUTTONDOWN:
                updateh = True
                musposh = pygame.mouse.get_pos()
                if klarknapp.ar_aktiv() and eventh.button == 1:
                    va = rakna_klar(nulagh, nu)
                    if va[0]:
                        if nu == 1:
                            nu = 2
                            nulagh = alla_spelare2
                            coach = coach2
                            if andra:
                                kick_off(2)
                                return
                            else:
                                andra = True
                        else:
                            nu = 1
                            nulagh = alla_spelare1
                            coach = coach1
                            if andra:
                                kick_off(1)
                                return
                            else:
                                andra = True
                        splash_message(vettigt_s(coach) + " tur att ställa upp.", (0, 255, 0))
                    else:
                        splash_message(va[1], tid=1.5)
                elif sparaknapp.ar_aktiv() and eventh.button == 1:
                    # sparar en uppställning
                    upst = pygame_input(gameDisplay, "Vad ska uppställningen heta?")
                    if upst:
                        try:
                            os.mkdir(".skapade lag/" + globals()["lag" + str(nu) + "namn"] + "/.setups")
                        except FileExistsError:
                            pass
                        filh = open(".skapade lag/" + globals()["lag" + str(nu) + "namn"] + "/.setups/" +
                                    upst, "w", encoding="utf-8")
                        skrivah = ""
                        for vh in nulagh:
                            if vh.ruta != 1000:
                                skrivah += vh.spelare.namn + "=" + str(vh.ruta) + ","
                        filh.write(skrivah.strip(","))
                        filh.close()
                elif laddaknapp.ar_aktiv() and eventh.button == 1:
                    try:
                        upst = pygame_input(gameDisplay, "Vad heter uppställningen?")
                        if upst:
                            filh = open(".skapade lag/" + globals()["lag" + str(nu) + "namn"] + "/.setups/" +
                                        upst, "r", encoding="utf-8")
                            setuplist = filh.read().split(",")
                            filh.close()
                            setupsida = 2
                            if fa_pos(int(setuplist[0].split("=")[1]))[0] > 584:
                                setupsida = 1
                            for vh in nulagh:
                                vh.ruta = 1000
                            if setupsida == nu:
                                for sh in setuplist:
                                    n, r = sh.split("=")  # namn, ruta
                                    for vh in nulagh:
                                        if vh.skadad == "" and vh.spelare.namn == n and int(r) != 1000:
                                            vh.ruta = int(r)
                            else:
                                for sh in setuplist:
                                    n, r = sh.split("=")  # namn, ruta
                                    for vh in nulagh:
                                        if vh.skadad == "" and vh.spelare.namn == n and int(r) != 1000:
                                            vh.ruta = tvartom_ruta(int(r))
                    except FileNotFoundError:
                        splash_message("Den uppställningen finns inte.")
                else:
                    rutanh = vilken_ruta(musposh)
                    if vem_star_har(rutanh) is None:
                        if eventh.button == 1:
                            if utsatta < 11:
                                nagon = valj_person(nulagh)
                                if nagon is not None:
                                    nagon.ruta = rutanh
                            else:
                                splash_message("Du har redan 11 på plan!")
                    else:
                        person, lagtillhorighet = vem_star_har(rutanh, True)
                        if lagtillhorighet == nu:
                            if eventh.button == 1:
                                kor = True
                                rita(False)
                                gameDisplay.blit(globals()["Cirkelvitbild"], fa_pos(rutanh))
                                rita_stats(person)
                                alltsur2h = gameDisplay.copy().convert()
                                while kor:
                                    for event2h in pygame.event.get():
                                        if event2h.type == pygame.MOUSEBUTTONDOWN:
                                            if event2h.button == 1:
                                                musposh = pygame.mouse.get_pos()
                                                infoh = vem_star_har(vilken_ruta(musposh), True)
                                                if infoh[0] is None or infoh[1] == nu:
                                                    if infoh[1] == nu:
                                                        infoh[0].ruta = person.ruta
                                                    person.ruta = vilken_ruta(musposh)
                                                    kor = False
                                            if event2h.button == 3:
                                                kor = False
                                    gameDisplay.blit(alltsur2h, (0, 0))
                                    gameDisplay.blit(mus, pygame.mouse.get_pos())
                                    pygame.display.update()
                            elif eventh.button == 3:
                                person.ruta = 1000
                        else:
                            if eventh.button == 1:
                                kor = True
                                rita(False)
                                gameDisplay.blit(globals()["Cirkelgråbild"], fa_pos(rutanh))
                                rita_stats(person)
                                alltsur2h = gameDisplay.copy().convert()
                                while kor:
                                    for event2h in pygame.event.get():
                                        if event2h.type == pygame.MOUSEBUTTONDOWN:
                                            if event2h.button == 3:
                                                kor = False
                                    gameDisplay.blit(alltsur2h, (0, 0))
                                    gameDisplay.blit(mus, pygame.mouse.get_pos())
                                    pygame.display.update()

        utsatta = 0
        for vh in nulagh:
            if vh.ruta != 1000:
                utsatta += 1
        if updateh:
            rita(False)
            klarknapp.rita()
            sparaknapp.rita()
            laddaknapp.rita()
            alltsurh = gameDisplay.copy().convert()
            updateh = False

        gameDisplay.blit(alltsurh, (0, 0))

        musposh = pygame.mouse.get_pos()
        if klarknapp.ar_aktiv() or sparaknapp.ar_aktiv() or laddaknapp.ar_aktiv():
            gameDisplay.blit(pekmus, musposh)
        else:
            gameDisplay.blit(mus, musposh)

        pygame.display.update()


def kick_off(vemkickar):
    global aktiv
    aktiv = None
    global bollruta
    splash_message("Kick-off!", (0, 255, 0), 1.5)
    if vemkickar == 1:
        detandra = 2
    else:
        detandra = 1
    rita(False)
    alltsurh = gameDisplay.copy().convert()
    while True:
        for eventh in pygame.event.get():
            if eventh.type == pygame.MOUSEBUTTONDOWN:
                musposh = pygame.mouse.get_pos()
                if ((musposh[0] < 585 and vemkickar == 1) or (musposh[0] > 584 and vemkickar == 2)) and musposh[0] <= \
                        1170 and 0 <= musposh[1] <= 675:
                    rutanh = vilken_ruta(musposh)
                    hall = random.randint(1, 8)
                    tarningsslag.append("T8 (kick-scatter): " + str(hall))
                    plush = listahall[hall - 1]
                    hur_manga = random.randint(1, 6)
                    tarningsslag.append("T6 (kick-längd): " + str(hur_manga))
                    if animeringar:
                        if vemkickar == 2:
                            xh = 600
                            vem = None
                            for vh in alla_spelare2:
                                if vh.ruta != 1000 and fa_pos(vh.ruta)[0] < xh:
                                    xh = fa_pos(vh.ruta)[0]
                                    vem = vh.ruta
                            if vem is not None:
                                animera(vem, rutanh + (plush * hur_manga), True)
                        if vemkickar == 1:
                            xh = 600
                            vem = None
                            for vh in alla_spelare1:
                                if vh.ruta != 1000 and fa_pos(vh.ruta)[0] > xh:
                                    xh = fa_pos(vh.ruta)[0]
                                    vem = vh.ruta
                            if vem is not None:
                                animera(vem, rutanh + (plush * hur_manga), True)

                    bollruta = rutanh
                    denfor = False
                    for _ in range(0, hur_manga):
                        if far_bollen_ut(bollruta, plush, True, detandra):
                            bollruta += plush
                            denfor = True
                            ge_boll(detandra)
                            break
                        else:
                            bollruta += plush
                    if denfor is False:
                        kkr = False
                        if tur == 1:
                            for vh in alla_spelare1:
                                if not tackle_zones(vh) and vh.spelare.skills.__contains__("kick-off return"):
                                    if not (584 < fa_pos(vh.ruta)[0] < 630 and vh.ruta != 1000 and 179 < fa_pos(
                                            vh.ruta)[1] < 495):
                                        if not vh.skadad and vh.ruta != 1000:
                                            kkr = True
                        if tur == 2:
                            for vh in alla_spelare2:
                                if not tackle_zones(vh) and vh.spelare.skills.__contains__("kick-off return"):
                                    if not (585 > fa_pos(vh.ruta)[0] > 539 and vh.ruta != 1000 and 179 < fa_pos(
                                            vh.ruta)[1] < 495):
                                        if not vh.skadad and vh.ruta != 1000:
                                            kkr = True
                        if kkr:
                            kickoffreturn()
                        if vem_star_har(bollruta) is not None:
                            if vem_star_har(bollruta).star is True and vem_star_har(bollruta).tacklezone:
                                if fanga(sidbry=detandra) == "denfor":
                                    ge_boll(detandra)
                            else:
                                if ball_bounce(detandra) == "denfor":
                                    ge_boll(detandra)
                        elif ball_bounce(detandra) == "denfor":
                            ge_boll(detandra)
                    return
        gameDisplay.blit(alltsurh, (0, 0))
        musposh = pygame.mouse.get_pos()
        if ((musposh[0] < 585 and vemkickar == 1) or (musposh[0] > 584 and vemkickar == 2)) and musposh[0] <= 1170 \
                and 0 <= musposh[1] <= 675:
            gameDisplay.blit(globals()["Grön markörbild"], fa_pos(vilken_ruta(musposh)))
        else:
            gameDisplay.blit(globals()["Cancelbild"], fa_pos(vilken_ruta(musposh)))
        gameDisplay.blit(mus, musposh)

        pygame.display.update()


def kolla_mojliga_rutor(person, ruta, stegkvar, hittatill=None, personenslag=None, tacklezones=False):
    if person.star is False and not person.spelare.skills.__contains__("jump up"):
        stegkvar -= 3
    stegkvar += 2
    globals()["harsprint"] = False
    if person.spelare.skills.__contains__("sprint"):
        stegkvar += 1
        globals()["harsprint"] = True
    globals()["personlag"] = personenslag
    globals()["hittatill"] = hittatill
    globals()["ruta"] = ruta
    globals()["stegkvar"] = stegkvar
    globals()["tacklezones"] = tacklezones
    globals()["scopet"] = 1
    globals()["kollade"] = []
    globals()["kolladesteg"] = []
    globals()["kolladedodgar"] = []
    fler = ""
    if stegkvar > 0:
        kod = """dodgar = 0\n"""
        for _ in range(1, stegkvar + 1):
            scopeplus = "scopet = " + str(_)
            dodgeplus = "dodgar = 0"
            if _ != 1:
                dodgeplus = 'dodgar = locals()["hittills" + "' + str(_ - 1) + '"]'
            kod += fler + """for tjohej in listahall:
    """ + fler + """locals()["hittills" + '""" + str(_) + """'] = dodgar
    """ + fler + dodgeplus + """
    """ + fler + scopeplus + """
    """ + fler + """if vem_star_har(ruta + hallh) is None and (hittatill is None or not tacklezones or (ruta + hallh) 
    == hittatill or tackle_zones_ruta((ruta + hallh), personlag) == 0):
        """ + fler + """if hittatill is not None and not tacklezones and tackle_zones_ruta((ruta + hallh), personlag
        ) != 0:
            """ + fler + """dodgar += 1
        """ + fler + """if not faktiska.__contains__(ruta + hallh) and not far_nagot_ut(ruta + noggi1, noggi2):
            """ + fler + """faktiska.append(ruta + hallh)
        """ + fler + """if (kollade.__contains__(ruta + hallh) is False or (stegkvar - knasboll > kolladesteg[
        kollade.index(ruta + hallh)])) and not far_nagot_ut(ruta + noggi1, noggi2):
            """ + fler + """if hittatill is not None and (ruta + hallh) == hittatill:
            """ + fler + """    vag = [jaha]
            """ + fler + """if kollade.__contains__(ruta + hallh):
                """ + fler + """kolladesteg.pop(kollade.index(ruta + hallh))
                """ + fler + """kollade.pop(kollade.index(ruta + hallh))
                """ + fler + """try:
                    """ + fler + """extrasteg.pop(extrasteg.index(ruta + hallh))
                """ + fler + """except ValueError:
                """ + fler + """    pass

            """ + fler + """kollade.append(ruta + hallh)
            """ + fler + """kolladesteg.append(stegkvar - knasboll)
            """ + fler + """if hittatill is not None and not tacklezones:
                """ + fler + """kolladedodgar.append(dodgar)
            """ + fler + """if scopet == stegkvar or scopet + 1 == stegkvar or (scopet + 2 == stegkvar and harsprint):
                """ + fler + """extrasteg.append(ruta + hallh)
"""
            if _ == 1:
                kod = kod.replace("noggi1", "0")
                kod = kod.replace("noggi2", "halloh")
                kod = kod.replace("tjohej", "halloh")
            else:
                kod = kod.replace("tjohej", "hall" + str(_) + "h")
            kod = kod.replace("knasboll", str(_))
            replaca = "halloh"
            fler += "            "
            replacaut = "halloh"
            if _ != 1:
                for _2 in range(1, _):
                    replaca += " + hall" + str(_2 + 1) + "h"
                    if not _2 == _:
                        if _2 != 0 and _2 != 1:
                            replacaut += " + hall" + str(_2) + "h"
            kod = kod.replace("noggi1", replacaut)
            kod = kod.replace("noggi2", "hall" + str(_) + "h")
            jahareplaca = "halloh, "
            if hittatill is not None:
                if _ != 1:
                    for _2 in range(1, _):
                        jahareplaca += "hall" + str(_2 + 1) + "h, "
                jahareplaca = jahareplaca[:-2]
                kod = kod.replace("jaha", jahareplaca)

            replaca += ")"
            kod = kod.replace("hallh)", replaca)
        exec(kod, globals())


def ga_vag(person, vagen):
    rutorna = []
    dragfore = drag

    if vader == "blizzard":
        farg = (1, 1, 1)
    else:
        farg = (255, 255, 255)
    global faktiska
    minus = 0
    if person.star is False:
        minus = 3
    rita(False)

    plag = vilket_lag(person)

    originalruta = person.ruta
    originalsteg = person.steg_kvar

    def ritah():
        nonlocal rutorna
        rutanuh = originalruta
        rutorna = []
        borjan = 0
        if tackle_zones_ruta(originalruta, plag):
            nastatz = True
        else:
            nastatz = False
        for numhh in vagen:
            borjan += 1
            rutanuh += numhh
            rutorna.append(rutanuh)
            surhh = pygame.Surface((43, 43))
            if i_touch_down_ruta(rutanuh, plag):
                pygame.draw.circle(surhh, (0, 255, 0), (22, 22), 22)
            elif borjan + minus > originalsteg or nastatz:
                pygame.draw.circle(surhh, (255, 0, 0), (22, 22), 22)
            else:
                pygame.draw.circle(surhh, farg, (22, 22), 22)
            if tackle_zones_ruta(rutanuh, plag):
                nastatz = True
            else:
                nastatz = False
            surhh.set_alpha(118)
            surhh.set_colorkey((0, 0, 0))
            gameDisplay.blit(surhh, (fa_pos(rutanuh)[0] + 1, fa_pos(rutanuh)[1] + 1))

    ritah()
    alltsurh = gameDisplay.copy().convert()
    while True:
        for eventh in pygame.event.get():
            if eventh.type == pygame.MOUSEBUTTONDOWN:
                if eventh.button == 1:
                    if not rutorna:
                        return
                    klickadruta = vilken_ruta(pygame.mouse.get_pos())
                    if klickadruta == rutorna[-1]:
                        if len(vagen) > 1 and vem_star_har(klickadruta) is not None:
                            if vilket_lag(vem_star_har(klickadruta)) != vilket_lag(person):
                                if not har_blitzat(tur):
                                    person.ska_blitza = True
                        if person.star is False and (person.spelare.skills.__contains__("jump up") is False or
                                                     not (vem_star_har(rutorna[0]) is not None and vem_star_har(
                                                         rutorna[0]).star is True and
                                                          vem_star_har(rutorna[0], True)[1] != tur and
                                                          len(rutorna) == 1)):
                            if gor_nagot(person, tur):
                                if person.steg_kvar > 2 or person.spelare.skills.__contains__("jump up"):
                                    person.star = True
                                    if not person.spelare.skills.__contains__("jump up"):
                                        person.steg_kvar -= 3
                                else:
                                    if tarning(person.spelare.namn + " försöker ställa sig upp, 4+", "resa sig", person,
                                               None, 4) > 3:
                                        person.star = True
                                        person.steg_kvar -= 3
                                    else:
                                        person.fardig = True
                        for num1h in vagen:
                            if tur == vilket_lag(person) and dragfore == drag:
                                ga(person, num1h, False)
                                if i_touch_down(person):
                                    touch_down(plag, person)
                                    return

                                rita(False)
                                ritah()

                                # rita gubben igen, annars blir den bakom det vita
                                bh = globals()[person.spelare.typ + "bild"]
                                bhs = bh.get_size()[1]
                                if bhs == 45:
                                    gameDisplay.blit(bh, fa_pos(person.ruta))
                                else:
                                    gameDisplay.blit(bh, (fa_pos(person.ruta)[0], fa_pos(person.ruta)[1] - (bhs - 45)))

                                pygame.display.update()
                                if not animeringar:
                                    time.sleep(0.2)
                    return

                elif eventh.button == 3:
                    if len(rutorna) < aktiv.steg_kvar + 2 - minus or (len(rutorna) < aktiv.steg_kvar + 3 - minus and
                                                                      person.spelare.skills.__contains__("sprint")):
                        rutanh = vilken_ruta(pygame.mouse.get_pos())
                        if rutanh != person.ruta:
                            bredvidh = False
                            for numh in listahall:
                                if rutorna[-1] + numh == rutanh:
                                    bredvidh = True
                            if bredvidh:
                                vagen.append(rutanh - rutorna[-1])
                                rita(False)
                                ritah()
                                alltsurh = gameDisplay.copy().convert()
        gameDisplay.blit(alltsurh, (0, 0))
        gameDisplay.blit(mus, pygame.mouse.get_pos())
        pygame.display.update()


# den här variabeln är till för att om bollen bouncar när man passar, så blir det turnover, och SEDAN kollar datorn att
# man står i touch down, därför blir det nästa drag igen med "fixar" som förklaring. Variabeln gör så att draget sätts
# tillbaka så att det görs touch down samma drag som man passade
passfailnu = False

aktiv = None
info = None
tur = 1
td1, td2 = 0, 0
drag = 1
anvantrr = False
kanapo1, kanapo2 = 0, 0
harapo1, harapo2 = False, False  # dont cara about the shit that it is two different variables, nobody cares
fil = open(".skapade lag/" + lag1namn + "/Apo", "r")
if fil.read() == "True":
    kanapo1 = 1
    harapo1 = True
fil.close()
fil = open(".skapade lag/" + lag2namn + "/Apo", "r")
if fil.read() == "True":
    kanapo2 = 1
    harapo2 = True
fil.close()

bwbs1, bwbs2 = 0, 0

if not matchen:
    inducements()
    spelplan = pygame.image.load(".bilder/.spelplansgrejer/" + vadertillbild + ".png").convert()
    bollruta = 0
    passat, handoffat, foulat = False, False, False

    borjar = random.randint(1, 2)
    set_up(borjar)
    if borjar == 1:
        tur = 2
    else:
        tur = 1

else:
    matchload = ladda_match()
    spelplan = pygame.image.load(".bilder/.spelplansgrejer/" + vadertillbild + ".png").convert()
    if vader == "blizzard":
        globals()["Cirkelvitbild"] = pygame.image.load(".bilder/.markörer/Cirkelsvart.png").convert_alpha()
    if matchload[0] == "kick-off":
        set_up(matchload[1], True)

extrasteglyckas = 2
if vader == "blizzard":
    extrasteglyckas = 3

dragklarknapp = knapp(gameDisplay, "Nästa drag", (1180, 10), 45, (0, 255, 0))

update = True
alltsur = gameDisplay.copy().convert()

faktiska = []
kollade = []

clock = pygame.time.Clock()

while True:
    clock.tick(60)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quit()

        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1 or event.button == 3:
                update = True
            if dragklarknapp.ar_aktiv():
                nasta_drag("Nästa drag")
            else:
                if event.button == 1:
                    muspos = pygame.mouse.get_pos()
                    if 1625 > muspos[0] >= 1175 and ((225 < muspos[1] < 380 and aktiv is not None) or
                                                     (225 < muspos[1] < 360 and info is not None)):
                        if info is not None:
                            visa_info_om(info.spelare)
                        elif aktiv is not None:
                            visa_info_om(aktiv.spelare)

                    else:
                        rutan = vilken_ruta(muspos)
                        stardar = vem_star_har(rutan, True)
                        if stardar[0] is not None and stardar[1] == tur:
                            aktiv = stardar[0]
                            info = None
                        elif stardar[0] is not None:
                            info = stardar[0]
                            aktiv = None
                        else:
                            aktiv = None
                            info = None
                elif event.button == 3:
                    muspos = pygame.mouse.get_pos()
                    rutan = vilken_ruta(muspos)
                    if aktiv is not None:
                        if rutan == aktiv.ruta:
                            if not aktiv.skadad:
                                hogerklick(aktiv)
                        else:
                            if aktiv.fardig is False:
                                bredvid = False
                                for num in listahall:
                                    if aktiv.ruta + num == rutan:
                                        bredvid = True
                                if vem_star_har(rutan, True)[1] == tur:
                                    bredvid = False
                                if bredvid:
                                    if aktiv.steg_kvar > -2 or (
                                            aktiv.steg_kvar > -3 and aktiv.spelare.skills.__contains__("sprint")):
                                        ga_vag(aktiv, [rutan - aktiv.ruta])
                                else:
                                    if rutan in faktiska:
                                        vag = []
                                        kolla_mojliga_rutor(aktiv, aktiv.ruta, aktiv.steg_kvar, rutan, vilket_lag(
                                            aktiv), True)
                                        if not vag:
                                            vag = []
                                            kolla_mojliga_rutor(aktiv, aktiv.ruta, aktiv.steg_kvar, rutan, vilket_lag(
                                                aktiv))
                                        ga_vag(aktiv, vag)

        if event.type == pygame.KEYDOWN:
            update = True
            key = pygame.key.get_pressed()
            if hemligakommandon:
                if key[pygame.K_k] and (key[pygame.K_RCTRL] or key[pygame.K_LCTRL]):
                    set_up(1)
            if key[pygame.K_i]:
                data = ["tur", "bollruta", "borjar", "passat", "handoffat", "drag", "td1", "td2", "anvantrr",
                        "rerolls1", "rerolls2", "kanapo1", "kanapo2", "foulat", "vader",
                        "bribes1", "bribes2", "bwbs1", "bwbs2"]
                koru = True
                while koru:
                    for event2 in pygame.event.get():
                        if event2.type == pygame.QUIT:
                            quit()
                        if event2.type == pygame.MOUSEBUTTONDOWN or event2.type == pygame.KEYDOWN:
                            koru = False
                    gameDisplay.fill((255, 255, 255))
                    xj, yj = 0, 0
                    for v in data:
                        skriv(gameDisplay, stor_forsta_bokstav(v) + ": " + str(globals()[v]), (xj, yj))
                        yj += 30
                    gameDisplay.blit(mus, pygame.mouse.get_pos())
                    pygame.display.update()
            if key[pygame.K_t]:
                for v in tarningsslag:
                    print(v)
            if ((key[pygame.K_RCTRL] or key[pygame.K_LCTRL]) and key[pygame.K_q]) or key[pygame.K_ESCAPE]:
                if pygame_input(gameDisplay, "Vill du verkligen avsluta?", "ja").lower() == "ja":
                    exit()
            if (key[pygame.K_RCTRL] or key[pygame.K_LCTRL]) and key[pygame.K_s]:
                spara_match()
            if hemligakommandon:
                if key[pygame.K_d] and (key[pygame.K_RCTRL] or key[pygame.K_LCTRL]):
                    slut()
            if aktiv is not None:
                if key[pygame.K_SPACE]:
                    if aktiv.star is False:
                        if gor_nagot(aktiv, tur):
                            if aktiv.steg_kvar > 2 or aktiv.spelare.skills.__contains__("jump up"):
                                aktiv.star = True
                                if not aktiv.spelare.skills.__contains__("jump up"):
                                    aktiv.steg_kvar -= 3
                            else:
                                if tarning(aktiv.spelare.namn + " försöker ställa sig upp, 4+", "resa sig", aktiv,
                                           None, 4) > 3:
                                    aktiv.star = True
                                    aktiv.steg_kvar -= 3
                                else:
                                    aktiv.fardig = True
                plus = 0
                if hemligakommandon:
                    if key[pygame.K_l] and (key[pygame.K_RCTRL] or key[pygame.K_LCTRL]):
                        aktiv.star = False
                    if key[pygame.K_b] and (key[pygame.K_RCTRL] or key[pygame.K_LCTRL]):
                        aktiv.skadad = "badly hurt"
                        aktiv.ruta = 1000
                if key[pygame.K_KP1]:
                    plus = 25
                if key[pygame.K_KP2]:
                    plus = 26
                if key[pygame.K_KP3]:
                    plus = 27
                if key[pygame.K_KP4]:
                    plus = -1
                if key[pygame.K_KP6]:
                    plus = 1
                if key[pygame.K_KP7]:
                    plus = -27
                if key[pygame.K_KP8]:
                    plus = -26
                if key[pygame.K_KP9]:
                    plus = -25
                if plus:
                    ga(aktiv, plus)

    # kollar om någon står i touch down, och om det är den andras drag så gör den nasta_drag() för
    # att det inte ska bli fel med vem som ställer upp å sånt
    for v in alla_spelare1:
        if i_touch_down(v):
            if tur != 1:
                if passfailnu:
                    drag -= 1
                    nasta_drag("Fixar...")
                    drag -= 1
                else:
                    nasta_drag("Fixar...")
            passfailnu = False
            touch_down(1, v)
    for v in alla_spelare2:
        if i_touch_down(v):
            if tur != 2:
                if passfailnu:
                    drag -= 1
                    nasta_drag("Fixar...")
                    drag -= 1
                else:
                    nasta_drag("Fixar...")
            passfailnu = False
            touch_down(2, v)

    if update:
        rita(False)
        if aktiv is not None:
            if aktiv.fardig is True:
                gameDisplay.blit(globals()["Cirkelrödbild"], fa_pos(aktiv.ruta))
            elif aktiv.star is False:
                gameDisplay.blit(globals()["Cirkelgulbild"], fa_pos(aktiv.ruta))
            else:
                gameDisplay.blit(globals()["Cirkelvitbild"], fa_pos(aktiv.ruta))
            rita_stats(aktiv, True)

            if ruthjalp:
                faktiska = []
                extrasteg = []

                if not aktiv.fardig and not aktiv.fastvaxt:
                    kolla_mojliga_rutor(aktiv, aktiv.ruta, aktiv.steg_kvar)

                for num in faktiska:
                    surh = pygame.Surface((43, 43))
                    if num in extrasteg:
                        surh.fill((255, 0, 0))
                    else:
                        surh.fill((255, 255, 255))
                    surh.set_alpha(118)
                    gameDisplay.blit(surh, (fa_pos(num)[0] + 1, fa_pos(num)[1] + 1))

        if info is not None:
            gameDisplay.blit(globals()["Cirkelgråbild"], fa_pos(info.ruta))
            rita_stats(info)

            if ruthjalp:
                faktiska = []
                extrasteg = []

                if not info.fastvaxt:
                    kolla_mojliga_rutor(info, info.ruta, info.steg_kvar)

                for num in faktiska:
                    surh = pygame.Surface((43, 43))
                    if num in extrasteg:
                        surh.fill((255, 0, 0))
                    else:
                        surh.fill((255, 255, 255))
                    surh.set_alpha(118)
                    gameDisplay.blit(surh, (fa_pos(num)[0] + 1, fa_pos(num)[1] + 1))

        skriv(gameDisplay, vettigt_s(globals()["coach" + str(tur)]) + " drag", (1175, 60), 30, (255, 0, 0))

        # skriver ställningen i matchen
        if td1 == td2:
            vu1 = ""
        else:
            vu1 = " till"
        skriv(gameDisplay, "Det står " + str(td1) + " – " + str(td2) + vu1, (1175, 95), 25, (255, 100, 20))
        if not td1 == td2:
            if td1 > td2:
                vu2 = "1"
            else:
                vu2 = "2"
            skriv(gameDisplay, globals()["lag" + str(vu2) + "namn"], (1175, 120), 25, (255, 100, 20))
        #
        if egetdrag:
            if drag % 2 == 0:
                dh = int(drag / 2)
            else:
                dh = int((drag + 1) / 2)
        else:
            dh = drag
        skriv(gameDisplay, "Drag: " + str(dh), (1175, 150), 25, (255, 247, 0))

        skriv(gameDisplay, "Dina rerolls: " + str(globals()["rerolls" + str(tur)]), (1175, 185), 25, (255, 192, 203))

        dragklarknapp.rita()

        if paplaninfo:
            for v in paplaninfo:
                skriv(gameDisplay, v[0], v[1], 25, farg=(255, 255, 255))
            nedrakning -= 1
        alltsur = gameDisplay.copy().convert()
        update = False

    if nedrakning != nedrakutgang:
        nedrakning -= 1
        if nedrakning < 0:
            nedrakning = nedrakutgang
            paplaninfo = []
            update = True

    gameDisplay.blit(alltsur, (0, 0))

    if visafps:
        skriv(gameDisplay, str(int(clock.get_fps())))

    muspos = pygame.mouse.get_pos()
    if dragklarknapp.ar_aktiv():
        gameDisplay.blit(pekmus, muspos)
    else:
        gameDisplay.blit(mus, muspos)
    pygame.display.update()
